# Toasty-Himmel fuer Nuit: 3x2-Face-Grid, aus Richtungsvektoren berechnet (Naehte passen, wenn die Layout-Annahme stimmt).
# LAYOUT: Zelle 0..5 (Zeile 0: 0,1,2 / Zeile 1: 3,4,5). Annahme (UNGEPRUEFT): bottom, north, south, top, west, east
import numpy as np
from PIL import Image, ImageFilter
S=512
LAYOUT=['bottom','north','south','top','west','east']
BASIS={ # forward, right, up
 'north':((0,0,-1),(1,0,0),(0,1,0)),'south':((0,0,1),(-1,0,0),(0,1,0)),
 'east':((1,0,0),(0,0,1),(0,1,0)),'west':((-1,0,0),(0,0,-1),(0,1,0)),
 'top':((0,1,0),(1,0,0),(0,0,-1)),'bottom':((0,-1,0),(1,0,0),(0,0,1))}
rng=np.random.default_rng(11)
perm=rng.integers(0,2**31-1,size=(3,))
def hash3(ix,iy,iz,seed):
    h=(ix*374761393+iy*668265263+iz*2147483647+seed*1274126177)&0xFFFFFFFF
    h=((h^(h>>13))*1274126177)&0xFFFFFFFF
    return ((h^(h>>16))&0xFFFF)/65535.0
def vnoise(x,y,z,seed=0):
    ix,iy,iz=np.floor(x).astype(np.int64),np.floor(y).astype(np.int64),np.floor(z).astype(np.int64)
    fx,fy,fz=x-ix,y-iy,z-iz
    fx,fy,fz=[f*f*(3-2*f) for f in (fx,fy,fz)]
    r=0
    for dx in (0,1):
        for dy in (0,1):
            for dz in (0,1):
                w=(fx if dx else 1-fx)*(fy if dy else 1-fy)*(fz if dz else 1-fz)
                r=r+w*hash3(ix+dx,iy+dy,iz+dz,seed)
    return r
def fbm(x,y,z,oct=5,seed=0):
    a,t,n=1.0,0,0
    for o in range(oct):
        t+=a*vnoise(x,y,z,seed+o); n+=a; x,y,z=x*2.03+17,y*2.03+5,z*2.03+9; a*=.5
    return t/n
def lerp(a,b,t): return a+(b-a)*t[...,None]
def c(h): return np.array([(h>>16)&255,(h>>8)&255,h&255],float)/255
ZEN,MID,HOR,GLOW,DOWN=c(0x120A3A),c(0xA855F7),c(0x7DD3FC),c(0xF0ABFC),c(0x5B6FD8)
def stars(dirs_face):
    pass
def face_dirs(name):
    f,r,u=[np.array(v,float) for v in BASIS[name]]
    g=(np.arange(S)+.5)/S*2-1
    U,V=np.meshgrid(g,-g)
    d=f[None,None,:]+U[...,None]*r+V[...,None]*u
    return d/np.linalg.norm(d,axis=2,keepdims=True)
def shade(d):
    x,y,z=d[...,0],d[...,1],d[...,2]
    yaw=np.arctan2(x,-z)
    # Grundverlauf
    t=np.clip(y,0,1)
    col=lerp(lerp(HOR,MID,np.clip(t/0.35,0,1)**0.8),ZEN,np.clip((t-0.25)/0.75,0,1)**0.9)
    # Horizont-Glow (rosa) um eine Richtung
    sun=np.array([0.55,0.04,-0.83]); sun/=np.linalg.norm(sun)
    dot=np.clip((d*sun).sum(2),0,1)
    col=col+GLOW*(dot**24*0.55+dot**5*0.12)[...,None]*np.clip(1-np.abs(y)*2.2,0,1)[...,None]
    # Nebel im oberen Himmel
    neb=fbm(x*2.2,y*2.2,z*2.2,5,40)
    neb=np.clip((neb-.45)*2.4,0,1)*np.clip(y*1.6,0,1)
    ncol=lerp(np.broadcast_to(c(0xC084FC),col.shape).copy(),np.broadcast_to(c(0x38BDF8),col.shape).copy(),np.clip(fbm(x*1.3,y*1.3,z*1.3,3,90),0,1))
    col=col+ncol*(neb*0.35)[...,None]
    # Sterne: weiche runde Punkte, 3D-Zellen -> nahtlos
    for scale,thr,size in ((90,.90,1.0),(170,.93,.7)):
        P=np.stack([x,y,z],2)*scale
        I=np.floor(P).astype(np.int64)
        h=hash3(I[...,0],I[...,1],I[...,2],5)
        jx=hash3(I[...,0],I[...,1],I[...,2],6)*.5+.25
        jy=hash3(I[...,0],I[...,1],I[...,2],7)*.5+.25
        jz=hash3(I[...,0],I[...,1],I[...,2],8)*.5+.25
        dist=np.sqrt((P[...,0]-I[...,0]-jx)**2+(P[...,1]-I[...,1]-jy)**2+(P[...,2]-I[...,2]-jz)**2)
        rad=0.16+0.12*hash3(I[...,0],I[...,1],I[...,2],9)
        st=(h>thr)*np.clip(1-dist/rad,0,1)**1.5*np.clip(y*3+.15,0,1)*size
        tint=lerp(np.broadcast_to(c(0xFFFFFF),col.shape).copy(),np.broadcast_to(c(0xBAE6FD),col.shape).copy(),hash3(I[...,0],I[...,1],I[...,2],10))
        col=col+tint*st[...,None]*1.3
    # Wolkenschichten
    for k,(ymin,ymax,sc,seed,opac) in enumerate(((.02,.5,2.6,3,.95),(.25,.8,1.7,21,.55))):
        # auf Ebene projizieren: stauchen in y fuer lange Baender
        yy=np.clip(y,0.03,1)
        px,pz=x/yy**0.6,z/yy**0.6
        n=fbm(px*sc*.5+seed,pz*sc*.5,yy*sc*1.5,6,seed)
        cov=np.clip((n-.50)*3.2,0,1)*np.clip((y-ymin)/0.06,0,1)*np.clip((ymax-y)/0.2,0,1)
        # Licht: heller wo Dichte niedrig (Rand), Unterseite violett-rosa
        n2=fbm(px*sc*.5+seed,pz*sc*.5,yy*sc*1.5+.35,6,seed)
        lit=np.clip((n-n2)*6+.55,0,1)
        base=lerp(np.broadcast_to(c(0x7C5CD6),col.shape).copy(),np.broadcast_to(c(0xFFFFFF),col.shape).copy(),lit)
        base=base+GLOW*(dot**8*.35)[...,None]
        col=lerp(col,base,cov*opac)
    # Aurora-Vorhaenge (violett -> magenta, senkrechte Strahlen)
    yawp=np.arctan2(x,-z)
    wob=0.10*np.sin(yawp*3+1.3)+0.05*np.sin(yawp*7)+0.04*vnoise(np.cos(yawp)*4,np.sin(yawp)*4,np.zeros_like(yawp),55)
    cen=0.24+wob
    band=np.exp(-((y-cen)/0.11)**2)
    rays=0.55+0.45*np.sin(yawp*38+6*vnoise(np.cos(yawp)*6,np.sin(yawp)*6,np.zeros_like(yawp),56))
    rays=np.clip(rays,0,1)**1.4
    au=band*rays*np.clip(y*14,0,1)
    acol=lerp(np.broadcast_to(c(0xE879F9),col.shape).copy(),np.broadcast_to(c(0x8B5CF6),col.shape).copy(),np.clip((y-0.10)/0.35,0,1))
    col=col+acol*(au*0.75)[...,None]
    # Ringplanet
    P0=np.array([0.55,0.40,-0.73]); P0/=np.linalg.norm(P0)
    e1=np.cross(P0,[0,1,0]); e1/=np.linalg.norm(e1); e2=np.cross(P0,e1)
    pa=(d*e1).sum(2); pb=(d*e2).sum(2); pf=(d*P0).sum(2)
    R=0.20
    ca,sa_=np.cos(0.38),np.sin(0.38)
    ra=pa*ca+pb*sa_; rb=-pa*sa_+pb*ca
    ell=np.sqrt((ra/(R*2.15))**2+(rb/(R*0.62))**2)
    ring=((ell>0.66)&(ell<1.0)&(pf>0)).astype(float)
    ring*= (0.35+0.65*np.clip(1-np.abs(ell-0.83)/0.17,0,1))
    ring*= 1-0.45*((ell>0.80)&(ell<0.83)).astype(float)
    rcol=lerp(np.broadcast_to(c(0xE9D5FF),col.shape).copy(),np.broadcast_to(c(0xA78BFA),col.shape).copy(),np.clip((ell-.66)/.34,0,1))
    front=(rb<0)
    rr=np.sqrt(pa**2+pb**2)
    disk=(rr<R)&(pf>0)
    nz=np.sqrt(np.clip(1-(rr/R)**2,0,1))
    lx=(pa/R)*np.cos(2.5)+(pb/R)*np.sin(2.5)
    lam=np.clip(0.25+0.85*(-0.5*pa/R+0.6*pb/R+0.7*nz),0,1)
    tex=fbm(pa*18+3,pb*18,nz*6,5,77)
    pcol=lerp(np.broadcast_to(c(0x5B4B9A),col.shape).copy(),np.broadcast_to(c(0xF5F3FF),col.shape).copy(),np.clip((tex-.38)*2.2,0,1))
    pcol=pcol*lam[...,None]
    glow=np.exp(-np.clip(rr-R,0,1)/0.05)*(pf>0)*(rr>=R)
    col=col+np.broadcast_to(c(0xC084FC),col.shape)*(glow*0.35)[...,None]
    col=lerp(col,rcol,ring*(~front))                 # Ring hinten
    col=lerp(col,pcol,disk.astype(float))            # Planet
    col=lerp(col,rcol,ring*front*0.95)               # Ring vorne
    # Berg-Silhouette am Horizont
    ang=yaw
    hgt=0.015+0.05*vnoise(np.cos(ang)*3,np.sin(ang)*3,np.zeros_like(ang),70)+0.03*vnoise(np.cos(ang)*9,np.sin(ang)*9,np.zeros_like(ang),71)
    m=np.clip((hgt-y)*180,0,1)*(y>-0.2)
    mc=lerp(np.broadcast_to(c(0x3A2480),col.shape).copy(),np.broadcast_to(c(0x140B38),col.shape).copy(),np.clip((hgt-y)*14,0,1))
    col=lerp(col,mc,m)
    # Unterhalb Horizont: dunkler Dunst
    col=lerp(col,np.broadcast_to(c(0x1B1049),col.shape).copy(),np.clip(-y*40,0,1))
    return col
def render(name):
    return Image.fromarray((np.clip(shade(face_dirs(name)),0,1)*255).astype(np.uint8))
if __name__!="__main__": raise SystemExit
out=Image.new('RGB',(S*3,S*2))
for i,n in enumerate(LAYOUT): out.paste(render(n),((i%3)*S,(i//3)*S))
out.save('src/main/resources/assets/toastyclient/textures/sky/toasty_sky.png',optimize=True)
out.resize((1152,768)).save('/home/claude/sky_preview.png')
