package dev.toasty.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Auktions-HUD: Karte mit Logo, Item, Zeitbalken, Höchstgebot, Mindestgebot, Sofortkauf/Mindestpreis,
 * Top 3, Live-Gebotsverlauf und Warteschlange. Verschiebbar im HUD-Editor. Dazu großer Countdown in der Mitte.
 */
public final class ToastyAuctionHud {
    private ToastyAuctionHud() {}

    private record Row(String l, String r, int color) {}

    public static void render(DrawContext ctx, RenderTickCounter tick) {
        ToastyConfig c = ToastyConfig.get();
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.options.hudHidden || !c.aucHud) return;
        if (!c.masterOn || mc.currentScreen instanceof ToastyMenu) return;
        TextRenderer tr = mc.textRenderer;
        boolean editing = mc.currentScreen instanceof ToastyHudEditor || mc.currentScreen instanceof net.minecraft.client.gui.screen.ChatScreen;
        if (!ToastyAuction.active && ToastyAuction.queue.isEmpty() && editing && mc.currentScreen instanceof ToastyHudEditor) {
            preview(ctx, tr, mc, c);
            return;
        }
        if (ToastyAuction.active) {
            card(ctx, tr, mc, c);
            if (c.aucBigCountdown) bigCountdown(ctx, tr, mc);
        } else if (!ToastyAuction.queue.isEmpty()) {
            queueCard(ctx, tr, mc, c);
        } else ToastyHud.BOUNDS.remove("auction");
    }

    private static float[] defaultPos(MinecraftClient mc, ToastyConfig c, float fw, float fh) {
        int sw = mc.getWindow().getScaledWidth(), sh = mc.getWindow().getScaledHeight();
        return switch (c.aucCorner) {
            case "top_left" -> new float[]{6, 6};
            case "top_right" -> new float[]{sw - fw - 6, 6};
            case "bottom_right" -> new float[]{sw - fw - 6, sh - fh - 40};
            case "mid_left" -> new float[]{6, (sh - fh) / 2};
            default -> new float[]{sw - fw - 6, (sh - fh) / 2};
        };
    }

    private static void card(DrawContext ctx, TextRenderer tr, MinecraftClient mc, ToastyConfig c) {
        long now = System.currentTimeMillis();
        long left = ToastyAuction.left();
        boolean urgent = left < 10_000 && !ToastyAuction.paused;
        boolean hasBid = ToastyAuction.bestName != null;
        long need = hasBid ? ToastyAuction.best + Math.max(1, c.aucMinRaise) : ToastyAuction.startBid;

        List<Row> rows = new ArrayList<>();
        rows.add(new Row("Höchstgebot", hasBid ? ToastyAuction.fmt(ToastyAuction.best) : ToastyAuction.fmt(ToastyAuction.startBid) + " (Start)", ToastyTheme.GOOD));
        rows.add(new Row("Meistbietender", hasBid ? ToastyAuction.bestName : "–", hasBid ? ToastyTheme.GOOD : ToastyTheme.MUTED));
        rows.add(new Row("Insgesamt geboten", ToastyAuction.fmt(ToastyAuction.total()) + "  ·  " + ToastyAuction.bids.size() + " Bieter", ToastyTheme.BLUE));
        rows.add(new Row("Nächstes Gebot ab", ToastyAuction.fmt(need), ToastyTheme.TEXT));
        if (ToastyAuction.buyNow > 0) rows.add(new Row("Sofortkauf", ToastyAuction.fmt(ToastyAuction.buyNow), ToastyTheme.BLUE));
        if (ToastyAuction.reserve > 0) {
            boolean met = hasBid && ToastyAuction.best >= ToastyAuction.reserve;
            rows.add(new Row("Mindestpreis", met ? "erreicht" : "noch nicht", met ? ToastyTheme.GOOD : ToastyTheme.BAD));
        }
        if (c.aucAntiSnipe) {
            boolean hit = now < ToastyAuction.snipeFlashUntil;
            rows.add(new Row("Anti-Snipe", hit ? "+ Zeit! wieder " + c.aucSnipeTo + "s" : "letzte " + c.aucSnipeWindow + "s → " + c.aucSnipeTo + "s",
                hit ? ToastyTheme.BAD : ToastyTheme.MUTED));
        }
        List<Map.Entry<String, Long>> top = ToastyAuction.top();
        int n = Math.min(3, top.size());
        for (int i = 0; i < n; i++)
            rows.add(new Row((i + 1) + ". " + top.get(i).getKey(), ToastyAuction.fmt(top.get(i).getValue()), i == 0 ? ToastyTheme.GOOD : ToastyTheme.TEXT));

        List<Row> feed = new ArrayList<>();
        if (c.aucFeed) {
            for (int i = 0; i < Math.min(4, ToastyAuction.feed.size()); i++) {
                ToastyAuction.Bid b = ToastyAuction.feed.get(i);
                long ago = (now - b.at()) / 1000;
                String r = "+" + ToastyAuction.fmt(b.amount()) + (b.total() != b.amount() ? " = " + ToastyAuction.fmt(b.total()) : "") + "  ·  " + ago + "s";
                feed.add(new Row(b.name(), r, b.top() ? ToastyTheme.GOOD : ToastyTheme.MUTED));
            }
        }
        String next = !ToastyAuction.queue.isEmpty() ? "Danach: " + ToastyAuction.queue.get(0).item() + (ToastyAuction.queue.size() > 1 ? " (+" + (ToastyAuction.queue.size() - 1) + ")" : "") : null;

        String title = ToastyAuction.item;
        String time = ToastyAuction.paused ? "PAUSE" : ToastyAuction.mmss(left);
        int pad = 7;
        int w = Math.max(150, Math.min(240, tr.getWidth(title) + 12 + tr.getWidth(time) * 2 + 16));
        for (Row r : rows) w = Math.max(w, Math.min(260, tr.getWidth(r.l()) + 14 + tr.getWidth(r.r())));
        for (Row r : feed) w = Math.max(w, Math.min(260, tr.getWidth(r.l()) + 14 + tr.getWidth(r.r())));
        int h = pad + 12 + 4 + 16 + 6 + rows.size() * 11 + (feed.isEmpty() ? 0 : 14 + feed.size() * 10) + (next == null ? 0 : 13) + pad - 2;
        int bw = w + pad * 2;

        float s = c.hudScale;
        float[] d = defaultPos(mc, c, bw * s, h * s);
        float[] pos = ToastyHud.place("auction", d[0], d[1], bw * s, h * s, mc);
        ctx.getMatrices().pushMatrix();
        ctx.getMatrices().translate(pos[0], pos[1]);
        ctx.getMatrices().scale(s, s);

        ToastyTheme.panel(ctx, 0, 0, bw, h);
        boolean flash = now < ToastyAuction.flashUntil;
        int edge = flash ? ToastyTheme.GOOD : urgent ? ToastyTheme.BAD : ToastyTheme.alpha(ToastyTheme.PURPLE, 0x90);
        ToastyTheme.roundOutline(ctx, 0, 0, bw, h, 6, edge);

        // Kopfzeile: Logo + "AUKTION" + Zeit gross rechts
        ToastyLogo.draw(ctx, pad, pad, 10);
        ToastyTheme.gradientText(ctx, tr, "AUKTION", pad + 14, pad + 1);
        ctx.getMatrices().pushMatrix();
        ctx.getMatrices().translate(pad + w, pad - 1);
        ctx.getMatrices().scale(1.5f, 1.5f);
        ctx.drawTextWithShadow(tr, time, -tr.getWidth(time), 0, urgent ? ToastyTheme.BAD : ToastyAuction.paused ? ToastyTheme.MUTED : ToastyTheme.TEXT);
        ctx.getMatrices().popMatrix();

        // Item-Name
        int y = pad + 16;
        String t = tr.getWidth(title) > w ? tr.trimToWidth(title, w - 6) + "…" : title;
        ctx.drawTextWithShadow(tr, t, pad, y, ToastyTheme.BLUE);
        y += 12;

        // Zeitbalken
        float frac = ToastyAuction.durationMs <= 0 ? 0 : Math.min(1f, left / (float) ToastyAuction.durationMs);
        ToastyTheme.roundRectExact(ctx, pad, y, w, 4, 2, ToastyTheme.alpha(0xFFFFFFFF, 0x30));
        int fill = Math.max(4, Math.round(w * frac));
        int barCol = urgent ? ToastyTheme.BAD : ToastyTheme.lerp(ToastyTheme.BLUE, ToastyTheme.PURPLE, 1f - frac);
        if (frac > 0) ToastyTheme.roundRectExact(ctx, pad, y, fill, 4, 2, barCol);
        y += 10;

        for (Row r : rows) {
            ctx.drawTextWithShadow(tr, r.l(), pad, y, ToastyTheme.MUTED);
            ctx.drawTextWithShadow(tr, r.r(), pad + w - tr.getWidth(r.r()), y, r.color());
            y += 11;
        }
        if (!feed.isEmpty()) {
            y += 3;
            ctx.fill(pad, y, pad + w, y + 1, ToastyTheme.alpha(0xFFFFFFFF, 0x30));
            y += 4;
            ctx.drawTextWithShadow(tr, "Letzte Gebote", pad, y, ToastyTheme.MUTED);
            y += 10;
            for (Row r : feed) {
                ctx.drawTextWithShadow(tr, r.l(), pad, y, r.color());
                ctx.drawTextWithShadow(tr, r.r(), pad + w - tr.getWidth(r.r()), y, ToastyTheme.TEXT);
                y += 10;
            }
        }
        if (next != null) {
            y += 3;
            ctx.drawTextWithShadow(tr, tr.trimToWidth(next, w), pad, y, ToastyTheme.MUTED);
        }
        ctx.getMatrices().popMatrix();
    }

    /** Platzhalter im HUD-Editor, damit man das Auktions-HUD auch ohne laufende Auktion verschieben kann. */
    private static void preview(DrawContext ctx, TextRenderer tr, MinecraftClient mc, ToastyConfig c) {
        int pad = 7, w = 160, h = 76, bw = w + pad * 2;
        float s = c.hudScale;
        float[] d = defaultPos(mc, c, bw * s, h * s);
        float[] pos = ToastyHud.place("auction", d[0], d[1], bw * s, h * s, mc);
        ctx.getMatrices().pushMatrix();
        ctx.getMatrices().translate(pos[0], pos[1]);
        ctx.getMatrices().scale(s, s);
        ToastyTheme.panel(ctx, 0, 0, bw, h);
        ToastyLogo.draw(ctx, pad, pad, 10);
        ToastyTheme.gradientText(ctx, tr, "AUKTION", pad + 14, pad + 1);
        ctx.drawTextWithShadow(tr, "Vorschau", pad + w - tr.getWidth("Vorschau"), pad + 1, ToastyTheme.MUTED);
        ctx.drawTextWithShadow(tr, "Hier erscheint das", pad, pad + 20, ToastyTheme.TEXT);
        ctx.drawTextWithShadow(tr, "Auktions-HUD.", pad, pad + 31, ToastyTheme.TEXT);
        ctx.drawTextWithShadow(tr, "Ziehen zum Verschieben", pad, pad + 50, ToastyTheme.MUTED);
        ctx.getMatrices().popMatrix();
    }

    private static void queueCard(DrawContext ctx, TextRenderer tr, MinecraftClient mc, ToastyConfig c) {
        long in = ToastyAuction.queueStartsIn();
        String l1 = "Nächste Auktion: " + ToastyAuction.queue.get(0).item();
        String l2 = (in >= 0 ? "startet in " + ToastyAuction.mmss(in) : "/action queue next zum Starten") + "  ·  " + ToastyAuction.queue.size() + " in der Warteschlange";
        int pad = 6, w = Math.min(240, Math.max(tr.getWidth(l1) + 14, tr.getWidth(l2))), h = pad * 2 + 20, bw = w + pad * 2;
        float s = c.hudScale;
        float[] d = defaultPos(mc, c, bw * s, h * s);
        float[] pos = ToastyHud.place("auction", d[0], d[1], bw * s, h * s, mc);
        ctx.getMatrices().pushMatrix();
        ctx.getMatrices().translate(pos[0], pos[1]);
        ctx.getMatrices().scale(s, s);
        ToastyTheme.panel(ctx, 0, 0, bw, h);
        ToastyLogo.draw(ctx, pad, pad, 9);
        ctx.drawTextWithShadow(tr, tr.trimToWidth(l1, w - 12), pad + 12, pad, ToastyTheme.BLUE);
        ctx.drawTextWithShadow(tr, tr.trimToWidth(l2, w), pad, pad + 11, ToastyTheme.MUTED);
        ctx.getMatrices().popMatrix();
    }

    /** Letzte 5 Sekunden: große Zahl in der Bildschirmmitte, oben. */
    private static void bigCountdown(DrawContext ctx, TextRenderer tr, MinecraftClient mc) {
        if (ToastyAuction.paused) return;
        long left = ToastyAuction.left();
        if (left > 5000 || left <= 0) return;
        int sec = (int) ((left + 999) / 1000);
        float part = (left % 1000) / 1000f;              // 1 -> 0 innerhalb jeder Sekunde
        float scale = 3.0f + 1.5f * part;
        int alpha = (int) (110 + 145 * part);
        String s = String.valueOf(sec);
        int sw = mc.getWindow().getScaledWidth();
        ctx.getMatrices().pushMatrix();
        ctx.getMatrices().translate(sw / 2f, 38);
        ctx.getMatrices().scale(scale, scale);
        ctx.drawTextWithShadow(tr, s, -tr.getWidth(s) / 2, 0, ToastyTheme.alpha(sec <= 3 ? ToastyTheme.BAD : ToastyTheme.BLUE, alpha));
        ctx.getMatrices().popMatrix();
    }
}
