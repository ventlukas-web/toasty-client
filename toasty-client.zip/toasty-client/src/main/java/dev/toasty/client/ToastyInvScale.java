package dev.toasty.client;

import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.minecraft.client.gui.screen.ingame.HandledScreen;

/**
 * Inventare (Spieler-Inventar, Kisten, Ofen, Crafting ...) oeffnen standardmaessig mit GUI-Skalierung 2, egal was in den Optionen steht.
 * Die Skalierung wird direkt beim Aufbau des Screens gesetzt (vor dem ersten Frame, kein Flackern) und beim Schliessen zurueckgestellt.
 */
public final class ToastyInvScale {
    private static double saved = -1;
    private static boolean guard;

    private ToastyInvScale() {}

    public static void register() {
        ScreenEvents.AFTER_INIT.register((mc, screen, w, h) -> {
            if (guard || !(screen instanceof HandledScreen<?>)) return;
            if (!ToastyConfig.get().invGui2) return;
            var win = mc.getWindow();
            if (Math.abs(win.getScaleFactor() - 2.0) < 0.01) return;
            guard = true;
            try {
                if (saved < 0) saved = win.getScaleFactor();
                win.setScaleFactor(2.0);
                screen.init(mc, win.getScaledWidth(), win.getScaledHeight());
            } catch (Throwable ignored) {
            } finally { guard = false; }
            ScreenEvents.remove(screen).register(s -> {
                if (saved > 0) {
                    try { mc.getWindow().setScaleFactor(saved); } catch (Throwable ignored) { }
                    saved = -1;
                }
            });
        });
    }
}
