package dev.toasty.client;

import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.minecraft.client.gui.screen.ingame.HandledScreen;

/**
 * Inventare (Spieler-Inventar, Kisten, Ofen, Crafting ...) oeffnen mit der eingestellten GUI-Skalierung (Standard 2), egal was in den Optionen steht.
 * Die Skalierung wird direkt beim Aufbau des Screens gesetzt (vor dem ersten Frame, kein Flackern) und beim Schliessen zurueckgestellt.
 */
public final class ToastyInvScale {
    private static int saved = -1;
    private static boolean guard;

    private ToastyInvScale() {}

    public static void register() {
        ScreenEvents.AFTER_INIT.register((mc, screen, w, h) -> {
            if (guard || !(screen instanceof HandledScreen<?>)) return;
            int want = ToastyConfig.get().invGuiScale;
            if (want <= 0) return;
            var win = mc.getWindow();
            if ((int) win.getScaleFactor() == want) return;
            guard = true;
            long p0 = ToastyProf.begin();
            try {
                if (saved < 0) saved = (int) win.getScaleFactor();
                win.setScaleFactor(want);
                screen.init(win.getScaledWidth(), win.getScaledHeight());
            } catch (Throwable ignored) {
            } finally { guard = false; ToastyProf.end("Inventar-Skalierung", p0); }
            ScreenEvents.remove(screen).register(s -> {
                if (saved > 0 && !(mc.currentScreen instanceof HandledScreen<?> cs && cs != s)) {
                    try { mc.getWindow().setScaleFactor(saved); } catch (Throwable ignored) { }
                    saved = -1;
                }
            });
        });
    }
}
