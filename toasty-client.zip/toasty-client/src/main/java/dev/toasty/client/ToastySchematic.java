package dev.toasty.client;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.registry.Registries;
import net.minecraft.state.property.Property;
import net.minecraft.util.Identifier;

import java.io.IOException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Geladene .litematic. Speichert nur Nicht-Luft-Bloecke als parallele Arrays,
 * Koordinaten relativ zum Schematic-Ursprung (0,0,0 = Litematica-Ursprung).
 */
public final class ToastySchematic {
    public final String name;
    public final BlockState[] palette;
    public final int[] xs, ys, zs, st;
    public final int count;
    public final int minX, minY, minZ, maxX, maxY, maxZ;

    private ToastySchematic(String name, BlockState[] palette, int[] xs, int[] ys, int[] zs, int[] st) {
        this.name = name; this.palette = palette; this.xs = xs; this.ys = ys; this.zs = zs; this.st = st;
        this.count = xs.length;
        int a = Integer.MAX_VALUE, b = a, c = a, d = Integer.MIN_VALUE, e = d, f = d;
        for (int i = 0; i < count; i++) {
            a = Math.min(a, xs[i]); b = Math.min(b, ys[i]); c = Math.min(c, zs[i]);
            d = Math.max(d, xs[i]); e = Math.max(e, ys[i]); f = Math.max(f, zs[i]);
        }
        if (count == 0) { a = b = c = d = e = f = 0; }
        minX = a; minY = b; minZ = c; maxX = d; maxY = e; maxZ = f;
    }

    public static ToastySchematic load(Path file) throws IOException {
        Map<String, Object> root = ToastyNbt.readGzip(file);
        Map<String, Object> regions = ToastyNbt.map(root.get("Regions"));
        if (regions.isEmpty()) throw new IOException("Keine Regionen gefunden (ist das eine .litematic?)");

        Map<BlockState, Integer> pal = new HashMap<>();
        List<BlockState> palList = new ArrayList<>();
        IntList xs = new IntList(), ys = new IntList(), zs = new IntList(), st = new IntList();

        for (Object regObj : regions.values()) {
            Map<String, Object> reg = ToastyNbt.map(regObj);
            Map<String, Object> pos = ToastyNbt.map(reg.get("Position"));
            Map<String, Object> size = ToastyNbt.map(reg.get("Size"));
            int px = ToastyNbt.i(pos.get("x")), py = ToastyNbt.i(pos.get("y")), pz = ToastyNbt.i(pos.get("z"));
            int sx = ToastyNbt.i(size.get("x")), sy = ToastyNbt.i(size.get("y")), sz = ToastyNbt.i(size.get("z"));
            // Negative Groessen: Region geht vom Position-Punkt aus in negative Richtung
            int ox = px + (sx < 0 ? sx + 1 : 0);
            int oy = py + (sy < 0 ? sy + 1 : 0);
            int oz = pz + (sz < 0 ? sz + 1 : 0);
            int ax = Math.abs(sx), ay = Math.abs(sy), az = Math.abs(sz);
            long vol = (long) ax * ay * az;
            if (vol <= 0) continue;

            List<Object> palette = ToastyNbt.list(reg.get("BlockStatePalette"));
            BlockState[] local = new BlockState[palette.size()];
            for (int i = 0; i < local.length; i++) local[i] = parseState(ToastyNbt.map(palette.get(i)));
            Object arrObj = reg.get("BlockStates");
            if (!(arrObj instanceof long[] arr)) continue;
            int bits = Math.max(2, 32 - Integer.numberOfLeadingZeros(Math.max(1, local.length - 1)));
            long mask = (1L << bits) - 1L;

            for (long idx = 0; idx < vol; idx++) {
                long start = idx * bits;
                int si = (int) (start >> 6);
                int ei = (int) (((idx + 1) * bits - 1) >> 6);
                int off = (int) (start & 63);
                if (ei >= arr.length) break;
                int v;
                if (si == ei) v = (int) ((arr[si] >>> off) & mask);
                else v = (int) (((arr[si] >>> off) | (arr[ei] << (64 - off))) & mask);
                if (v <= 0 || v >= local.length) continue;
                BlockState s = local[v];
                if (s.isAir()) continue;
                int x = (int) (idx % ax);
                int z = (int) ((idx / ax) % az);
                int y = (int) (idx / ((long) ax * az));
                Integer pi = pal.get(s);
                if (pi == null) { pi = palList.size(); palList.add(s); pal.put(s, pi); }
                xs.add(ox + x); ys.add(oy + y); zs.add(oz + z); st.add(pi);
            }
        }
        String n = file.getFileName().toString().replaceFirst("\\.litematic$", "");
        return new ToastySchematic(n, palList.toArray(new BlockState[0]), xs.toArray(), ys.toArray(), zs.toArray(), st.toArray());
    }

    static BlockState parseState(Map<String, Object> m) {
        Object n = m.get("Name");
        Identifier id = n instanceof String s ? Identifier.tryParse(s) : null;
        if (id == null) return Blocks.AIR.getDefaultState();
        Block b = Registries.BLOCK.get(id);
        BlockState state = b.getDefaultState();
        for (Map.Entry<String, Object> e : ToastyNbt.map(m.get("Properties")).entrySet()) {
            Property<?> p = b.getStateManager().getProperty(e.getKey());
            if (p != null && e.getValue() instanceof String v) state = with(state, p, v);
        }
        return state;
    }

    private static <T extends Comparable<T>> BlockState with(BlockState s, Property<T> p, String v) {
        return p.parse(v).map(val -> s.with(p, val)).orElse(s);
    }

    private static final class IntList {
        int[] a = new int[1024]; int n;
        void add(int v) { if (n == a.length) a = java.util.Arrays.copyOf(a, n * 2); a[n++] = v; }
        int[] toArray() { return java.util.Arrays.copyOf(a, n); }
    }
}
