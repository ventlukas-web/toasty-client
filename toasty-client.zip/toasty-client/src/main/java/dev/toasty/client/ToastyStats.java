package dev.toasty.client;

import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

/** Session-Statistik aus Sicht des Hauses. */
public class ToastyStats {
    public static long income, payouts;
    public static int rounds, wins, losses;
    public static final Map<String, Long> pending = new LinkedHashMap<>();
    public static String lastPayer;

    public static long profit() { return income - payouts; }
    public static double winrate() { return rounds == 0 ? 0 : 100.0 * wins / rounds; }

    public static void reset() {
        income = payouts = 0; rounds = wins = losses = 0;
        pending.clear(); lastPayer = null;
    }

    private static String trim(double d) {
        return String.format(Locale.ROOT, "%.2f", d).replaceAll("0+$", "").replaceAll("\\.$", "");
    }

    /** 1500 -> 1.5k */
    public static String fmt(long v) {
        double a = Math.abs((double) v);
        if (a >= 1e12) return trim(v / 1e12) + "T";
        if (a >= 1e9) return trim(v / 1e9) + "B";
        if (a >= 1e6) return trim(v / 1e6) + "M";
        if (a >= 1e3) return trim(v / 1e3) + "k";
        return Long.toString(v);
    }
}
