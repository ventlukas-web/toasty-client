package dev.toasty.client;

import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

/** Session-Statistik aus Sicht des Hauses. */
public class ToastyStats {
    public static long income, payouts;
    public static int rounds, wins, losses;
    public static final Map<String, Long> pending = new LinkedHashMap<>();
    public static String lastPayer;
    /** Abgeschlossene Zahlungen (result 1 = bezahlt/gewonnen, 2 = verloren). */
    public record Done(String name, long amount, int result, long at) {}
    public static final java.util.List<Done> done = new java.util.ArrayList<>();
    public static void finish(String name, long amount, boolean win) {
        done.add(new Done(name, amount, win ? 1 : 2, System.currentTimeMillis()));
        if (done.size() > 20) done.remove(0);
    }

    public static long profit() { return income - payouts; }
    public static double winrate() { return rounds == 0 ? 0 : 100.0 * wins / rounds; }

    public static void reset() {
        income = payouts = 0; rounds = wins = losses = 0;
        pending.clear(); done.clear(); lastPayer = null;
    }

    private static String trim(double d) {
        return String.format(Locale.ROOT, "%.2f", d).replaceAll("0+$", "").replaceAll("\\.$", "");
    }

    /** 1500 -> 1.5k */
    public static String fmt(long v) {
        double a = Math.abs((double) v);
        if (a >= 1e12) return trim(v / 1e12) + "T";
        if (a >= 1e9) return trim(v / 1e9) + "B";
        if (a >= 1e6) return trim(v / 1e6) + "M";
        if (a >= 1e3) return trim(v / 1e3) + "k";
        return Long.toString(v);
    }
}
