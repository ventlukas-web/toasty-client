package dev.toasty.client;

import com.mojang.brigadier.arguments.DoubleArgumentType;
import com.mojang.brigadier.arguments.FloatArgumentType;
import com.mojang.brigadier.arguments.LongArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.fabricmc.fabric.api.client.message.v1.ClientSendMessageEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.registry.Registries;
import net.minecraft.sound.SoundEvent;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ToastyGamble implements ClientModInitializer {
    public static final String ID = "toastyclient";
    public static KeyBinding openMenu, calcKey, hudEditKey, glassKey;
    static int pendingScreen = 0;
    private static boolean debugChat = false;

    @Override
    public void onInitializeClient() {
        ToastyTheme.reload(ToastyConfig.get());
        ToastyGlass.register();
        ToastyTitle.register();
        ToastyReconnect.register();
        ToastyPvp.register();
        ToastyCursor.register();
        ToastyInvScale.register();
        ToastyCrosshair.register();

        HudElementRegistry.replaceElement(VanillaHudElements.SCOREBOARD,
            orig -> (ctx, tick) -> ToastyScoreboard.render(ctx, tick, () -> orig.render(ctx, tick)));
        HudElementRegistry.attachElementAfter(VanillaHudElements.MISC_OVERLAYS,
            Identifier.of(ID, "hud"), ToastyHud::render);
        HudElementRegistry.attachElementAfter(VanillaHudElements.MISC_OVERLAYS,
            Identifier.of(ID, "auction"), ToastyAuctionHud::render);
        HudElementRegistry.attachElementAfter(VanillaHudElements.MISC_OVERLAYS,
            Identifier.of(ID, "giveaway"), ToastyGiveawayHud::render);
        ToastyGiveaway.register();
        ToastyChatDrag.register();
        ToastyPrices.register();
        net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents.DISCONNECT.register((h, mc) -> ToastyAuction.pause());
        net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents.JOIN.register((h, sn, mc) -> mc.execute(ToastyAuction::resumeAfterJoin));

        KeyBinding.Category cat = KeyBinding.Category.create(Identifier.of(ID, "main"));
        openMenu = KeyBindingHelper.registerKeyBinding(
            new KeyBinding("key.toastyclient.menu", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, cat));
        calcKey = KeyBindingHelper.registerKeyBinding(
            new KeyBinding("key.toastyclient.calc", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_J, cat));
        hudEditKey = KeyBindingHelper.registerKeyBinding(
            new KeyBinding("key.toastyclient.hudedit", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_UNKNOWN, cat));
        glassKey = KeyBindingHelper.registerKeyBinding(
            new KeyBinding("key.toastyclient.glass", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_UNKNOWN, cat));
        // '#' auf deutscher Tastatur = GLFW BACKSLASH
        ToastyMisc.zoomKey = KeyBindingHelper.registerKeyBinding(
            new KeyBinding("key.toastyclient.zoom", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_C, cat));
        ToastyMisc.fullbrightKey = KeyBindingHelper.registerKeyBinding(
            new KeyBinding("key.toastyclient.fullbright", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_UNKNOWN, cat));
        ToastyMisc.shotKey = KeyBindingHelper.registerKeyBinding(
            new KeyBinding("key.toastyclient.shot", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_F9, cat));

        ClientLifecycleEvents.CLIENT_STARTED.register(c -> {
            ToastyConfig cu = ToastyConfig.get();
            if (!cu.autoUpdateFixed) { cu.autoUpdate = true; cu.autoUpdateFixed = true; cu.save(); }
            ToastyUpdater.start();
            // Inventar-/Button-Design haben keinen Schalter mehr im Menue: nach einem frueheren /toasty lite oder /toasty inventory wieder anschalten
            ToastyConfig cf0 = ToastyConfig.get();
            if (!cf0.invOffDone) { cf0.niceInventory = false; cf0.invOffDone = true; cf0.save(); } // Inventar-Design: aus (einmalig), an mit /toasty inventory
            if (!cf0.niceButtons) { cf0.niceButtons = true; cf0.save(); }
            ToastyPerf.apply(); ToastyMisc.registerSound();
        });
        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            autoAd(mc);
            while (openMenu.wasPressed()) {
                if (mc.currentScreen == null) mc.setScreen(new ToastyMenu(null));
            }
            while (calcKey.wasPressed()) {
                if (mc.currentScreen == null) mc.setScreen(new ToastyCalculatorScreen(null));
            }
            while (hudEditKey.wasPressed()) {
                if (mc.currentScreen == null) mc.setScreen(new ToastyHudEditor(null));
            }
            while (glassKey.wasPressed()) {
                if (mc.currentScreen == null) { ToastyGlass.toggle(); chat("Unsichtbares Glas wird umgeschaltet ..."); }
            }
            long q0 = ToastyProf.begin();
            ToastyMisc.tick(mc);
            ToastyFx.tick(mc);
            ToastyPrices.tick(mc);
            ToastyProf.end("Tick Misc", q0);
            q0 = ToastyProf.begin();
            ToastyEvents.tick();
            ToastySkyLyrics.tick(mc);
            ToastyAuction.tick();
            ToastyGiveaway.tick();
            ToastyProf.end("Tick Events+Death", q0);
            if (pendingScreen == 4) { pendingScreen = 0; mc.setScreen(new ToastyHudEditor(null)); }
            if (pendingScreen == 5) { pendingScreen = 0; mc.setScreen(new ToastyKeysScreen(null)); }
            if (pendingScreen == 1) { pendingScreen = 0; mc.setScreen(new ToastyMenu(null)); }
            if (pendingScreen == 2) { pendingScreen = 0; mc.setScreen(new ToastyCalculatorScreen(null)); }
            if (pendingScreen == 6) { pendingScreen = 0; mc.setScreen(new ToastyTrailerScreen(null)); }
        });
        ToastyMisc.registerEvents();
        ToastyTwitch.start();
        ToastyYoutube.start();

        ClientReceiveMessageEvents.GAME.register((msg, overlay) -> { if (!overlay) onChat(msg.getString()); });
        ClientSendMessageEvents.COMMAND.register(ToastyGamble::onOwnCommand);

        // Wasserzeichen in allen Menues
        ScreenEvents.AFTER_INIT.register((client, screen, w, h) ->
            ScreenEvents.afterRender(screen).register((s, ctx, mx, my, delta) -> {
                if (!ToastyConfig.get().watermark) return;
                var tr = client.textRenderer;
                String label = "Toastentials";
                int lx = s.width - tr.getWidth(label) - 5; // oben rechts: der Chat (unten links) bleibt frei
                ToastyLogo.draw(ctx, lx - 13, 4, 11);
                ToastyTheme.gradientText(ctx, tr, label, lx, 5);
            }));

        ClientCommandRegistrationCallback.EVENT.register((d, reg) -> {
            d.register(ClientCommandManager.literal("werbung").executes(c -> { sendAd(); return 1; })
                .then(ClientCommandManager.literal("auto").executes(c -> { toggleAutoAd(); return 1; })));
            d.register(ClientCommandManager.literal("Werbung").executes(c -> { sendAd(); return 1; }));
            d.register(ClientCommandManager.literal("note")
                .then(ClientCommandManager.literal("add")
                    .then(ClientCommandManager.argument("text", StringArgumentType.greedyString()).executes(c -> {
                        ToastyConfig cf = ToastyConfig.get(); cf.notes.add(StringArgumentType.getString(c, "text").trim()); cf.save();
                        chat("Notiz " + cf.notes.size() + " gespeichert."); return 1;
                    })))
                .then(ClientCommandManager.literal("remove")
                    .then(ClientCommandManager.argument("nr", com.mojang.brigadier.arguments.IntegerArgumentType.integer(1)).executes(c -> {
                        ToastyConfig cf = ToastyConfig.get(); int i = com.mojang.brigadier.arguments.IntegerArgumentType.getInteger(c, "nr") - 1;
                        if (i >= cf.notes.size()) { chat("Keine Notiz " + (i + 1) + "."); return 0; }
                        cf.notes.remove(i); cf.save(); chat("Notiz gelöscht."); return 1;
                    })))
                .then(ClientCommandManager.literal("clear").executes(c -> {
                    ToastyConfig cf = ToastyConfig.get(); cf.notes.clear(); cf.save(); chat("Alle Notizen gelöscht."); return 1;
                }))
                .then(ClientCommandManager.literal("list").executes(c -> {
                    ToastyConfig cf = ToastyConfig.get();
                    if (cf.notes.isEmpty()) { chat("Keine Notizen."); return 1; }
                    for (int i = 0; i < cf.notes.size(); i++) chatLong((i + 1) + ". " + cf.notes.get(i));
                    return 1;
                })));
            d.register(ClientCommandManager.literal("profile")
                .then(ClientCommandManager.literal("list").executes(c -> {
                    var l = ToastyProfiles.list();
                    chatLong(l.isEmpty() ? "Keine Profile gespeichert." : "Profile: " + String.join(", ", l)); return 1;
                }))
                .then(ClientCommandManager.literal("save").then(ClientCommandManager.argument("name", StringArgumentType.word()).executes(c -> {
                    String n = StringArgumentType.getString(c, "name");
                    chat(ToastyProfiles.save(n) ? "Profil \"" + ToastyProfiles.clean(n) + "\" gespeichert." : "Speichern fehlgeschlagen."); return 1;
                })))
                .then(ClientCommandManager.literal("load").then(ClientCommandManager.argument("name", StringArgumentType.word()).executes(c -> {
                    String n = StringArgumentType.getString(c, "name");
                    chat(ToastyProfiles.load(n) ? "Profil \"" + ToastyProfiles.clean(n) + "\" geladen." : "Profil nicht gefunden."); return 1;
                })))
                .then(ClientCommandManager.literal("delete").then(ClientCommandManager.argument("name", StringArgumentType.word()).executes(c -> {
                    chat(ToastyProfiles.delete(StringArgumentType.getString(c, "name")) ? "Profil gelöscht." : "Profil nicht gefunden."); return 1;
                }))));
            d.register(ClientCommandManager.literal("waypoint")
                .then(ClientCommandManager.literal("add")
                    .then(ClientCommandManager.argument("name", StringArgumentType.word())
                        .executes(c -> {
                            String n = StringArgumentType.getString(c, "name");
                            chat(ToastyWaypoints.addHere(n) ? "Wegpunkt \"" + n + "\" gesetzt." : "Nicht möglich."); return 1;
                        })
                        .then(ClientCommandManager.argument("x", com.mojang.brigadier.arguments.IntegerArgumentType.integer())
                            .then(ClientCommandManager.argument("y", com.mojang.brigadier.arguments.IntegerArgumentType.integer())
                                .then(ClientCommandManager.argument("z", com.mojang.brigadier.arguments.IntegerArgumentType.integer()).executes(c -> {
                                    String n = StringArgumentType.getString(c, "name");
                                    boolean ok = ToastyWaypoints.add(n, com.mojang.brigadier.arguments.IntegerArgumentType.getInteger(c, "x"),
                                        com.mojang.brigadier.arguments.IntegerArgumentType.getInteger(c, "y"),
                                        com.mojang.brigadier.arguments.IntegerArgumentType.getInteger(c, "z"));
                                    chat(ok ? "Wegpunkt \"" + n + "\" gesetzt." : "Nicht möglich."); return 1;
                                })))))
                )
                .then(ClientCommandManager.literal("remove").then(ClientCommandManager.argument("name", StringArgumentType.word()).executes(c -> {
                    chat(ToastyWaypoints.remove(StringArgumentType.getString(c, "name")) ? "Wegpunkt gelöscht." : "Wegpunkt nicht gefunden."); return 1;
                })))
                .then(ClientCommandManager.literal("clear").executes(c -> {
                    ToastyConfig cf = ToastyConfig.get(); cf.waypoints.clear(); cf.save(); chat("Alle Wegpunkte gelöscht."); return 1;
                }))
                .then(ClientCommandManager.literal("list").executes(c -> {
                    ToastyConfig cf = ToastyConfig.get();
                    if (cf.waypoints.isEmpty()) { chat("Keine Wegpunkte."); return 1; }
                    for (var w : cf.waypoints) chatLong(w.name + ": " + w.x + " " + w.y + " " + w.z + " (" + w.dim + ")");
                    return 1;
                })));
            d.register(ClientCommandManager.literal("shot")
                .executes(c -> { ToastyMisc.screenshot(true); return 1; })
                .then(ClientCommandManager.literal("hud").executes(c -> { ToastyMisc.screenshot(false); return 1; })));
            d.register(ClientCommandManager.literal("fullbright").executes(c -> {
                ToastyConfig cf = ToastyConfig.get(); cf.fullbright = !cf.fullbright; cf.save();
                chat("Fullbright " + (cf.fullbright ? "an" : "aus")); return 1;
            }));
            d.register(ClientCommandManager.literal("twitch")
                .then(ClientCommandManager.literal("off").executes(c -> {
                    ToastyConfig cf = ToastyConfig.get(); cf.twitch = false; cf.save(); chat("Twitch-Chat aus."); return 1;
                }))
                .then(ClientCommandManager.argument("kanal", StringArgumentType.word()).executes(c -> {
                    ToastyConfig cf = ToastyConfig.get(); cf.twitchChannel = StringArgumentType.getString(c, "kanal"); cf.twitch = true; cf.save();
                    chat("Twitch-Chat: " + cf.twitchChannel); return 1;
                })));
            d.register(ClientCommandManager.literal("youtube")
                .then(ClientCommandManager.literal("off").executes(c -> {
                    ToastyConfig cf = ToastyConfig.get(); cf.youtube = false; cf.save(); chat("YouTube-Chat aus."); return 1;
                }))
                .then(ClientCommandManager.argument("video", StringArgumentType.greedyString()).executes(c -> {
                    ToastyConfig cf = ToastyConfig.get(); cf.youtubeVideo = StringArgumentType.getString(c, "video").trim(); cf.youtube = true; cf.save();
                    chat(cf.youtubeKey.isBlank() ? "Video gesetzt – API-Key fehlt (Menü → YouTube)." : "YouTube-Chat: " + ToastyYoutube.videoId(cf.youtubeVideo)); return 1;
                })));
            ToastyAuctionCmd.register(d);
            ToastyAI.register(d);
            ToastyMusic.register(d);
            ToastyGiveaway.registerCommands(d);
            ToastyPrices.registerCommands(d);
            d.register(ClientCommandManager.literal("stopwatch")
                .executes(c -> { chat(ToastyEvents.stopwatch(ToastyEvents.swRunning() ? "stop" : "start")); return 1; })
                .then(ClientCommandManager.literal("start").executes(c -> { chat(ToastyEvents.stopwatch("start")); return 1; }))
                .then(ClientCommandManager.literal("stop").executes(c -> { chat(ToastyEvents.stopwatch("stop")); return 1; }))
                .then(ClientCommandManager.literal("lap").executes(c -> { chat(ToastyEvents.stopwatch("lap")); return 1; }))
                .then(ClientCommandManager.literal("reset").executes(c -> { chat(ToastyEvents.stopwatch("reset")); return 1; })));
            d.register(ClientCommandManager.literal("timer")
                .then(ClientCommandManager.literal("cancel").executes(c -> { chat(ToastyEvents.cancelTimers() + " Timer gelöscht."); return 1; }))
                .then(ClientCommandManager.argument("sekunden", com.mojang.brigadier.arguments.IntegerArgumentType.integer(1, 86400))
                    .executes(c -> { int s = com.mojang.brigadier.arguments.IntegerArgumentType.getInteger(c, "sekunden"); ToastyEvents.addTimer(s, s + " s"); chat("Timer gestartet: " + s + " s"); return 1; })
                    .then(ClientCommandManager.argument("name", StringArgumentType.greedyString())
                        .executes(c -> { int s = com.mojang.brigadier.arguments.IntegerArgumentType.getInteger(c, "sekunden"); String n = StringArgumentType.getString(c, "name"); ToastyEvents.addTimer(s, n); chat("Timer \"" + n + "\": " + s + " s"); return 1; }))));
            d.register(ClientCommandManager.literal("calc").executes(c -> { pendingScreen = 2; return 1; }));
            d.register(ClientCommandManager.literal("glass").executes(c -> {
                boolean ok = ToastyGlass.toggle();
                chat(ok ? "Unsichtbares Glas wird umgeschaltet ..." : "Glas-Pack nicht gefunden.");
                return ok ? 1 : 0;
            }));
            d.register(ClientCommandManager.literal("toasty")
                .then(ClientCommandManager.literal("menu").executes(c -> { pendingScreen = 1; return 1; }))
                .then(ClientCommandManager.literal("werbung").executes(c -> { sendAd(); return 1; }))
                .then(ClientCommandManager.literal("lag").executes(c -> { for (String ln : ToastyProf.analyze()) chat(ln); return 1; }))
                .then(ClientCommandManager.literal("perf")
                    .executes(c -> { for (String ln : ToastyProf.report()) chat(ln); return 1; })
                    .then(ClientCommandManager.literal("reset").executes(c -> { ToastyProf.reset(); chat("Messung neu gestartet."); return 1; })))
                .then(ClientCommandManager.literal("lite").executes(c -> {
                    ToastyConfig cf = ToastyConfig.get();
                    cf.niceButtons = false; cf.niceInventory = false; cf.hud = false; cf.keystrokes = false; cf.coords = false;
                    cf.moduleList = false; cf.payHud = false; cf.watermark = false; cf.effects = false; cf.confetti = false;
                    cf.save(); chat("Lite-Modus: Designs, HUDs und Effekte aus."); return 1;
                }))
                .then(ClientCommandManager.literal("inventory").executes(c -> { ToastyConfig cf = ToastyConfig.get(); cf.niceInventory = !cf.niceInventory; cf.save(); chat("Inventar-Design: " + (cf.niceInventory ? "AN" : "AUS") + " · Inventare im Toasty-Design gezeichnet: " + ToastyProf.inventoryDraws); return 1; }))
                .then(ClientCommandManager.literal("buttons").executes(c -> { ToastyConfig cf = ToastyConfig.get(); cf.niceButtons = !cf.niceButtons; cf.save(); chat("Button-Design: " + (cf.niceButtons ? "AN" : "AUS") + " · Mixin-Zeichnungen: " + ToastyProf.mixinButtons + " · Fehler: " + ToastyProf.mixinErrors + (ToastyProf.mixinLastError.isEmpty() ? "" : " (" + ToastyProf.mixinLastError + ")")); return 1; }))
                .then(ClientCommandManager.literal("trailer").executes(c -> { pendingScreen = 6; return 1; }))
                .then(ClientCommandManager.literal("hud").executes(c -> { pendingScreen = 4; return 1; }))
                .then(ClientCommandManager.literal("keys").executes(c -> { pendingScreen = 5; return 1; }))
                .then(ClientCommandManager.literal("leak")
                    .then(ClientCommandManager.argument("text", StringArgumentType.greedyString()).executes(c -> {
                        String w = ToastyMisc.leakReason(StringArgumentType.getString(c, "text"));
                        chatLong("Anti-Leak (" + (ToastyConfig.get().antiLeak ? "an" : "AUS") + "): "
                            + (w == null ? "würde durchgehen" : "würde blockieren – " + w));
                        return 1;
                    })))
                .then(ClientCommandManager.literal("scale")
                    .then(ClientCommandManager.argument("wert", FloatArgumentType.floatArg(0.5f, 3f)).executes(c -> {
                        ToastyConfig cfg = ToastyConfig.get(); cfg.hudScale = FloatArgumentType.getFloat(c, "wert"); cfg.save();
                        chat("HUD-Größe " + cfg.hudScale); return 1;
                    })))
            );
        });
    }

    private static int run(String err) {
        if (err != null) { chat(err); return 0; }
        return 1;
    }

    /** Immer als Chat-Nachricht (nicht als Toast), z. B. fuer lange Texte. */
    public static void chatLong(String text) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || text == null) return;
        mc.player.sendMessage(Text.literal("[Toasty] ").formatted(Formatting.LIGHT_PURPLE)
            .append(Text.literal(text).formatted(Formatting.AQUA)), false);
    }

    private static long lastAutoAd = 0;

    /** Automatische Werbung: alle adEverySec Sekunden (Standard 10), solange adAuto an ist und du in einer Welt bist. */
    private static void autoAd(MinecraftClient mc) {
        ToastyConfig c = ToastyConfig.get();
        if (!c.adAuto) { lastAutoAd = 0; return; }
        if (mc.player == null || mc.player.networkHandler == null) return;
        long now = System.currentTimeMillis();
        if (lastAutoAd == 0) { lastAutoAd = now; return; }
        if (now - lastAutoAd < Math.max(1, c.adEverySec) * 1000L) return;
        lastAutoAd = now;
        String ch = c.adChannel != null && !c.adChannel.isBlank() ? c.adChannel.trim() : (c.twitchChannel == null ? "" : c.twitchChannel.trim());
        if (ch.isEmpty()) { c.adAuto = false; c.save(); chat("Auto-Werbung aus: erst einen Twitch-Kanal eintragen."); return; }
        sendAd();
    }

    public static void toggleAutoAd() {
        ToastyConfig c = ToastyConfig.get();
        c.adAuto = !c.adAuto; c.save(); lastAutoAd = 0;
        chat("Auto-Werbung " + (c.adAuto ? "an (alle " + Math.max(1, c.adEverySec) + " s)" : "aus"));
    }

    /** Schickt die Twitch-Werbung (manuell per Knopf/Befehl) in den oeffentlichen Chat, ohne Pause. */
    public static void sendAd() {
        MinecraftClient mc = MinecraftClient.getInstance();
        ToastyConfig c = ToastyConfig.get();
        if (mc.player == null || mc.player.networkHandler == null) { chat("Nicht in einer Welt."); return; }
        String ch = c.adChannel != null && !c.adChannel.isBlank() ? c.adChannel.trim() : (c.twitchChannel == null ? "" : c.twitchChannel.trim());
        if (ch.isEmpty()) { chat("Erst einen Twitch-Kanal eintragen (Streamer-Tab)."); return; }
        String txt = (c.adText == null || c.adText.isBlank() ? "Schaut bei mir auf Twitch vorbei: twitch.tv/{kanal}" : c.adText).replace("{kanal}", ch);
        mc.player.networkHandler.sendChatMessage(txt);
    }

    public static void chat(String text) {
        if (text == null) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;
        if (ToastyConfig.get().notify && text.length() <= 70) {
            ToastyNotify.push("Toastentials", text, ToastyTheme.PURPLE);
            return;
        }
        mc.player.sendMessage(Text.literal("[Toasty] ").formatted(Formatting.LIGHT_PURPLE)
            .append(Text.literal(text).formatted(Formatting.AQUA)), false);
    }

    // ---------- Zahlungen ----------

    private static void onChat(String text) {
        ToastyConfig cfg = ToastyConfig.get();
        Matcher m;
        try { m = Pattern.compile(cfg.pattern).matcher(text); } catch (Exception e) { return; }
        if (!m.find()) return;
        try {
            String suf;
            try { suf = m.group("suffix"); } catch (Exception e) { suf = ""; }
            ToastyAuction.onPayment(m.group("player"), parseAmount(m.group("amount"), suf));
        } catch (Exception e) { }
    }

    /** "1,500" / "2.5" + K/M/B/T -> long. Komma = Tausender, Punkt = Dezimal. */
    static long parseAmount(String num, String suffix) {
        java.math.BigDecimal v = new java.math.BigDecimal(num.replace(",", "").replaceAll("\\.$", ""));
        long f = 1;
        switch (suffix == null ? "" : suffix.toLowerCase()) {
            case "k" -> f = 1_000L;
            case "m" -> f = 1_000_000L;
            case "b" -> f = 1_000_000_000L;
            case "t" -> f = 1_000_000_000_000L;
            default -> {}
        }
        return v.multiply(java.math.BigDecimal.valueOf(f)).longValue();
    }

    private static final Pattern PAY_CMD = Pattern.compile(
        "^pay\\s+(\\.?[A-Za-z0-9_]{1,16})\\s+\\$?([0-9][0-9.,]*\\s*[KkMmBbTt]?)\\s*$", Pattern.CASE_INSENSITIVE);

    /** Eigener "/pay <name> <betrag>": zaehlt als Auszahlung und beendet den offenen Einsatz als Gewinn. */
    private static void onOwnCommand(String cmd) { }

    private static boolean autoPaying;

    private static void promote(String p) {
        var q = ToastyStats.queued.get(p);
        if (q != null) { // naechste wartende Zahlung rueckt nach
            Long nx = q.poll();
            if (q.isEmpty()) ToastyStats.queued.remove(p);
            if (nx != null) {
                ToastyStats.pending.put(p, nx);
                ToastyStats.pendingAt.put(p, System.currentTimeMillis());
                chat("Nächste Zahlung von " + p + ": " + ToastyStats.fmt(nx));
            }
        }
    }

    private static void fixLast(String p) {
        if (p.equals(ToastyStats.lastPayer))
            ToastyStats.lastPayer = ToastyStats.pending.keySet().stream().reduce((a, b) -> b).orElse(null);
    }

    /** Zahlt den Gewinn per /pay aus. */
    private static final java.util.ArrayDeque<Object[]> PAYQ = new java.util.ArrayDeque<>();
    private static long nextPay;

    private static void sendPay(String player, long amount) {
        PAYQ.add(new Object[]{player, amount});
        payTick();
    }

    /** Sendet wartende Auszahlungen mit der eingestellten Pause (Anti-Spam). */
    /** Zufallszahl 1..max (lokal, nur fuer dich sichtbar). */
    private static void roll(int max) {
        int v = java.util.concurrent.ThreadLocalRandom.current().nextInt(1, max + 1);
        int col = v == max ? 0xFF4ADE80 : v == 1 ? 0xFFFB7185 : 0xFF7DD3FC;
        ToastyNotify.push("Roll 1–" + max, String.valueOf(v), col);
        chat("Roll (1–" + max + "): " + v);
    }

    public static void payTick() {
        if (PAYQ.isEmpty()) return;
        long now = System.currentTimeMillis();
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.player.networkHandler == null) { PAYQ.clear(); return; }
        int delay = Math.max(0, ToastyConfig.get().payDelayMs);
        while (!PAYQ.isEmpty() && now >= nextPay) {
            Object[] e = PAYQ.poll();
            String pl = (String) e[0]; long amount = (Long) e[1];
            autoPaying = true;
            try { mc.player.networkHandler.sendChatCommand("pay " + pl + " " + amount); } finally { autoPaying = false; }
            chat("Auszahlung: /pay " + pl + " " + ToastyStats.fmt(amount));
            nextPay = now + delay;
            if (delay > 0) break;
        }
    }

    /** @return Fehlermeldung oder null bei Erfolg */
    public static String settle(String player, boolean win) { return settle(player, win, -1); }

    /** @param mult Auszahlungs-Faktor (<= 0: Standard-Multiplikator aus der Config) */
    public static String settle(String player, boolean win, double mult) {
        if (player != null && (player.equalsIgnoreCase("all") || player.equalsIgnoreCase("alle"))) {
            int n = ToastyStats.pending.size() + ToastyStats.queuedCount();
            if (n == 0) return "Keine offene Zahlung.";
            for (int guard = 0; guard < 10000 && !ToastyStats.pending.isEmpty(); guard++)
                settle(ToastyStats.pending.keySet().iterator().next(), win, mult);
            return n + " Zahlungen abgeschlossen.";
        }
        String p = player != null ? player : ToastyStats.pending.keySet().stream().findFirst().orElse(null); // ohne Namen: der Älteste in der Warteschlange
        if (p != null) for (String k : ToastyStats.pending.keySet())
            if (k.equalsIgnoreCase(p) || k.equalsIgnoreCase("." + p) || ("." + k).equalsIgnoreCase(p)) { p = k; break; }
        Long bet = p == null ? null : ToastyStats.pending.remove(p);
        if (bet == null) return "Keine offene Zahlung" + (p != null ? " von " + p : "") + ".";
        ToastyConfig cfg = ToastyConfig.get();
        ToastyStats.rounds++;
        if (win) {
            long payout = Math.round(bet * (mult > 0 ? mult : cfg.winMultiplier));
            ToastyStats.payouts += payout;
            ToastyStats.wins++;
            ToastyStats.recordRound(p, bet, true, payout);
            ToastyStats.finish(p, payout, true);
            effect(true, p, payout);
            if (cfg.autoPay && payout > 0) sendPay(p, payout);
        } else {
            ToastyStats.losses++;
            ToastyStats.recordRound(p, bet, false, 0);
            ToastyStats.finish(p, bet, false);
            effect(false, p, bet);
        }
        promote(p);
        fixLast(p);
        return null;
    }

    /** /payback [Spieler|all]: zahlt den Einsatz der offenen Zahlung sofort automatisch per /pay zurueck (kein Gewinn/Verlust, keine Runde). */
    public static String payback(String player) {
        if (player != null && (player.equalsIgnoreCase("all") || player.equalsIgnoreCase("alle"))) {
            int n = ToastyStats.pending.size() + ToastyStats.queuedCount();
            if (n == 0) return "Keine offene Zahlung.";
            for (int guard = 0; guard < 10000 && !ToastyStats.pending.isEmpty(); guard++)
                payback(ToastyStats.pending.keySet().iterator().next());
            chat(n + " Zahlungen werden zurückgezahlt.");
            return null;
        }
        String p = player != null ? player : ToastyStats.pending.keySet().stream().findFirst().orElse(null);
        if (p != null) for (String k : ToastyStats.pending.keySet())
            if (k.equalsIgnoreCase(p) || k.equalsIgnoreCase("." + p) || ("." + k).equalsIgnoreCase(p)) { p = k; break; }
        Long bet = p == null ? null : ToastyStats.pending.remove(p);
        if (bet == null) return "Keine offene Zahlung" + (p != null ? " von " + p : "") + ".";
        ToastyStats.recordPayout(p, bet);
        sendPay(p, bet);
        promote(p);
        fixLast(p);
        chat("Zurückgezahlt: " + ToastyStats.fmt(bet) + " an " + p);
        return null;
    }

    private static void effect(boolean win, String player, long amount) {
        ToastyConfig cfg = ToastyConfig.get();
        MinecraftClient mc = MinecraftClient.getInstance();
        ToastyHud.flash(win ? ToastyTheme.GOOD : ToastyTheme.BAD);
        if (cfg.effects) ToastyHud.overlay(win, win ? "GEWONNEN" : "VERLOREN", player + "  ·  " + ToastyStats.fmt(amount));
        if (cfg.sound && mc.player != null) {
            SoundEvent ev = Registries.SOUND_EVENT.get(
                Identifier.of("minecraft", win ? "entity.player.levelup" : "entity.villager.no"));
            if (ev != null) mc.player.playSound(ev, 1.0f, 1.0f);
        }
    }
}
