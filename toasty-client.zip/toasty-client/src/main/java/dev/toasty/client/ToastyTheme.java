package dev.toasty.client;

import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

/** Lila / Hellblau Design. */
public final class ToastyTheme {
    /** Hauptfarbe (Standard Lila) und Zweitfarbe (Standard Hellblau) - einstellbar im Design-Tab. */
    public static int PURPLE = 0xFFA855F7;
    public static int BLUE = 0xFF7DD3FC;
    public static int BG = 0xD0140B2B;
    public static final int TEXT = 0xFFF3EEFF;
    public static final int MUTED = 0xFFB8B5E6;
    public static final int GOOD = 0xFF86EFAC;
    public static final int BAD = 0xFFFDA4AF;

    private ToastyTheme() {}

    /** "#RRGGBB" (mit oder ohne #) -> ARGB, sonst null. */
    public static Integer parseHex(String s) {
        if (s == null) return null;
        s = s.trim();
        if (s.startsWith("#")) s = s.substring(1);
        if (!s.matches("[0-9a-fA-F]{6}")) return null;
        return 0xFF000000 | Integer.parseInt(s, 16);
    }

    public static String toHex(int argb) { return String.format("#%06X", argb & 0xFFFFFF); }

    public static void reload(ToastyConfig c) {
        Integer a = parseHex(c.color1), b = parseHex(c.color2);
        if (a != null) PURPLE = a;
        if (b != null) BLUE = b;
        int op = Math.max(32, Math.min(255, c.bgOpacity));
        BG = alpha(lerp(0xFF0A0614, PURPLE, 0.10f), op);
    }

    /** Hintergrundfarbe mit relativer Deckkraft (a = 0..255 bei voller Einstellung). */
    public static int bgA(int a) {
        return alpha(BG, ((BG >>> 24) * a) / 255);
    }

    public static int lerp(int a, int b, float t) {
        int r = 0;
        for (int s = 24; s >= 0; s -= 8) {
            int ca = (a >> s) & 0xFF, cb = (b >> s) & 0xFF;
            r |= ((int) (ca + (cb - ca) * t) & 0xFF) << s;
        }
        return r;
    }

    public static int alpha(int color, int a) {
        return (color & 0xFFFFFF) | ((Math.max(0, Math.min(255, a))) << 24);
    }

    public static void hGradient(DrawContext ctx, int x, int y, int w, int h, int c1, int c2) {
        for (int i = 0; i < w; i++) {
            ctx.fill(x + i, y, x + i + 1, y + h, lerp(c1, c2, w <= 1 ? 0 : (float) i / (w - 1)));
        }
    }

    // ---------- Runde Ecken ----------

    private static int inset(int d, int r) {
        double dy = r - (d + 0.5);
        double dx = Math.sqrt(Math.max(0, (double) r * r - dy * dy));
        return (int) Math.round(r - dx);
    }

    public static void roundRect(DrawContext ctx, int x, int y, int w, int h, int r, int color) {
        r = Math.max(0, Math.min(r, Math.min(w, h) / 2));
        for (int i = 0; i < r; i++) {
            int ins = inset(i, r);
            ctx.fill(x + ins, y + i, x + w - ins, y + i + 1, color);
            ctx.fill(x + ins, y + h - 1 - i, x + w - ins, y + h - i, color);
        }
        ctx.fill(x, y + r, x + w, y + h - r, color);
    }

    public static void roundOutline(DrawContext ctx, int x, int y, int w, int h, int r, int c) {
        r = Math.max(0, Math.min(r, Math.min(w, h) / 2));
        for (int i = 0; i < r; i++) {
            int ins = inset(i, r);
            if (i == 0) {
                ctx.fill(x + ins, y, x + w - ins, y + 1, c);
                ctx.fill(x + ins, y + h - 1, x + w - ins, y + h, c);
            } else {
                int span = Math.max(ins + 1, inset(i - 1, r));
                ctx.fill(x + ins, y + i, x + span, y + i + 1, c);
                ctx.fill(x + w - span, y + i, x + w - ins, y + i + 1, c);
                ctx.fill(x + ins, y + h - 1 - i, x + span, y + h - i, c);
                ctx.fill(x + w - span, y + h - 1 - i, x + w - ins, y + h - i, c);
            }
        }
        ctx.fill(x, y + r, x + 1, y + h - r, c);
        ctx.fill(x + w - 1, y + r, x + w, y + h - r, c);
    }

    public static void panel(DrawContext ctx, int x, int y, int w, int h) {
        roundRect(ctx, x, y, w, h, 6, BG);
        roundOutline(ctx, x, y, w, h, 6, alpha(lerp(PURPLE, BLUE, 0.5f), 0xC0));
        hGradient(ctx, x + 8, y + 1, Math.max(1, w - 16), 2, PURPLE, BLUE);
    }

    /** Text mit Farbverlauf (Lila -> Hellblau), Rueckgabe = Breite. */
    public static int gradientText(DrawContext ctx, TextRenderer tr, String s, int x, int y) {
        int cx = x, n = Math.max(1, s.length() - 1);
        for (int i = 0; i < s.length(); i++) {
            String ch = String.valueOf(s.charAt(i));
            ctx.drawTextWithShadow(tr, ch, cx, y, lerp(PURPLE, BLUE, (float) i / n));
            cx += tr.getWidth(ch);
        }
        return cx - x;
    }

    public static int gradientWidth(TextRenderer tr, String s) { return tr.getWidth(s); }
}
