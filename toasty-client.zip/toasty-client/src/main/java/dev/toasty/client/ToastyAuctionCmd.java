package dev.toasty.client;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

/** Auktions-Befehle wie im Floons Client: /action, /auction und /toasty auction. */
public final class ToastyAuctionCmd {
    private ToastyAuctionCmd() {}

    public static void register(CommandDispatcher<FabricClientCommandSource> d) {
        d.register(auctionCommand("action"));
        d.register(auctionCommand("auction"));
        d.register(ClientCommandManager.literal("toasty").then(auctionCommand("auction"))
            .then(ClientCommandManager.literal("update")
                .executes(c -> { ToastyUpdater.checkNow(); ToastyAuction.info("Update: prüfe GitHub … Ergebnis mit /toasty update status"); return 1; })
                .then(ClientCommandManager.literal("status").executes(c -> { ToastyAuction.info("Update: " + ToastyUpdater.status + "  (Log: config/toasty-update.log)"); return 1; }))));
    }

    private static int ok(String err) {
        if (err != null) { ToastyAuction.info(err); return 0; }
        return 1;
    }

    private static LiteralArgumentBuilder<FabricClientCommandSource> auctionCommand(String name) {
        return ClientCommandManager.literal(name)
            .executes(c -> { help(); return 1; })
            .then(ClientCommandManager.literal("start")
                .then(ClientCommandManager.argument("startgebot", StringArgumentType.word())
                    .then(ClientCommandManager.argument("dauer", StringArgumentType.word())
                        .then(ClientCommandManager.argument("item", StringArgumentType.greedyString()).executes(c -> {
                            long st = ToastyAuction.parseInput(StringArgumentType.getString(c, "startgebot"));
                            int sec = ToastyAuction.parseDuration(StringArgumentType.getString(c, "dauer"));
                            if (st < 0) return ok("Startgebot ungültig (z. B. 500k, 1.5m, 2000).");
                            if (sec < 0) return ok("Dauer ungültig (z. B. 90, 90s, 2m, 1m30s).");
                            return ok(ToastyAuction.start(StringArgumentType.getString(c, "item"), st, sec));
                        })))))
            .then(ClientCommandManager.literal("hand")
                .then(ClientCommandManager.argument("startgebot", StringArgumentType.word())
                    .then(ClientCommandManager.argument("dauer", StringArgumentType.word()).executes(c -> {
                        var p = net.minecraft.client.MinecraftClient.getInstance().player;
                        if (p == null || p.getMainHandStack().isEmpty()) return ok("Du hältst kein Item in der Hand.");
                        long st = ToastyAuction.parseInput(StringArgumentType.getString(c, "startgebot"));
                        int sec = ToastyAuction.parseDuration(StringArgumentType.getString(c, "dauer"));
                        if (st < 0) return ok("Startgebot ungültig (z. B. 500k, 1.5m, 2000).");
                        if (sec < 0) return ok("Dauer ungültig (z. B. 90, 90s, 2m, 1m30s).");
                        return ok(ToastyAuction.start(ToastyItemPicker.describe(p.getMainHandStack()), st, sec));
                    }))))
            .then(ClientCommandManager.literal("end").executes(c -> ok(ToastyAuction.end(false))))
            .then(ClientCommandManager.literal("cancel").executes(c -> ok(ToastyAuction.end(true))))
            .then(ClientCommandManager.literal("extend")
                .then(ClientCommandManager.argument("sekunden", IntegerArgumentType.integer(1, 3600))
                    .executes(c -> ok(ToastyAuction.extend(IntegerArgumentType.getInteger(c, "sekunden"))))))
            .then(ClientCommandManager.literal("refund").executes(c -> { ToastyAuction.refundList(); return 1; }))
            .then(ClientCommandManager.literal("reset")
                .executes(c -> ok(ToastyAuction.reset()))
                .then(ClientCommandManager.literal("bids").executes(c -> ok(ToastyAuction.resetBids())))
                .then(ClientCommandManager.argument("spieler", StringArgumentType.word()).executes(c -> ok(ToastyAuction.resetPlayer(StringArgumentType.getString(c, "spieler"))))))
            .then(ClientCommandManager.literal("pause").executes(c -> ok(ToastyAuction.pauseManual())))
            .then(ClientCommandManager.literal("resume").executes(c -> ok(ToastyAuction.resumeManual())))
            .then(ClientCommandManager.literal("stats").executes(c -> { ToastyAuction.stats(); return 1; }))
            .then(ClientCommandManager.literal("buynow")
                .then(ClientCommandManager.argument("betrag", StringArgumentType.word()).executes(c -> ok(setPrice(StringArgumentType.getString(c, "betrag"), true)))))
            .then(ClientCommandManager.literal("reserve")
                .then(ClientCommandManager.argument("betrag", StringArgumentType.word()).executes(c -> ok(setPrice(StringArgumentType.getString(c, "betrag"), false)))))
            .then(ClientCommandManager.literal("queue")
                .executes(c -> { queueList(); return 1; })
                .then(ClientCommandManager.literal("list").executes(c -> { queueList(); return 1; }))
                .then(ClientCommandManager.literal("clear").executes(c -> { int n = ToastyAuction.queue.size(); ToastyAuction.queue.clear(); return ok(n + " Auktionen aus der Warteschlange entfernt."); }))
                .then(ClientCommandManager.literal("next").executes(c -> ok(ToastyAuction.startNext())))
                .then(ClientCommandManager.literal("remove")
                    .then(ClientCommandManager.argument("nr", IntegerArgumentType.integer(1)).executes(c -> {
                        int i = IntegerArgumentType.getInteger(c, "nr") - 1;
                        if (i >= ToastyAuction.queue.size()) return ok("Keine Auktion Nr. " + (i + 1) + ".");
                        ToastyAuction.queue.remove(i); return ok("Entfernt.");
                    })))
                .then(ClientCommandManager.literal("add")
                    .then(ClientCommandManager.argument("startgebot", StringArgumentType.word())
                        .then(ClientCommandManager.argument("dauer", StringArgumentType.word())
                            .then(ClientCommandManager.argument("item", StringArgumentType.greedyString()).executes(c -> {
                                long st = ToastyAuction.parseInput(StringArgumentType.getString(c, "startgebot"));
                                int sec = ToastyAuction.parseDuration(StringArgumentType.getString(c, "dauer"));
                                if (st < 0) return ok("Startgebot ungültig (z. B. 500k, 1.5m, 2000).");
                                if (sec < 5) return ok("Dauer ungültig (mindestens 5 Sekunden, z. B. 90s, 2m).");
                                String it = StringArgumentType.getString(c, "item");
                                ToastyAuction.queue.add(new ToastyAuction.Queued(it, st, sec, 0, 0));
                                return ok("In der Warteschlange (" + ToastyAuction.queue.size() + "): " + it);
                            }))))))
            .then(ClientCommandManager.literal("status").executes(c -> { status(); return 1; }))
            .then(ClientCommandManager.literal("history").executes(c -> { history(); return 1; }))
            .then(ClientCommandManager.literal("test")
                .then(ClientCommandManager.argument("spieler", StringArgumentType.word())
                    .then(ClientCommandManager.argument("betrag", StringArgumentType.word()).executes(c -> {
                        long v = ToastyAuction.parseInput(StringArgumentType.getString(c, "betrag"));
                        if (v <= 0) return ok("Betrag ungültig.");
                        if (!ToastyAuction.onPayment(StringArgumentType.getString(c, "spieler"), v)) return ok("Keine Auktion aktiv.");
                        return 1;
                    }))));
    }

    /** /action buynow|reserve <betrag|aus>: gilt für die laufende Auktion, sonst für die nächste. */
    private static String setPrice(String raw, boolean buy) {
        long v = raw.equalsIgnoreCase("aus") || raw.equalsIgnoreCase("off") ? 0 : ToastyAuction.parseInput(raw);
        if (v < 0) return "Betrag ungültig (z. B. 5m oder aus).";
        String what = buy ? "Sofortkauf" : "Mindestpreis";
        if (ToastyAuction.active) {
            if (buy) ToastyAuction.buyNow = v; else ToastyAuction.reserve = v;
            if (buy && v > 0) ToastyAuction.say("[Auktion] Sofortkauf für " + ToastyAuction.item + ": " + ToastyAuction.fmt(v));
            return what + (v > 0 ? ": " + ToastyAuction.fmt(v) : " aus") + " (laufende Auktion).";
        }
        if (buy) ToastyAuction.nextBuyNow = v; else ToastyAuction.nextReserve = v;
        return what + (v > 0 ? ": " + ToastyAuction.fmt(v) : " aus") + " (gilt für die nächste Auktion).";
    }

    private static void queueList() {
        if (ToastyAuction.queue.isEmpty()) { ToastyAuction.info("Warteschlange ist leer. /action queue add <start> <dauer> <item>"); return; }
        int i = 1;
        for (ToastyAuction.Queued q : ToastyAuction.queue)
            ToastyAuction.info((i++) + ". " + q.item() + "  ·  Start " + ToastyAuction.fmt(q.start()) + "  ·  " + ToastyAuction.mmss(q.sec() * 1000L));
    }

    private static void help() {
        ToastyAuction.info("/action start <startgebot> <dauer> <item>  – z. B. /action start 500k 2m Elytra");
        ToastyAuction.info("Gleich: /auction … und /toasty auction … (z. B. /action hand 500k 2m)");
        ToastyAuction.info("/action end | cancel | extend <s> | pause | resume | status | refund | history | stats");
        ToastyAuction.info("/action buynow <betrag|aus> | reserve <betrag|aus> | queue add <start> <dauer> <item> | queue list|next|remove <nr>|clear");
        ToastyAuction.info("/action test <spieler> <betrag> – Gebot simulieren (kein Geld)");
        ToastyAuction.info("Mod-Menü (Rechte Shift) → Streaming → Auktion");
    }

    private static void status() {
        if (!ToastyAuction.active) { ToastyAuction.info("Keine Auktion aktiv."); return; }
        ToastyAuction.info(ToastyAuction.item + " | noch " + ToastyAuction.mmss(ToastyAuction.left()) + (ToastyAuction.paused ? " (Pause)" : "")
            + " | " + (ToastyAuction.bestName == null ? "kein Gebot" : ToastyAuction.fmt(ToastyAuction.best) + " von " + ToastyAuction.bestName)
            + " | " + ToastyAuction.bids.size() + " Bieter");
    }

    private static void history() {
        List<ToastyAuction.Entry> h = ToastyAuction.history();
        if (h.isEmpty()) { ToastyAuction.info("Noch keine Auktionen."); return; }
        SimpleDateFormat f = new SimpleDateFormat("dd.MM. HH:mm");
        long sum = 0;
        for (ToastyAuction.Entry e : h) sum += e.amount;
        ToastyAuction.info("Letzte Auktionen (" + h.size() + ", Erlös gesamt " + ToastyAuction.fmt(sum) + "):");
        for (int i = 0; i < Math.min(10, h.size()); i++) {
            ToastyAuction.Entry e = h.get(i);
            ToastyAuction.info(f.format(new Date(e.time)) + "  " + e.item + " → "
                + (e.winner == null ? "keine Gebote" : e.winner + " " + ToastyAuction.fmt(e.amount)) + "  (" + e.bidders + " Bieter)");
        }
    }

}
