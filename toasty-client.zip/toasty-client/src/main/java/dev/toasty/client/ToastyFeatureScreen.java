package dev.toasty.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

import java.util.Set;
import java.util.function.Consumer;
import java.util.function.Supplier;

/** Rechtsklick auf ein Feature im Mod-Menue: weitere Einstellungen zu genau diesem Feature. */
public class ToastyFeatureScreen extends ToastyScreen {
    private static final int PW = 280;
    private static final Set<String> HUDS = Set.of("Stats-HUD", "Keystrokes", "Koordinaten", "FPS", "Ping", "Speed", "Uhrzeit", "Modul-Liste",
        "CPS-Anzeige", "Reach-Anzeige", "Item-Zähler", "Combo-Zähler", "Armor-Haltbarkeit", "Effekte",
        "Status (Leben/Hunger)", "Saturation-Rand", "Treffer-Marker", "Cooldown-Balken", "Low-HP-Warnung");

    private final Screen parent;
    private final String name;
    private final Supplier<Boolean> get;
    private final Consumer<Boolean> set;
    private int left, top, bottom;
    private final java.util.List<String> info = new java.util.ArrayList<>();

    public ToastyFeatureScreen(Screen parent, String name, Supplier<Boolean> get, Consumer<Boolean> set) {
        super(Text.literal(name));
        this.parent = parent; this.name = name; this.get = get; this.set = set;
    }

    @Override
    protected void build() {
        info.clear();
        ToastyConfig c = ToastyConfig.get();
        left = width / 2 - PW / 2;
        top = Math.max(24, height / 2 - 90);
        int y = top + 30;
        button(() -> name + ": " + (get.get() ? "AN" : "AUS"), () -> set.accept(!get.get()), left, y, PW, 22, true);
        y += 30;
        boolean any = false;
        if (HUDS.contains(name) || name.endsWith("HUD") || name.endsWith("-HUD")) {
            any = true;
            button(() -> "-", () -> { c.hudScale = Math.max(0.5f, Math.round((c.hudScale - 0.1f) * 10) / 10f); c.save(); }, left, y, 30, 20);
            button(() -> "HUD-Größe: " + Math.round(c.hudScale * 100) + " %", () -> {}, left + 34, y, PW - 68, 20);
            button(() -> "+", () -> { c.hudScale = Math.min(2.0f, Math.round((c.hudScale + 0.1f) * 10) / 10f); c.save(); }, left + PW - 30, y, 30, 20);
            y += 24;
            button(() -> "HUD verschieben …", () -> MinecraftClient.getInstance().setScreen(new ToastyHudEditor(this)), left, y, PW, 20, true);
            y += 24;
            button(() -> "Alle HUD-Positionen zurücksetzen", () -> { c.hudPos.clear(); c.save(); }, left, y, PW, 20);
            y += 24;
        }
        if (name.equals("Auto-Reconnect")) {
            any = true;
            button(() -> "Pause vor Reconnect: " + c.reconnectSec + " s", () -> {
                int[] st = {3, 5, 10, 30};
                int n = st[0];
                for (int i = 0; i < st.length; i++) if (st[i] == c.reconnectSec) { n = st[(i + 1) % st.length]; break; }
                c.reconnectSec = n; c.save();
            }, left, y, PW, 20);
            y += 24;
        }
        if (name.equals("Treffer-Sound")) {
            any = true;
            button(() -> "Sound: " + ToastyPvp.SOUNDS[Math.floorMod(c.hitSoundIdx, ToastyPvp.SOUNDS.length)][0], () -> {
                c.hitSoundIdx = (c.hitSoundIdx + 1) % ToastyPvp.SOUNDS.length; c.save(); ToastyPvp.playHit();
            }, left, y, PW - 100, 20, true);
            button(() -> "Test", ToastyPvp::playHit, left + PW - 96, y, 96, 20);
            y += 24;
        }
        if (!any) { info.add("Für dieses Feature gibt es nur AN/AUS."); y += 14; }
        button(() -> "Zurück", this::close, left, y + 6, PW, 20);
        bottom = y + 6 + 20 + 12;
    }

    @Override
    public void renderBackground(DrawContext ctx, int mouseX, int mouseY, float delta) {
        ctx.fill(0, 0, width, height, 0x99000000);
        ToastyTheme.panel(ctx, left - 14, top - 8, PW + 28, bottom - top + 8, 0xFF);
        ToastyTheme.gradientText(ctx, textRenderer, name, left, top + 4);
    }

    @Override
    protected void extra(DrawContext ctx, int mouseX, int mouseY) {
        int y = top + 66;
        for (String s : info) { ctx.drawTextWithShadow(textRenderer, ToastyTheme.ui(s), left, y, ToastyTheme.MUTED); y += 11; }
        String hint = "Einstellungen zu diesem Feature";
        ctx.drawTextWithShadow(textRenderer, ToastyTheme.ui(hint), left + PW - textRenderer.getWidth(ToastyTheme.ui(hint)), top + 4, ToastyTheme.MUTED);
    }

    @Override
    public boolean shouldPause() { return false; }

    @Override
    public void close() { MinecraftClient.getInstance().setScreen(parent); }
}
