package dev.toasty.client.mixin;

import dev.toasty.client.ToastyConfig;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.client.render.entity.state.LivingEntityRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Map;
import java.util.WeakHashMap;

/** Treffer-Bounce: getroffene Lebewesen federn kurz (gedaempfte Feder) in die Hoehe und zurueck. Unabhaengig vom Skelett. */
@Mixin(LivingEntityRenderer.class)
public abstract class HitBounceMixin {
    private static final Map<Object, Float> BOUNCE = new WeakHashMap<>();

    @Inject(method = "updateRenderState(Lnet/minecraft/entity/LivingEntity;Lnet/minecraft/client/render/entity/state/LivingEntityRenderState;F)V", at = @At("RETURN"), require = 0)
    private void toasty$bounceState(LivingEntity entity, LivingEntityRenderState state, float tickDelta, CallbackInfo ci) {
        try {
            float bn = 0f;
            if (ToastyConfig.get().hitBounce && entity.hurtTime > 0) {
                double ht = Math.min(1.0, Math.max(0.0, (10.0 - (entity.hurtTime - tickDelta)) / 10.0));
                bn = (float) (Math.exp(-3.2 * ht) * Math.cos(ht * 13.0));
            }
            if (bn != 0f) BOUNCE.put(state, bn); else BOUNCE.remove(state);
        } catch (Throwable ignored) {}
    }

    @Inject(method = "scale(Lnet/minecraft/client/render/entity/state/LivingEntityRenderState;Lnet/minecraft/client/util/math/MatrixStack;)V", at = @At("RETURN"), require = 0)
    private void toasty$bounceScale(LivingEntityRenderState state, MatrixStack matrices, CallbackInfo ci) {
        try {
            Float bn = BOUNCE.get(state);
            if (bn == null) return;
            matrices.scale(1f - 0.09f * bn, 1f + 0.13f * bn, 1f - 0.09f * bn);
        } catch (Throwable ignored) {}
    }
}
