package dev.toasty.client;

import net.minecraft.client.gui.DrawContext;

/** Toasty-Logo: lila-blaue Plakette mit lachendem Toast. Wird komplett per Code gezeichnet (skaliert scharf). */
public final class ToastyLogo {
    private static final int TOAST = 0xFFFDE7B5, CRUST = 0xFFE9B96E;

    private ToastyLogo() {}

    public static void draw(DrawContext ctx, int x, int y, int s) {
        if (s < 8) return;
        int r = s * 22 / 100;
        int g = Math.max(1, s / 12);   // weicher Schein hinter der Plakette
        ToastyTheme.roundRectExact(ctx, x - g, y - g, s + 2 * g, s + 2 * g, r + g, ToastyTheme.alpha(ToastyTheme.PURPLE, 0x30));
        ToastyTheme.roundRectExact(ctx, x, y, s, s, r, ToastyTheme.BLUE);
        ToastyTheme.roundRectExact(ctx, x, y, s * 72 / 100, s * 72 / 100, r, ToastyTheme.alpha(ToastyTheme.PURPLE, 0xC8));
        ToastyTheme.roundRectExact(ctx, x, y, s * 46 / 100, s * 46 / 100, r, ToastyTheme.alpha(ToastyTheme.PURPLE, 0x90));
        ToastyTheme.roundRectExact(ctx, x + s / 14, y + s / 16, s - s / 7, s * 38 / 100, r, ToastyTheme.alpha(0xFFFFFFFF, 0x24)); // Glanz oben
        ToastyTheme.roundOutlineExact(ctx, x, y, s, s, r, ToastyTheme.alpha(0xFFFFFFFF, 0x60));
        ToastyTheme.roundOutlineExact(ctx, x + 1, y + 1, s - 2, s - 2, Math.max(1, r - 1), ToastyTheme.alpha(0xFFFFFFFF, 0x18));

        int tx = x + s * 20 / 100, tw = s * 60 / 100;
        int ty = y + s * 32 / 100, th = s * 48 / 100;
        int br = s * 11 / 100;
        // Kruste (leicht groesser, dahinter)
        int c = Math.max(1, s / 36);
        ToastyTheme.roundRectExact(ctx, tx - c, ty - c, tw + 2 * c, th + 2 * c, br + c, CRUST);
        ToastyTheme.roundRectExact(ctx, tx - c - s * 2 / 100, y + s * 20 / 100 - c, s * 31 / 100 + 2 * c, s * 24 / 100 + 2 * c, s * 12 / 100, CRUST);
        ToastyTheme.roundRectExact(ctx, tx + tw - s * 29 / 100 - c, y + s * 20 / 100 - c, s * 31 / 100 + 2 * c, s * 24 / 100 + 2 * c, s * 12 / 100, CRUST);
        // Toast
        ToastyTheme.roundRectExact(ctx, tx, ty, tw, th, br, TOAST);
        ToastyTheme.roundRectExact(ctx, tx - s * 2 / 100, y + s * 20 / 100, s * 31 / 100, s * 24 / 100, s * 11 / 100, TOAST);
        ToastyTheme.roundRectExact(ctx, tx + tw - s * 29 / 100, y + s * 20 / 100, s * 31 / 100, s * 24 / 100, s * 11 / 100, TOAST);
        // Details: Schatten, Lichtkante, goldener Verlauf, Butter, Funkeln
        ToastyTheme.roundRectExact(ctx, tx + s * 4 / 100, ty + th - s * 9 / 100, tw - s * 8 / 100, s * 8 / 100, s * 4 / 100, ToastyTheme.alpha(0xFFE9B96E, 0x90));   // dunkler Boden
        ToastyTheme.roundRectExact(ctx, tx + s * 5 / 100, ty + s * 3 / 100, tw / 2, Math.max(2, s * 4 / 100), Math.max(1, s * 2 / 100), ToastyTheme.alpha(0xFFFFFFFF, 0xB0)); // Lichtkante
        int bx = tx + tw * 62 / 100, by = ty + s * 5 / 100, bw2 = s * 17 / 100, bh2 = s * 9 / 100;
        ToastyTheme.roundRectExact(ctx, bx, by, bw2, bh2, Math.max(1, s * 3 / 100), 0xFFFFE066);   // Butterstueck
        ToastyTheme.roundRectExact(ctx, bx + 1, by + 1, bw2 - 2, Math.max(1, bh2 / 3), 1, ToastyTheme.alpha(0xFFFFFFFF, 0x90));
        int sp = Math.max(2, s * 7 / 100), sx = x + s * 82 / 100, sy = y + s * 12 / 100;   // Funkeln (4-Strahl)
        ctx.fill(sx - sp, sy, sx + sp + 1, sy + 1, 0xFFFFFFFF);
        ctx.fill(sx, sy - sp, sx + 1, sy + sp + 1, 0xFFFFFFFF);
        int sp2 = Math.max(1, sp / 2), sx2 = x + s * 14 / 100, sy2 = y + s * 84 / 100;
        ctx.fill(sx2 - sp2, sy2, sx2 + sp2 + 1, sy2 + 1, ToastyTheme.alpha(0xFFFFFFFF, 0xC0));
        ctx.fill(sx2, sy2 - sp2, sx2 + 1, sy2 + sp2 + 1, ToastyTheme.alpha(0xFFFFFFFF, 0xC0));
        // Gesicht
        int ew = Math.max(2, s * 9 / 100), eh = Math.max(3, s * 13 / 100);
        int ey = ty + th * 22 / 100;
        int dark = 0xFF120826;
        int ex1 = tx + tw * 27 / 100 - ew / 2, ex2 = tx + tw * 73 / 100 - ew / 2;
        ToastyTheme.roundRectExact(ctx, ex1, ey, ew, eh, ew / 2, dark);
        ToastyTheme.roundRectExact(ctx, ex2, ey, ew, eh, ew / 2, dark);
        int sh = Math.max(1, ew / 3);   // Glanzpunkte
        ctx.fill(ex1 + ew / 4, ey + eh / 6, ex1 + ew / 4 + sh, ey + eh / 6 + sh, 0xFFFFFFFF);
        ctx.fill(ex2 + ew / 4, ey + eh / 6, ex2 + ew / 4 + sh, ey + eh / 6 + sh, 0xFFFFFFFF);
        // Wangen
        int cw = Math.max(2, s * 9 / 100), ch = Math.max(2, s * 5 / 100), cy = ey + eh + s * 2 / 100;
        ToastyTheme.roundRectExact(ctx, tx + tw * 12 / 100, cy, cw, ch, ch / 2, ToastyTheme.alpha(0xFFFB7185, 0xA0));
        ToastyTheme.roundRectExact(ctx, tx + tw * 88 / 100 - cw, cy, cw, ch, ch / 2, ToastyTheme.alpha(0xFFFB7185, 0xA0));
        // Mund: grosses Laecheln
        int mw = tw * 42 / 100, mh = Math.max(4, s * 12 / 100);
        int mxx = tx + (tw - mw) / 2, myy = ey + eh + s * 3 / 100;
        ToastyTheme.roundRectExact(ctx, mxx, myy, mw, mh, mh / 2 + 1, dark);
        ToastyTheme.roundRectExact(ctx, mxx + mw / 5, myy + mh * 55 / 100, mw * 3 / 5, Math.max(1, mh * 40 / 100), Math.max(1, mh / 5), 0xFFFB7185);
    }
}
