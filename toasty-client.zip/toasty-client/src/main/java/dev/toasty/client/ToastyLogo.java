package dev.toasty.client;

import net.minecraft.client.gui.DrawContext;

/** Toasty-Logo: lila-blaue Plakette mit lachendem Toast. Wird komplett per Code gezeichnet (skaliert scharf). */
public final class ToastyLogo {
    private static final int TOAST = 0xFFFDE7B5, CRUST = 0xFFE9B96E;

    private ToastyLogo() {}

    public static void draw(DrawContext ctx, int x, int y, int s) {
        if (s < 8) return;
        int r = s * 22 / 100;
        ToastyTheme.roundRectExact(ctx, x, y, s, s, r, ToastyTheme.PURPLE);
        ToastyTheme.roundRectExact(ctx, x + s * 30 / 100, y + s * 30 / 100, s * 70 / 100, s * 70 / 100, r, ToastyTheme.alpha(ToastyTheme.BLUE, 0xB0));
        ToastyTheme.roundOutlineExact(ctx, x, y, s, s, r, ToastyTheme.alpha(0xFFFFFFFF, 0x70));

        int tx = x + s * 20 / 100, tw = s * 60 / 100;
        int ty = y + s * 32 / 100, th = s * 48 / 100;
        int br = s * 11 / 100;
        // Kruste (leicht groesser, dahinter)
        int c = Math.max(1, s / 36);
        ToastyTheme.roundRectExact(ctx, tx - c, ty - c, tw + 2 * c, th + 2 * c, br + c, CRUST);
        ToastyTheme.roundRectExact(ctx, tx - c - s * 2 / 100, y + s * 20 / 100 - c, s * 31 / 100 + 2 * c, s * 24 / 100 + 2 * c, s * 12 / 100, CRUST);
        ToastyTheme.roundRectExact(ctx, tx + tw - s * 29 / 100 - c, y + s * 20 / 100 - c, s * 31 / 100 + 2 * c, s * 24 / 100 + 2 * c, s * 12 / 100, CRUST);
        // Toast
        ToastyTheme.roundRectExact(ctx, tx, ty, tw, th, br, TOAST);
        ToastyTheme.roundRectExact(ctx, tx - s * 2 / 100, y + s * 20 / 100, s * 31 / 100, s * 24 / 100, s * 11 / 100, TOAST);
        ToastyTheme.roundRectExact(ctx, tx + tw - s * 29 / 100, y + s * 20 / 100, s * 31 / 100, s * 24 / 100, s * 11 / 100, TOAST);
        // Gesicht
        int e = Math.max(1, s / 14);
        int ey = ty + th * 32 / 100;
        ctx.fill(tx + tw * 28 / 100, ey, tx + tw * 28 / 100 + e, ey + e, 0xFF3B1D5E);
        ctx.fill(tx + tw * 72 / 100 - e, ey, tx + tw * 72 / 100, ey + e, 0xFF3B1D5E);
        ToastyTheme.roundRectExact(ctx, tx + tw * 36 / 100, ey + e * 2, tw * 28 / 100, Math.max(2, s / 12), Math.max(1, s / 24), 0xFF3B1D5E);
    }
}
