package dev.toasty.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

/**
 * Luft-Partikel (Stil wie Jessentials): weiche, runde Lichtkugeln mit Glow. Jede Kugel hat eine echte Weltposition,
 * treibt langsam und wird passend zur Kamera auf den Bildschirm projiziert (naeher = groesser, weiter weg = kleiner und blasser).
 */
public final class ToastyAirOrbs {
    private ToastyAirOrbs() {}

    private static final class Orb {
        double x, y, z, vx, vy, vz, phase;
        float size, hue;
        int age, life;
    }

    private static final List<Orb> orbs = new ArrayList<>();
    private static final Random rnd = new Random();

    private static int max() { return switch (ToastyConfig.get().airDensity) { case 1 -> 18; case 3 -> 60; default -> 34; }; }

    public static void tick(MinecraftClient mc) {
        if (mc.player == null || mc.world == null) { orbs.clear(); return; }
        if (mc.isPaused()) return;
        Vec3d p = mc.player.getEyePos();
        // neue Kugeln
        while (orbs.size() < max()) {
            Orb o = new Orb();
            double ang = rnd.nextDouble() * Math.PI * 2, dist = 2.5 + rnd.nextDouble() * 10;
            o.x = p.x + Math.cos(ang) * dist; o.z = p.z + Math.sin(ang) * dist;
            o.y = p.y - 1.5 + rnd.nextDouble() * 4.5;
            o.vx = (rnd.nextDouble() - 0.5) * 0.01; o.vz = (rnd.nextDouble() - 0.5) * 0.01; o.vy = 0.004 + rnd.nextDouble() * 0.008;
            o.phase = rnd.nextDouble() * Math.PI * 2;
            o.size = 0.6f + rnd.nextFloat() * 0.8f;
            o.hue = rnd.nextFloat();
            o.life = 140 + rnd.nextInt(160);
            orbs.add(o);
        }
        for (Iterator<Orb> it = orbs.iterator(); it.hasNext(); ) {
            Orb o = it.next();
            o.age++;
            o.x += o.vx + Math.sin(o.phase + o.age * 0.03) * 0.004;
            o.z += o.vz + Math.cos(o.phase + o.age * 0.027) * 0.004;
            o.y += o.vy;
            double dx = o.x - p.x, dz = o.z - p.z;
            if (o.age > o.life || dx * dx + dz * dz > 18 * 18) it.remove();
        }
    }

    public static void clear() { orbs.clear(); }

    /** Weicher Kreis aus waagrechten Zeilen. */
    private static void disc(DrawContext ctx, float cx, float cy, float r, int col) {
        if (r < 0.6f) return;
        int ri = Math.max(1, Math.round(r));
        for (int dy = -ri; dy < ri; dy++) {
            double yy = dy + 0.5;
            int half = (int) Math.round(Math.sqrt(Math.max(0, r * r - yy * yy)));
            if (half <= 0) continue;
            ctx.fill(Math.round(cx) - half, Math.round(cy) + dy, Math.round(cx) + half, Math.round(cy) + dy + 1, col);
        }
    }

    public static void render(DrawContext ctx, MinecraftClient mc) {
        if (!ToastyConfig.get().fxOrbs) return;
        var pl = mc.player;
        if (pl == null || orbs.isEmpty() || !mc.options.getPerspective().isFirstPerson()) return;
        
        float td = mc.getRenderTickCounter().getTickProgress(true);
        Vec3d eye = pl.getCameraPosVec(td);
        double yaw = Math.toRadians(pl.getYaw(td)), pitch = Math.toRadians(pl.getPitch(td));
        // Kamera-Achsen (Minecraft: Yaw 0 = Sueden)
        double fx = -Math.sin(yaw) * Math.cos(pitch), fy = -Math.sin(pitch), fz = Math.cos(yaw) * Math.cos(pitch);
        double rx = -Math.cos(yaw), ry = 0, rz = -Math.sin(yaw);
        double ux = ry * fz - rz * fy, uy = rz * fx - rx * fz, uz = rx * fy - ry * fx;
        int w = ctx.getScaledWindowWidth(), h = ctx.getScaledWindowHeight();
        double focal = (h / 2.0) / Math.tan(Math.toRadians(mc.options.getFov().getValue()) / 2.0);
        float sizeMul = ToastyConfig.get().airSize == 1 ? 0.7f : ToastyConfig.get().airSize == 3 ? 1.45f : 1f;
        boolean glow = true;

        // hinten zuerst zeichnen
        List<double[]> draw = new ArrayList<>();
        for (Orb o : orbs) {
            double dx = o.x - eye.x, dy = o.y - eye.y, dz = o.z - eye.z;
            double z = dx * fx + dy * fy + dz * fz;
            if (z < 0.4) continue;
            double sx = w / 2.0 + (dx * rx + dy * ry + dz * rz) / z * focal;
            double sy = h / 2.0 - (dx * ux + dy * uy + dz * uz) / z * focal;
            if (sx < -20 || sy < -20 || sx > w + 20 || sy > h + 20) continue;
            float fade = Math.min(1f, Math.min(o.age / 30f, (o.life - o.age) / 40f));
            float distFade = (float) Math.max(0, Math.min(1, 1.2 - z / 14.0));
            draw.add(new double[]{z, sx, sy, o.size, o.hue, fade * distFade});
        }
        draw.sort((a, b) -> Double.compare(b[0], a[0]));
        for (double[] d : draw) {
            float a = (float) d[5];
            if (a <= 0.02f) continue;
            float r = (float) Math.max(0.8, Math.min(7, d[3] * sizeMul * focal * 0.012 / d[0]));
            int col = ToastyTheme.lerp(ToastyTheme.PURPLE, ToastyTheme.BLUE, (float) d[4]);
            float cx = (float) d[1], cy = (float) d[2];
            if (glow) {
                disc(ctx, cx, cy, r * 3.2f, ToastyTheme.alpha(col, (int) (18 * a)));
                disc(ctx, cx, cy, r * 2.2f, ToastyTheme.alpha(col, (int) (34 * a)));
                disc(ctx, cx, cy, r * 1.5f, ToastyTheme.alpha(col, (int) (70 * a)));
            }
            disc(ctx, cx, cy, r, ToastyTheme.alpha(col, (int) (200 * a)));
            disc(ctx, cx, cy, r * 0.45f, ToastyTheme.alpha(ToastyTheme.lerp(col, 0xFFFFFFFF, 0.6f), (int) (230 * a)));
        }
    }
}
