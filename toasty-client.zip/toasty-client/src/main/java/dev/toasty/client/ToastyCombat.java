package dev.toasty.client;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.ActionResult;
import net.minecraft.util.math.Vec3d;

/** Kampf-Optik in Toasty-Farben: Ripple (Lichtwelle bei jedem Treffer), Afterglow (Kill loest sich in Licht auf) . Nur Anzeige, keine Kampfhilfe. */
public final class ToastyCombat {
    private ToastyCombat() {}

    private static LivingEntity target;
    private static long lastHitMs, deadMs, comboMs;
    private static int myHits, theirHits, combo, lastHurt;
    private static boolean wasDead;
    private static Vec3d lastPos = Vec3d.ZERO, ripC = Vec3d.ZERO, ripD = new Vec3d(0, 0, 1), glowPos = Vec3d.ZERO;
    private static int ripTick = -1, glowTick = -1;

    public static void register() {
        AttackEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (world.isClient() && player == mc.player && entity instanceof LivingEntity le) onHit(mc, le);
            return ActionResult.PASS;
        });
        ClientTickEvents.END_CLIENT_TICK.register(ToastyCombat::tick);
    }

    private static void onHit(MinecraftClient mc, LivingEntity le) {
        long now = System.currentTimeMillis();
        if (target != le) { target = le; myHits = 0; theirHits = 0; combo = 0; wasDead = false; }
        myHits++;
        combo = (now - comboMs < 2500) ? combo + 1 : 1;
        comboMs = now;
        lastHitMs = now;
        lastPos = new Vec3d(le.getX(), le.getY(), le.getZ());
        if (ToastyConfig.get().fxRipple && mc.player != null) {
            ripC = new Vec3d(le.getX(), le.getY() + le.getHeight() * 0.6, le.getZ());
            Vec3d d = ripC.subtract(mc.player.getEyePos());
            ripD = d.lengthSquared() < 1e-6 ? new Vec3d(0, 0, 1) : d.normalize();
            ripTick = 0;
            for (int i = 0; i < 8; i++) {
                mc.particleManager.addParticle(ToastyFx.effect(0.8f), ripC.x, ripC.y, ripC.z,
                    (Math.random() - 0.5) * 0.3, (Math.random() - 0.3) * 0.25, (Math.random() - 0.5) * 0.3);
            }
        }
    }

    private static void tick(MinecraftClient mc) {
        if (mc.player == null || mc.world == null || mc.isPaused()) return;
        ToastyConfig cfg = ToastyConfig.get();
        long now = System.currentTimeMillis();
        var p = mc.player;

        // Treffer, die du einsteckst (nur solange ein Ziel in der Naehe ist)
        if (p.hurtTime > lastHurt && target != null && p.distanceTo(target) < 10) { theirHits++; combo = 0; }
        lastHurt = p.hurtTime;

        if (target != null) {
            if (target.isAlive()) lastPos = new Vec3d(target.getX(), target.getY(), target.getZ());
            else if (!wasDead) {
                wasDead = true; deadMs = now;
                if (cfg.fxAfterglow && now - lastHitMs < 8000) { glowTick = 0; glowPos = lastPos; }
            }
            if (now - Math.max(lastHitMs, deadMs) > 6000) target = null;
        }

        // Ripple: Ring senkrecht zur Blickrichtung, wird groesser
        if (ripTick >= 0) {
            if (!cfg.fxRipple) ripTick = -1;
            else {
                Vec3d u = ripD.crossProduct(new Vec3d(0, 1, 0));
                if (u.lengthSquared() < 1e-4) u = new Vec3d(1, 0, 0);
                u = u.normalize();
                Vec3d v = ripD.crossProduct(u).normalize();
                double r = 0.2 + ripTick * 0.17;
                int pts = 20;
                for (int i = 0; i < pts; i++) {
                    double a = i * Math.PI * 2 / pts;
                    Vec3d q = ripC.add(u.multiply(Math.cos(a) * r)).add(v.multiply(Math.sin(a) * r));
                    mc.particleManager.addParticle(ToastyFx.effect(1.0f), q.x, q.y, q.z, 0, 0, 0);
                }
                if (++ripTick > 9) ripTick = -1;
            }
        }

        // Afterglow: Kill loest sich in aufsteigendes Licht auf
        if (glowTick >= 0) {
            if (!cfg.fxAfterglow) glowTick = -1;
            else {
                for (int i = 0; i < 6; i++) {
                    mc.particleManager.addParticle(ToastyFx.effect(0.9f),
                        glowPos.x + (Math.random() - 0.5) * 0.8, glowPos.y + Math.random() * 1.7, glowPos.z + (Math.random() - 0.5) * 0.8,
                        0, 0.04 + Math.random() * 0.08, 0);
                }
                if (glowTick % 2 == 0) for (int k = 0; k < 8; k++)
                    mc.particleManager.addParticle(ToastyFx.effect(1.2f), glowPos.x, glowPos.y + k * 0.35, glowPos.z, 0, 0.12, 0);
                if (++glowTick > 16) glowTick = -1;
            }
        }
    }
}
