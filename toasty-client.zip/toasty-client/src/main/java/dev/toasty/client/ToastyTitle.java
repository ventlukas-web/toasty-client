package dev.toasty.client;

import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.TitleScreen;

/** Start-Animation + Branding auf dem Hauptmenue. */
public final class ToastyTitle {
    private static long introStart = -1;
    private static boolean introDone = false;
    private static final long INTRO_MS = 2800;
    private static final String NAME = "TOASTY CLIENT";

    private ToastyTitle() {}

    public static void register() {
        ScreenEvents.AFTER_INIT.register((client, screen, w, h) -> {
            if (!(screen instanceof TitleScreen)) return;
            if (!introDone && introStart < 0 && ToastyConfig.get().titleAnimation) introStart = System.currentTimeMillis();
            ScreenEvents.afterRender(screen).register((s, ctx, mx, my, delta) ->
                render(ctx, client, s.width, s.height));
        });
    }

    private static float clamp01(float v) { return Math.max(0f, Math.min(1f, v)); }

    private static void render(DrawContext ctx, MinecraftClient mc, int w, int h) {
        TextRenderer tr = mc.textRenderer;
        long now = System.currentTimeMillis();

        // dauerhaftes Branding oben mittig, gross, mit Glanz-Effekt
        String tag = "Toasty Client";
        float bs = 2.5f;
        int tw = tr.getWidth(tag);
        float bx = (w - tw * bs) / 2f;
        ctx.getMatrices().pushMatrix();
        ctx.getMatrices().translate(bx, 4);
        ctx.getMatrices().scale(bs, bs);
        for (int i = 0, x = 0; i < tag.length(); i++) {
            String ch = String.valueOf(tag.charAt(i));
            float k = 0.5f + 0.5f * (float) Math.sin(now / 450.0 + i * 0.55);
            ctx.drawTextWithShadow(tr, ch, x, 0, ToastyTheme.lerp(ToastyTheme.PURPLE, ToastyTheme.BLUE, k));
            x += tr.getWidth(ch);
        }
        ctx.getMatrices().popMatrix();
        ToastyTheme.hGradient(ctx, (int) bx, (int) (4 + 8 * bs + 2), (int) (tw * bs), 2, ToastyTheme.PURPLE, ToastyTheme.BLUE);

        // Intro (einmal pro Spielstart)
        if (introStart < 0 || introDone) return;
        float t = (now - introStart) / (float) INTRO_MS;
        if (t >= 1f) { introDone = true; return; }
        float fade = t < 0.78f ? 1f : 1f - (t - 0.78f) / 0.22f;
        int bgA = (int) (235 * fade);

        ctx.fillGradient(0, 0, w, h,
            ToastyTheme.alpha(ToastyTheme.lerp(0xFF05030C, ToastyTheme.PURPLE, 0.18f), bgA),
            ToastyTheme.alpha(ToastyTheme.lerp(0xFF05030C, ToastyTheme.BLUE, 0.22f), bgA));

        // aufsteigende Funken
        for (int i = 0; i < 40; i++) {
            float seed = i * 37.17f;
            float px = (float) ((Math.sin(seed) * 0.5 + 0.5) * w);
            float speed = 18 + (i % 7) * 6;
            float py = h - ((now / 1000f * speed + (seed % 90) * 4) % (h + 20));
            int a = (int) (150 * fade * (0.4 + 0.6 * Math.abs(Math.sin(now / 500.0 + i))));
            int sz = 1 + (i % 3 == 0 ? 1 : 0);
            ctx.fill((int) px, (int) py, (int) px + sz, (int) py + sz,
                ToastyTheme.alpha(ToastyTheme.lerp(ToastyTheme.PURPLE, ToastyTheme.BLUE, (i % 10) / 9f), a));
        }

        // Buchstaben erscheinen nacheinander (gross, fuellen die Breite)
        int total = 0;
        for (int i = 0; i < NAME.length(); i++) total += tr.getWidth(String.valueOf(NAME.charAt(i)));
        float scale = Math.max(3f, Math.min(10f, w * 0.88f / total));
        int cy = (int) (h / 2f - 4 * scale);
        float startX = (w - total * scale) / 2f;
        float x = startX;
        for (int i = 0; i < NAME.length(); i++) {
            String ch = String.valueOf(NAME.charAt(i));
            float tl = 0.10f + i * 0.03f;
            float a = clamp01((t - tl) / 0.09f);
            int cw = tr.getWidth(ch);
            if (a > 0.03f && !ch.equals(" ")) {
                ctx.getMatrices().pushMatrix();
                ctx.getMatrices().translate(x, cy + (1f - a) * 14f);
                ctx.getMatrices().scale(scale, scale);
                int col = ToastyTheme.lerp(ToastyTheme.PURPLE, ToastyTheme.BLUE, (float) i / (NAME.length() - 1));
                ctx.drawTextWithShadow(tr, ch, 0, 0, ToastyTheme.alpha(col, (int) (255 * a * fade)));
                ctx.getMatrices().popMatrix();
            }
            x += cw * scale;
        }

        // Linie waechst aus der Mitte (unter dem Namen)
        float lineP = clamp01(t / 0.35f);
        int lw = (int) (total * scale * lineP);
        int ly = (int) (cy + 8 * scale + 6);
        if (lw > 0) {
            ToastyTheme.hGradient(ctx, (w - lw) / 2, ly, lw, 3,
                ToastyTheme.alpha(ToastyTheme.PURPLE, (int) (255 * fade)),
                ToastyTheme.alpha(ToastyTheme.BLUE, (int) (255 * fade)));
        }

        // Untertitel
        float sa = clamp01((t - 0.55f) / 0.15f) * fade;
        if (sa > 0.03f) {
            String sub = "Gamble · HUD · Tools  —  für WindSMP";
            ctx.drawTextWithShadow(tr, sub, (w - tr.getWidth(sub)) / 2, ly + 10,
                ToastyTheme.alpha(ToastyTheme.TEXT, (int) (255 * sa)));
        }
    }
}
