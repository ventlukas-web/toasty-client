package dev.toasty.client;

import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.GZIPInputStream;

/** Minimaler NBT-Leser (gzip). Compound -> Map, List -> List, Arrays -> primitive Arrays. */
final class ToastyNbt {
    private ToastyNbt() {}

    @SuppressWarnings("unchecked")
    public static Map<String, Object> readGzip(Path file) throws IOException {
        try (InputStream raw = Files.newInputStream(file);
             DataInputStream in = new DataInputStream(new BufferedInputStream(new GZIPInputStream(raw)))) {
            int type = in.readUnsignedByte();
            if (type != 10) throw new IOException("Kein NBT-Compound als Wurzel");
            in.readUTF(); // Root-Name
            return (Map<String, Object>) read(in, 10, 0);
        }
    }

    private static Object read(DataInputStream in, int type, int depth) throws IOException {
        if (depth > 512) throw new IOException("NBT zu tief verschachtelt");
        switch (type) {
            case 1: return in.readByte();
            case 2: return in.readShort();
            case 3: return in.readInt();
            case 4: return in.readLong();
            case 5: return in.readFloat();
            case 6: return in.readDouble();
            case 7: { byte[] a = new byte[len(in)]; in.readFully(a); return a; }
            case 8: return in.readUTF();
            case 9: {
                int t = in.readUnsignedByte();
                int n = in.readInt();
                List<Object> l = new ArrayList<>(Math.max(0, Math.min(n, 4096)));
                for (int i = 0; i < n; i++) l.add(read(in, t, depth + 1));
                return l;
            }
            case 10: {
                Map<String, Object> m = new HashMap<>();
                while (true) {
                    int t = in.readUnsignedByte();
                    if (t == 0) break;
                    String k = in.readUTF();
                    m.put(k, read(in, t, depth + 1));
                }
                return m;
            }
            case 11: { int n = len(in); int[] a = new int[n]; for (int i = 0; i < n; i++) a[i] = in.readInt(); return a; }
            case 12: { int n = len(in); long[] a = new long[n]; for (int i = 0; i < n; i++) a[i] = in.readLong(); return a; }
            default: throw new IOException("Unbekannter NBT-Typ " + type);
        }
    }

    private static int len(DataInputStream in) throws IOException {
        int n = in.readInt();
        if (n < 0 || n > 64_000_000) throw new IOException("Ungueltige NBT-Laenge " + n);
        return n;
    }

    @SuppressWarnings("unchecked")
    static Map<String, Object> map(Object o) { return o instanceof Map ? (Map<String, Object>) o : Map.of(); }

    @SuppressWarnings("unchecked")
    static List<Object> list(Object o) { return o instanceof List ? (List<Object>) o : List.of(); }

    static int i(Object o) { return o instanceof Number n ? n.intValue() : 0; }
}
