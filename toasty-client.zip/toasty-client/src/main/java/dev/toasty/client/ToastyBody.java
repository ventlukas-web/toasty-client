package dev.toasty.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.particle.Particle;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.particle.DustColorTransitionParticleEffect;
import net.minecraft.particle.ParticleEffect;

/**
 * Koerper-Effekte aus Partikeln: Skelett (Schaedel, Wirbelsaeule, Rippen, Becken, Gelenke) und Glas-Skin (leuchtende Kanten aller
 * Koerperteile). Nur normale Sicht, kein Blick durch Waende. Gliedmassen schwingen mit, Treffer-Bounce streckt den Koerper.
 */
final class ToastyBody {
    private ToastyBody() {}

    private static MinecraftClient mc;
    private static ParticleEffect fx;
    private static ParticleEffect fxJoint;
    private static int life;
    private static double ox, oy, oz, rx, rz, fxx, fzz, sxz, sy;

    static void tick(MinecraftClient client, ToastyConfig cfg, long tk) {
        if (!cfg.skeleton && !cfg.glass) return;
        mc = client;
        var p = mc.player;
        int cnt = 0;
        for (var o : mc.world.getPlayers()) {
            boolean self = o == p;
            if (o.isInvisible() || o.squaredDistanceTo(p) > 40 * 40) continue;
            if (self && (!cfg.glass || mc.options.getPerspective().isFirstPerson())) continue;
            boolean hurt = o.hurtTime > 0;
            if (tk % 2 != 0 && !hurt) continue;
            if (++cnt > 6) break;
            life = hurt ? 2 : 3;
            double yaw = Math.toRadians(o.getBodyYaw());
            rx = Math.cos(yaw); rz = Math.sin(yaw); fxx = -Math.sin(yaw); fzz = Math.cos(yaw);
            ox = o.getX(); oy = o.getY(); oz = o.getZ();
            double ht = (10 - Math.max(0, o.hurtTime)) / 10.0, bn = hurt ? Math.exp(-3.2 * ht) * Math.cos(ht * 13.0) : 0;
            sy = 1 + 0.16 * bn; sxz = 1 - 0.11 * bn;
            float big = (float) (Math.abs(bn));
            double sp = Math.min(1f, o.limbAnimator.getSpeed()), a = Math.cos(o.limbAnimator.getAnimationProgress() * 0.6662) * 1.4 * sp;
            double tt = (System.currentTimeMillis() % 100000L) / 1000.0 + o.getId() * 1.7, calm = 1.0 - 0.6 * sp;
            double aLA = -a + calm * 0.28 * Math.sin(tt * 1.9), aRA = a + calm * 0.28 * Math.sin(tt * 1.9 + 2.1);
            double aLL = a + calm * 0.12 * Math.sin(tt * 1.3 + 1.0), aRL = -a + calm * 0.12 * Math.sin(tt * 1.3 + 3.9);
            double sway = 0.04 * Math.sin(tt * 1.1);   // Oberkoerper atmet/wiegt leicht
            boolean sn = o.isSneaking();
            double lean = sn ? 0.35 : 0.0;
            if (cfg.glass) {
                int c1 = colorOf(cfg.glassColor);
                int gl = Math.max(1, Math.min(3, cfg.glassGlow));
                fx = new DustColorTransitionParticleEffect(c1 & 0xFFFFFF, ToastyTheme.lerp(0xFF000000 | c1, 0xFFFFFFFF, 0.55f) & 0xFFFFFF, 0.55f + 0.18f * gl + big * 0.4f);
                double st = 0.30 - 0.06 * gl;
                // Kopf, Rumpf, Arme, Beine als Glaskoerper (Vanilla-Masse)
                box(0, 1.75, 0, 0.25, 0.25, 0.25, 1.5, 0, 0, lean, st);
                box(0, 1.125, 0, 0.25, 0.375, 0.125, 0, 0.75, 0, 0, st);
                box(-0.375, 1.125, 0, 0.125, 0.375, 0.125, 1.5, 0, aLA, 0, st);
                box(0.375, 1.125, 0, 0.125, 0.375, 0.125, 1.5, 0, aRA, 0, st);
                box(-0.125, 0.375, 0, 0.125, 0.375, 0.125, 0.75, 0, aLL, 0, st);
                box(0.125, 0.375, 0, 0.125, 0.375, 0.125, 0.75, 0, aRL, 0, st);
            }
            if (cfg.skeleton) skeleton(a, aLA, aRA, aLL, aRL, sway, lean, big);
        }
    }

    // ---------------- Skelett ----------------
    private static void skeleton(double a, double aLA, double aRA, double aLL, double aRL, double sway, double lean, float big) {
        int bone = 0xFFEDE4FF, joint = ToastyTheme.PURPLE;
        fx = new DustColorTransitionParticleEffect(0xF3EAFF, 0xD946EF, 0.5f + big * 0.4f);
        fxJoint = new DustColorTransitionParticleEffect(0xFFFFFF, 0xA855F7, 0.9f + big * 0.4f);
        // Wirbelsaeule (8 Wirbel) + Kopf
        for (int i = 0; i < 8; i++) { double y = 0.80 + i * 0.085; dot(fxJoint, 0, y, -0.06, 0, 0, 0, 0); }
        line(0, 0.75, -0.06, 0, 1.52, -0.06, 0.1);
        // Schaedel: Box-Rahmen + Augenhoehlen + Kiefer
        box(0, 1.75, 0, 0.19, 0.19, 0.17, 1.5, 0, 0, lean, 0.12);
        dot(fxJoint, -0.09, 1.78, 0.17, 1.5, 0, 0, lean); dot(fxJoint, 0.09, 1.78, 0.17, 1.5, 0, 0, lean);
        line2(-0.1, 1.64, 0.15, 0.1, 1.64, 0.15, 0.06, 1.5, lean);
        line(0, 1.52, -0.06, 0, 1.6, -0.02, 0.08);
        // Schluesselbeine + Brustbein
        line(-0.3, 1.46, 0.0, 0.3, 1.46, 0.0, 0.1);
        line(0, 1.46, 0.09, 0, 1.0, 0.09, 0.1);
        // Rippen: 5 Boegen mit abnehmender Breite
        for (int r = 0; r < 5; r++) {
            double y = 1.38 - r * 0.075, wx = 0.22 - r * 0.012;
            for (int k = 0; k <= 6; k++) {
                double ang = Math.PI * (k / 6.0);              // Halbkreis vorn
                dot(fx, Math.cos(ang) * wx, y, Math.sin(ang) * 0.1 - 0.02, 0, 0, 0, 0);
            }
        }
        // Becken: Rahmen + Beckenschaufeln
        box(0, 0.80, 0, 0.19, 0.06, 0.1, 0, 0, 0, 0, 0.1);
        line(-0.19, 0.8, 0, -0.12, 0.74, 0.02, 0.07); line(0.19, 0.8, 0, 0.12, 0.74, 0.02, 0.07);
        // Arme: Schulter -> Ellbogen -> Hand, Unterarm knickt mit
        limbArm(-0.3, aLA, 1.5, 0.28);
        limbArm(0.3, aRA, 1.5, 0.28);
        // Beine: Hueft -> Knie -> Fuss
        limbLeg(-0.12, aLL);
        limbLeg(0.12, aRL);
    }

    private static void limbArm(double x, double ang, double py, double len) {
        double u = 0.3, l = 0.3;
        double bend = 0.25 + Math.abs(ang) * 0.35 + (ang > 0 ? 0.0 : 0.0);
        double[] e = rot(0, -u, 0, ang), h = rot(0, -u - Math.cos(bend) * l, Math.sin(bend) * l, ang);
        line(x, py + 0, 0, x + 0, py + e[1], e[2], 0.07);
        dot(fxJoint, x, py, 0, 0, 0, 0, 0);
        dot(fxJoint, x, py + e[1], e[2], 0, 0, 0, 0);
        line(x, py + e[1], e[2], x, py + h[1], h[2], 0.07);
        dot(fxJoint, x, py + h[1], h[2], 0, 0, 0, 0);
        // Hand: kleine Finger-Linie
        line(x - 0.03, py + h[1], h[2], x + 0.03, py + h[1], h[2], 0.04);
    }

    private static void limbLeg(double x, double ang) {
        double th = 0.38, sh = 0.37, py = 0.75;
        double knee = Math.max(0, -ang) * 0.5;   // Knie beugt, wenn das Bein nach hinten schwingt
        double[] k = rot(0, -th, 0, ang), f = rot(0, -th - Math.cos(knee) * sh, -Math.sin(knee) * sh, ang);
        line(x, py, 0, x, py + k[1], k[2], 0.08);
        dot(fxJoint, x, py, 0, 0, 0, 0, 0);
        dot(fxJoint, x, py + k[1], k[2], 0, 0, 0, 0);
        line(x, py + k[1], k[2], x, py + f[1], f[2], 0.08);
        dot(fxJoint, x, py + f[1], f[2], 0, 0, 0, 0);
        line(x, py + f[1], f[2], x, py + f[1], f[2] + 0.16, 0.06);   // Fuss
    }

    // ---------------- Helfer ----------------
    private static int colorOf(String hex) {
        Integer v = hex == null ? null : ToastyTheme.parseHex(hex.trim());
        return v != null ? v : 0xFF880FF9;
    }

    private static double[] rot(double x, double y, double z, double ang) {
        double c = Math.cos(ang), s = Math.sin(ang);
        return new double[]{x, y * c + z * s, -y * s + z * c};
    }

    /** Partikel an lokalem Punkt (x,y,z), optional um Drehpunkt py mit Winkel a um die Querachse gedreht; Bounce-Skalierung inklusive. */
    private static void dot(ParticleEffect e, double x, double y, double z, double py, double a, double dummy, double lean) {
        if (lean != 0 && py > 0) { double[] r = rot(0, y - py, z, -lean); y = py + r[1]; z = r[2]; }
        else if (a != 0) { double[] r = rot(0, y - py, z, a); y = py + r[1]; z = r[2]; }
        double lx = x * sxz, ly = y * sy, lz = z * sxz;
        Particle pt = mc.particleManager.addParticle(e, ox + lx * rx + lz * fxx, oy + ly, oz + lx * rz + lz * fzz, 0, 0, 0);
        if (pt != null) pt.setMaxAge(life);
    }

    private static void line(double x0, double y0, double z0, double x1, double y1, double z1, double step) {
        double len = Math.sqrt((x1 - x0) * (x1 - x0) + (y1 - y0) * (y1 - y0) + (z1 - z0) * (z1 - z0));
        int n = Math.max(1, (int) Math.round(len / Math.max(0.05, step)));
        for (int i = 0; i <= n; i++) { double u = i / (double) n; dot(fx, x0 + (x1 - x0) * u, y0 + (y1 - y0) * u, z0 + (z1 - z0) * u, 0, 0, 0, 0); }
    }

    private static void line2(double x0, double y0, double z0, double x1, double y1, double z1, double step, double py, double lean) {
        double len = Math.abs(x1 - x0);
        int n = Math.max(1, (int) Math.round(len / step));
        for (int i = 0; i <= n; i++) { double u = i / (double) n; dot(fx, x0 + (x1 - x0) * u, y0, z0, py, 0, 0, lean); }
    }

    /** Kantenrahmen einer Box (Mitte cx,cy,cz; Halbmasse h*), optional um Drehpunkt (py) gedreht (Gliedmassen) bzw. nach vorn geneigt (lean). */
    private static void box(double cx, double cy, double cz, double hx, double hy, double hz, double py, double dummy, double ang, double lean, double step) {
        for (int ax = 0; ax < 3; ax++) for (int s1 = -1; s1 <= 1; s1 += 2) for (int s2 = -1; s2 <= 1; s2 += 2) {
            double len = 2 * (ax == 0 ? hx : ax == 1 ? hy : hz);
            int n = Math.max(1, (int) Math.round(len / step));
            for (int i = 0; i <= n; i++) {
                double u = -1 + 2 * i / (double) n, x, y, z;
                if (ax == 0) { x = u * hx; y = s1 * hy; z = s2 * hz; }
                else if (ax == 1) { x = s1 * hx; y = u * hy; z = s2 * hz; }
                else { x = s1 * hx; y = s2 * hy; z = u * hz; }
                dot(fx, cx + x, cy + y, cz + z, py, ang, 0, lean);
            }
        }
    }
}
