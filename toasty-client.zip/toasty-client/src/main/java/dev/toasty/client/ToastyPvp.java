package dev.toasty.client;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.ActionResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayDeque;

/** PvP-Helfer: CPS, Reach, Item-Zaehler, Treffer-Marker/-Sound, Low-HP-Warnung, Cooldown-Balken. Alles nur Anzeige. */
public final class ToastyPvp {
    private static final ArrayDeque<Long> L = new ArrayDeque<>(), R = new ArrayDeque<>();
    private static boolean pl, pr;
    public static double reach = -1;
    private static long markerUntil;
    public static final int[] COUNTS = new int[6];
    public static final String[] NAMES = {"Totems", "G-Äpfel", "Perlen", "Kristalle", "Obsidian", "Tränke"};

    private ToastyPvp() {}

    public static void register() {
        AttackEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (world.isClient() && player == mc.player && entity != null) {
                Vec3d eye = player.getEyePos();
                Box b = entity.getBoundingBox();
                Vec3d c = new Vec3d(clamp(eye.x, b.minX, b.maxX), clamp(eye.y, b.minY, b.maxY), clamp(eye.z, b.minZ, b.maxZ));
                reach = eye.distanceTo(c);
                long now = System.currentTimeMillis();
                markerUntil = now + 260;
                if (ToastyConfig.get().hitSound) ToastyMisc.playId("entity.experience_orb.pickup");
            }
            return ActionResult.PASS;
        });
        ClientTickEvents.END_CLIENT_TICK.register(ToastyPvp::tick);
    }

    private static double clamp(double v, double lo, double hi) { return Math.max(lo, Math.min(hi, v)); }

    private static void tick(MinecraftClient mc) {
        if (mc.player == null) return;
        long now = System.currentTimeMillis();
        if (mc.currentScreen == null) {
            long win = mc.getWindow().getHandle();
            boolean l = GLFW.glfwGetMouseButton(win, 0) == GLFW.GLFW_PRESS, r = GLFW.glfwGetMouseButton(win, 1) == GLFW.GLFW_PRESS;
            if (l && !pl) L.add(now);
            if (r && !pr) R.add(now);
            pl = l; pr = r;
        } else { pl = false; pr = false; }
        while (!L.isEmpty() && now - L.peekFirst() > 1000) L.pollFirst();
        while (!R.isEmpty() && now - R.peekFirst() > 1000) R.pollFirst();
        if ((mc.world != null && (mc.world.getTime() % 5) == 0) && ToastyConfig.get().pvpItems) count(mc);
    }

    private static void count(MinecraftClient mc) {
        java.util.Arrays.fill(COUNTS, 0);
        var inv = mc.player.getInventory();
        for (int i = 0; i < inv.size(); i++) {
            ItemStack s = inv.getStack(i);
            if (s.isEmpty()) continue;
            Item it = s.getItem();
            int n = s.getCount();
            if (it == Items.TOTEM_OF_UNDYING) COUNTS[0] += n;
            else if (it == Items.GOLDEN_APPLE || it == Items.ENCHANTED_GOLDEN_APPLE) COUNTS[1] += n;
            else if (it == Items.ENDER_PEARL) COUNTS[2] += n;
            else if (it == Items.END_CRYSTAL) COUNTS[3] += n;
            else if (it == Items.OBSIDIAN) COUNTS[4] += n;
            else if (it == Items.SPLASH_POTION) COUNTS[5] += n;
        }
    }

    public static int cpsL() { return L.size(); }
    public static int cpsR() { return R.size(); }
    /** Treffer-Marker, Cooldown-Balken, Low-HP-Warnung. */
    public static void overlay(DrawContext ctx, MinecraftClient mc, ToastyConfig cfg) {
        if (mc.player == null || mc.options.hudHidden || mc.currentScreen != null) return;
        int sw = ctx.getScaledWindowWidth(), sh = ctx.getScaledWindowHeight();
        long now = System.currentTimeMillis();
        int cx = sw / 2, cy = sh / 2;

        if (cfg.hitMarker && now < markerUntil) {
            int a = (int) (255 * (markerUntil - now) / 260.0);
            int col = ToastyTheme.alpha(0xFFFFFFFF, Math.max(40, a));
            for (int d = 4; d <= 8; d++) {
                ctx.fill(cx - d, cy - d, cx - d + 1, cy - d + 1, col);
                ctx.fill(cx + d - 1, cy - d, cx + d, cy - d + 1, col);
                ctx.fill(cx - d, cy + d - 1, cx - d + 1, cy + d, col);
                ctx.fill(cx + d - 1, cy + d - 1, cx + d, cy + d, col);
            }
        }
        if (cfg.cooldownBar) {
            float p = mc.player.getAttackCooldownProgress(0f);
            if (p < 0.999f) {
                int w = 34, x = cx - w / 2, y = cy + 14;
                ctx.fill(x - 1, y - 1, x + w + 1, y + 4, 0x90000000);
                ctx.fill(x, y, x + (int) (w * p), y + 3, p > 0.9f ? 0xFF86EFAC : 0xFFFBBF24);
            }
        }
        if (cfg.lowHpWarn) {
            float hp = mc.player.getHealth() + mc.player.getAbsorptionAmount();
            if (hp > 0 && hp <= 6f) {
                double pulse = 0.5 + 0.5 * Math.sin(now / 220.0);
                int a = (int) (0x28 + 0x40 * pulse * (1f - hp / 8f));
                int red = 0xFFDC2626;
                ctx.fillGradient(0, 0, sw, 46, ToastyTheme.alpha(red, a), 0x00DC2626);
                ctx.fillGradient(0, sh - 46, sw, sh, 0x00DC2626, ToastyTheme.alpha(red, a));
            }
        }
    }
}
