package dev.toasty.client;

import net.fabricmc.fabric.api.resource.ResourceManagerHelper;
import net.fabricmc.fabric.api.resource.ResourcePackActivationType;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.resource.ResourcePackManager;
import net.minecraft.resource.ResourcePackProfile;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.util.ArrayList;
import java.util.List;

/** Unsichtbares Glas ueber ein eingebautes Resource-Pack (alle Glas-Texturen komplett durchsichtig). */
public final class ToastyGlass {
    public static final Identifier PACK_ID = Identifier.of("toastyclient", "invisible_glass");

    private ToastyGlass() {}

    public static void register() {
        FabricLoader.getInstance().getModContainer("toastyclient").ifPresent(c -> {
            ResourceManagerHelper.registerBuiltinResourcePack(PACK_ID, c,
                Text.literal("Toasty - Unsichtbares Glas"), ResourcePackActivationType.NORMAL);
            ResourceManagerHelper.registerBuiltinResourcePack(Identifier.of("toastyclient", "ore_cloak"), c,
                Text.literal("Toasty - Anti-Leak Bloecke"), ResourcePackActivationType.NORMAL);
            ResourceManagerHelper.registerBuiltinResourcePack(Identifier.of("toastyclient", "map_numbers"), c,
                Text.literal("Toasty - Papier-Zahlen als Karte"), ResourcePackActivationType.ALWAYS_ENABLED);
            ResourceManagerHelper.registerBuiltinResourcePack(Identifier.of("toastyclient", "toasty_totem"), c,
                Text.literal("Toasty - Totem im Client-Design"), ResourcePackActivationType.ALWAYS_ENABLED);
            ResourceManagerHelper.registerBuiltinResourcePack(Identifier.of("toastyclient", "toasty_items"), c,
                Text.literal("Toasty - Schwerter, Perle und Apfel"), ResourcePackActivationType.ALWAYS_ENABLED);
            // Runde, leicht durchsichtige Buttons und Slider als Texturen: funktioniert ohne Mixin, immer aktiv
            ResourceManagerHelper.registerBuiltinResourcePack(Identifier.of("toastyclient", "toasty_buttons"), c,
                Text.literal("Toasty - Runde Buttons"), ResourcePackActivationType.ALWAYS_ENABLED);
        });
    }

    private static String findId(ResourcePackManager pm) { return findId(pm, "invisible_glass"); }

    private static String findId(ResourcePackManager pm, String key) {
        for (ResourcePackProfile p : pm.getProfiles()) {
            if (p.getId().contains(key)) return p.getId();
        }
        return null;
    }

    public static boolean isOn() { return isOn("invisible_glass"); }

    public static boolean isOn(String key) {
        ResourcePackManager pm = MinecraftClient.getInstance().getResourcePackManager();
        String id = findId(pm, key);
        return id != null && pm.getEnabledIds().contains(id);
    }

    /** @return false, wenn das Pack nicht gefunden wurde. */
    public static boolean set(boolean on) { return set("invisible_glass", on); }

    /** Anti-Leak: Erze und Wertbloecke werden als Netherite-Block dargestellt. */
    public static boolean setCloak(boolean on) { return isOn("ore_cloak") == on || set("ore_cloak", on); }

    public static boolean set(String key, boolean on) {
        MinecraftClient mc = MinecraftClient.getInstance();
        ResourcePackManager pm = mc.getResourcePackManager();
        String id = findId(pm, key);
        if (id == null) return false;
        List<String> enabled = new ArrayList<>(pm.getEnabledIds());
        if (on) { if (!enabled.contains(id)) enabled.add(id); } else enabled.remove(id);
        pm.setEnabledProfiles(enabled);
        mc.options.refreshResourcePacks(pm);
        return true;
    }

    public static boolean toggle() {
        boolean target = !isOn();
        return set(target);
    }
}
