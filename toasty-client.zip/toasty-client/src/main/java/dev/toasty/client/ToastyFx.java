package dev.toasty.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.particle.DustColorTransitionParticleEffect;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;

/** Effekte in Toasty-Farben: Lichtschweif hinter dir (Trail) und Ring beim Landen (Shockwave). Reine Client-Partikel. */
public final class ToastyFx {
    private ToastyFx() {}

    private static boolean jumpPrevGround = true;
    private static final java.util.ArrayList<double[]> JUMP = new java.util.ArrayList<>();

    static ParticleEffect effect(float size) {
        // Uebergang Lila -> Blau (Toasty-Farben); Farbe ohne Alpha
        return new DustColorTransitionParticleEffect(ToastyTheme.PURPLE & 0xFFFFFF, ToastyTheme.BLUE & 0xFFFFFF, size);
    }

    /** Partikel mit kurzer, eigener Lebensdauer (Dust lebt sonst sehr lange und stapelt sich). */
    static void add(MinecraftClient mc, ParticleEffect e, double x, double y, double z, double vx, double vy, double vz, int maxAge) {
        try {
            var pt = mc.particleManager.addParticle(e, x, y, z, vx, vy, vz);
            if (pt != null) { pt.setMaxAge(maxAge); spawned++; } else nullPt++;
        } catch (Throwable t) { failed++; lastErr = String.valueOf(t); }
    }

    public static int spawned, nullPt, failed, ticks, jumps, auras;
    public static String lastErr = "-";
    public static final String BUILD = "2026-11-28 fx-diag";

    public static String diag() {
        ToastyConfig c = ToastyConfig.get();
        return "Build " + BUILD + " | Ringe " + (c.fxJump ? "AN" : "AUS") + " (" + jumps + " Spruenge) | Aura " + (c.fxAura ? "AN" : "AUS") + " (" + auras
            + ") | Ticks " + ticks + " | Partikel ok " + spawned + ", null " + nullPt + ", Fehler " + failed + " (" + lastErr + ")";
    }

    /** Aktive Pfuetzen-Ringe: {x, y, z, Alter}. */
    private static final java.util.ArrayList<double[]> RINGS = new java.util.ArrayList<>();
    private static final int RAIN_DROP = 0xFFCFE6FF;

    /** Realistischerer Regen: fallende Tropfen-Streifen, Spritzer und sich ausbreitende Pfuetzen-Ringe am Boden (nur Client-Partikel). */
    private static double windAngle = Math.random() * Math.PI * 2, windPhase;
    private static final int[][] RCOL = {{0xF2FAFF, 0xB9DCF7}, {0xDCEFFF, 0x9CC8EE}, {0xC9E2F7, 0x86B4DD}};

    private static boolean rainsAt(MinecraftClient mc, int bx, int top, int bz) {
        return mc.world.getBiome(new net.minecraft.util.math.BlockPos(bx, top, bz)).value().hasPrecipitation();
    }

    private static void plain(MinecraftClient mc, ParticleEffect e, double x, double y, double z, double vx, double vy, double vz) {
        try { mc.particleManager.addParticle(e, x, y, z, vx, vy, vz); } catch (Throwable ignored) {}
    }

    /** Realistischer Regen (wie ShinyRain aus Jessentials, erweitert): Streifen im Boenwind in drei Tiefen, echte Tropfen,
     *  am Boden Spritzer-Kronen, Sprühnebel und Pfuetzen mit doppelten, ausblendenden Ringen. Nur Client-Partikel. */
    private static void rain(MinecraftClient mc, ToastyConfig cfg, Vec3d pos) {
        float g = mc.world.getRainGradient(1f);
        if (g < 0.15f) { RINGS.clear(); return; }
        int dens = Math.max(1, Math.min(3, cfg.rainDensity));
        var rng = mc.world.getRandom();
        double py = mc.player.getEyeY();
        windPhase += 0.02; windAngle += (rng.nextDouble() - 0.5) * 0.01;
        double gust = 0.10 + 0.08 * Math.sin(windPhase) + (mc.world.isThundering() ? 0.12 : 0);
        double wx = Math.cos(windAngle) * gust, wz = Math.sin(windAngle) * gust;

        // Streifen in der Luft
        int streaks = (int) Math.ceil(dens * 9 * g);
        for (int k = 0; k < streaks; k++) {
            int layer = rng.nextInt(10) < 4 ? 0 : (rng.nextInt(10) < 6 ? 1 : 2);
            double dist = layer == 0 ? 1.5 + rng.nextDouble() * 4 : layer == 1 ? 5 + rng.nextDouble() * 6 : 11 + rng.nextDouble() * 8;
            double ang = rng.nextDouble() * Math.PI * 2;
            double x = pos.x + Math.cos(ang) * dist, z = pos.z + Math.sin(ang) * dist;
            int bx = (int) Math.floor(x), bz = (int) Math.floor(z);
            int top = mc.world.getTopY(net.minecraft.world.Heightmap.Type.MOTION_BLOCKING, bx, bz);
            if (top <= mc.world.getBottomY() || !rainsAt(mc, bx, top, bz)) continue;
            double y = Math.max(top + 1.0, py + 3.0 + rng.nextDouble() * 6.0);
            if (y <= top + 0.5) continue;
            double speed = layer == 0 ? 1.45 : layer == 1 ? 1.25 : 1.05;
            float size = layer == 0 ? 0.42f : layer == 1 ? 0.32f : 0.24f;
            var fx = new DustColorTransitionParticleEffect(RCOL[layer][0], RCOL[layer][1], size);
            int life = Math.max(2, (int) ((y - top) / speed));
            double len = layer == 0 ? 0.55 : 0.4;
            for (int s2 = 0; s2 < 4; s2++) {
                double off = s2 * len / 3.0;
                add(mc, fx, x - wx * off * 2, y + off, z - wz * off * 2, wx, -speed, wz, life);
            }
        }
        // echte Tropfen
        int drops = (int) Math.ceil(dens * 3 * g);
        for (int k = 0; k < drops; k++) {
            double ang = rng.nextDouble() * Math.PI * 2, dist = 1 + rng.nextDouble() * 7;
            double x = pos.x + Math.cos(ang) * dist, z = pos.z + Math.sin(ang) * dist;
            int bx = (int) Math.floor(x), bz = (int) Math.floor(z);
            int top = mc.world.getTopY(net.minecraft.world.Heightmap.Type.MOTION_BLOCKING, bx, bz);
            if (top <= mc.world.getBottomY() || !rainsAt(mc, bx, top, bz)) continue;
            plain(mc, net.minecraft.particle.ParticleTypes.FALLING_WATER, x, Math.max(top + 1.5, py + 1.0 + rng.nextDouble() * 3.0), z, 0, 0, 0);
        }
        // Boden
        int ground = (int) Math.ceil(dens * 6 * g);
        for (int k = 0; k < ground; k++) {
            double ang = rng.nextDouble() * Math.PI * 2, dist = 0.5 + rng.nextDouble() * 10.0;
            int bx = (int) Math.floor(pos.x + Math.cos(ang) * dist), bz = (int) Math.floor(pos.z + Math.sin(ang) * dist);
            int top = mc.world.getTopY(net.minecraft.world.Heightmap.Type.MOTION_BLOCKING, bx, bz);
            if (top <= mc.world.getBottomY() || !rainsAt(mc, bx, top, bz)) continue;
            double x = bx + rng.nextDouble(), z = bz + rng.nextDouble();
            // Spritzer-Krone: mehrere kleine Tropfen fliegen nach aussen und fallen zurueck
            int crown = 3 + rng.nextInt(3);
            for (int c = 0; c < crown; c++) {
                double a = rng.nextDouble() * Math.PI * 2, sp = 0.03 + rng.nextDouble() * 0.05;
                plain(mc, net.minecraft.particle.ParticleTypes.SPLASH, x, top + 0.05, z, Math.cos(a) * sp, 0.12 + rng.nextDouble() * 0.08, Math.sin(a) * sp);
            }
            if (rng.nextInt(4) == 0) plain(mc, net.minecraft.particle.ParticleTypes.RAIN, x, top + 0.04, z, 0, 0, 0);
            if (rng.nextInt(4) == 0) add(mc, new DustColorTransitionParticleEffect(0xFFFFFF, 0xCFE6FF, 0.3f), x, top + 0.06, z, 0, 0.015, 0, 5);
            if (rng.nextInt(5) == 0) add(mc, new DustColorTransitionParticleEffect(0xE8F2FA, 0xCFE0EE, 1.6f), x, top + 0.15, z, wx * 0.3, 0.004, wz * 0.3, 18);
            // Pfuetze: zwei Ringe, der aeussere versetzt
            if (RINGS.size() < 55 && rng.nextInt(3) == 0) RINGS.add(new double[]{x, top + 0.03, z, 0, 0.7 + rng.nextDouble() * 0.8});
        }
        for (var it = RINGS.iterator(); it.hasNext(); ) {
            double[] r = it.next();
            double sc = r[4];
            double rad = (0.06 + r[3] * 0.055) * sc;
            float sz = (float) Math.max(0.14, 0.34 - r[3] * 0.03);
            int pts = Math.max(10, (int) (10 + rad * 24));
            for (int i = 0; i < pts; i++) {
                double a = i * Math.PI * 2 / pts;
                add(mc, new DustColorTransitionParticleEffect(0xFFFFFF, 0xBFD8F0, sz), r[0] + Math.cos(a) * rad, r[1], r[2] + Math.sin(a) * rad, 0, 0, 0, 2);
            }
            if (r[3] > 2) {
                double rad2 = rad * 0.55;
                for (int i = 0; i < pts / 2; i++) {
                    double a = i * Math.PI * 4 / pts;
                    add(mc, new DustColorTransitionParticleEffect(0xE8F4FF, 0xA9C9E8, sz * 0.8f), r[0] + Math.cos(a) * rad2, r[1], r[2] + Math.sin(a) * rad2, 0, 0, 0, 2);
                }
            }
            if (++r[3] > 9) it.remove();
        }
    }

    public static void tick(MinecraftClient mc) {
        ToastyConfig cfg = ToastyConfig.get();
        if ((!cfg.fxOrbs && !cfg.fxJump && !cfg.blockOutline && !cfg.skeleton && !cfg.rainFx && !cfg.fxAura) || mc.player == null || mc.world == null || mc.isPaused()) { return; }
        var p = mc.player;
        ticks++;
        Vec3d pos = new Vec3d(p.getX(), p.getY(), p.getZ());
        long tk = mc.world.getTime();

        // Luft-Partikel: weiche Lichtkugeln (Anzeige in ToastyAirOrbs.render)
        if (cfg.fxOrbs) ToastyAirOrbs.tick(mc); else ToastyAirOrbs.clear();
        // Jump-Ringe (Stil wie Jessentials): beim Absprung ein einziger duenner, sauberer Ring aus 36 feinen Punkten,
        // der sich ruhig ausbreitet und verschwindet (7 Schritte, kurze Lebensdauer)
        boolean gnd = p.isOnGround();
        if (cfg.fxJump && jumpPrevGround && !gnd && p.getVelocity().y > 0.02) { jumps++; JUMP.add(new double[]{p.getX(), p.getY(), p.getZ(), 0}); while (JUMP.size() > 3) JUMP.remove(0); }
        jumpPrevGround = gnd;
        if (!cfg.fxJump) JUMP.clear();
        for (var it = JUMP.iterator(); it.hasNext(); ) {
            double[] r = it.next();
            int age = (int) r[3]++;
            float t = (age + 1) / 7f;
            double ease = 1 - (1 - t) * (1 - t);
            double rad = 0.25 + (1.4 - 0.25) * ease;
            int from = ToastyTheme.lerp(ToastyTheme.PURPLE, ToastyTheme.BLUE, t) & 0xFFFFFF;
            var fx = new DustColorTransitionParticleEffect(from, ToastyTheme.BLUE & 0xFFFFFF, 0.55f);
            for (int k = 0; k < 36; k++) {
                double a3 = k * Math.PI * 2 / 36;
                add(mc, fx, r[0] + Math.cos(a3) * rad, r[1] + 0.06, r[2] + Math.sin(a3) * rad, 0, 0, 0, 2);
            }
            if (age + 1 >= 7) it.remove();
        }
        // Block-Kontur: lila Partikel entlang der 12 Kanten des anvisierten Blocks
        if (cfg.blockOutline && tk % 2 == 0 && mc.crosshairTarget instanceof BlockHitResult bhr && bhr.getType() == HitResult.Type.BLOCK) {
            var bp = bhr.getBlockPos();
            for (int a = 0; a < 2; a++) for (int b = 0; b < 2; b++) for (int s = 0; s <= 4; s++) {
                double u = s / 4.0;
                add(mc, effect(0.45f), bp.getX() + u, bp.getY() + a, bp.getZ() + b, 0, 0, 0, 3);
                add(mc, effect(0.45f), bp.getX() + a, bp.getY() + u, bp.getZ() + b, 0, 0, 0, 3);
                add(mc, effect(0.45f), bp.getX() + a, bp.getY() + b, bp.getZ() + u, 0, 0, 0, 3);
            }
        }
        if (cfg.rainFx) rain(mc, cfg, pos); else RINGS.clear();
        if (cfg.fxAura) aura(mc, p);
        ToastyBody.tick(mc, cfg, tk);
    }

    /** Totem-Pop: eigener Partikel-Ausbruch (Aufwaertsfontaene, Ring, Funken) an der Stelle des Pops. */
    public static void totemBurst(MinecraftClient mc, double x, double y, double z) {
        if (mc.world == null) return;
        var r = mc.world.getRandom();
        y += 1.0;
        for (int i = 0; i < 70; i++) {
            double a = r.nextDouble() * Math.PI * 2, sp = 0.05 + r.nextDouble() * 0.28, up = 0.1 + r.nextDouble() * 0.45;
            add(mc, effect(0.9f), x, y + r.nextDouble() * 0.6 - 0.3, z, Math.cos(a) * sp, up, Math.sin(a) * sp, 22 + r.nextInt(16));
        }
        for (int i = 0; i < 36; i++) {
            double a = i * Math.PI * 2 / 36;
            add(mc, new DustColorTransitionParticleEffect(0xFFFFFF, ToastyTheme.PURPLE & 0xFFFFFF, 0.7f), x, y - 0.6, z, Math.cos(a) * 0.35, 0.04, Math.sin(a) * 0.35, 16);
        }
        for (int i = 0; i < 16; i++) plain(mc, net.minecraft.particle.ParticleTypes.END_ROD, x, y, z, (r.nextDouble() - 0.5) * 0.4, 0.15 + r.nextDouble() * 0.3, (r.nextDouble() - 0.5) * 0.4);
    }

    /** Aura: aufsteigende Mint-Funken um den Koerper, in der Ich-Perspektive etwas weiter weg. */
    private static void aura(MinecraftClient mc, net.minecraft.entity.player.PlayerEntity p) {
        auras++;
        var r = p.getRandom();
        boolean first = mc.options.getPerspective().isFirstPerson();
        for (int i = 0; i < 3; i++) {
            double ang = r.nextDouble() * Math.PI * 2, d = (first ? 0.9 : 0.45) + r.nextDouble() * (first ? 1.4 : 0.5);
            double x = p.getX() + Math.cos(ang) * d, z = p.getZ() + Math.sin(ang) * d, y = p.getY() + r.nextDouble() * 1.9;
            add(mc, effect(0.55f), x, y, z, 0, 0.03 + r.nextDouble() * 0.03, 0, 14 + r.nextInt(10));
        }
    }
}
