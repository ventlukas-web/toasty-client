package dev.toasty.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.particle.DustColorTransitionParticleEffect;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;

/** Effekte in Toasty-Farben: Lichtschweif hinter dir (Trail) und Ring beim Landen (Shockwave). Reine Client-Partikel. */
public final class ToastyFx {
    private ToastyFx() {}

    private static boolean wasGround = true, wasSwing = false, jumpPrevGround = true;
    private static int jumpRing = -1;
    private static Vec3d jumpPos = Vec3d.ZERO;
    private static double fallStartY = 0, lastY = 0;
    private static int ringTick = -1;
    private static Vec3d ringPos = Vec3d.ZERO;
    private static Vec3d lastPos = Vec3d.ZERO;

    static ParticleEffect effect(float size) {
        // Uebergang Lila -> Blau (Toasty-Farben); Farbe ohne Alpha
        return new DustColorTransitionParticleEffect(ToastyTheme.PURPLE & 0xFFFFFF, ToastyTheme.BLUE & 0xFFFFFF, size);
    }

    public static void tick(MinecraftClient mc) {
        ToastyConfig cfg = ToastyConfig.get();
        if ((!cfg.fxTrail && !cfg.fxShock && !cfg.fxHalo && !cfg.fxRing && !cfg.aura && !cfg.fxOrbs && !cfg.fxSlash && !cfg.fxJump && !cfg.blockOutline && !cfg.skeleton && !cfg.glass && cfg.weatherMode == 0) || mc.player == null || mc.world == null || mc.isPaused()) { ringTick = -1; return; }
        var p = mc.player;
        Vec3d pos = new Vec3d(p.getX(), p.getY(), p.getZ());

        // Trail: Partikel entlang der zurueckgelegten Strecke, nur bei Bewegung und nicht in der 1. Person ganz vor der Kamera
        if (cfg.fxTrail) {
            double moved = pos.distanceTo(lastPos);
            if (moved > 0.04 && moved < 5) {
                int n = Math.min(6, 1 + (int) (moved * 6));
                for (int i = 0; i < n; i++) {
                    double t = (i + 1) / (double) n;
                    Vec3d q = lastPos.lerp(pos, t);
                    double jx = (Math.random() - 0.5) * 0.25, jy = Math.random() * 0.9, jz = (Math.random() - 0.5) * 0.25;
                    mc.particleManager.addParticle(effect(0.9f), q.x + jx, q.y + 0.1 + jy, q.z + jz, 0, 0.01, 0);
                }
            }
        }

        // Halo: Ring ueber dem Kopf (in der 1. Person nicht sichtbar, daher nur ausserhalb)
        long tk = mc.world.getTime();
        if (cfg.fxHalo && !mc.options.getPerspective().isFirstPerson() && tk % 2 == 0) {
            for (int i = 0; i < 10; i++) {
                double a = tk * 0.08 + i * (Math.PI * 2 / 10);
                mc.particleManager.addParticle(effect(0.7f), pos.x + Math.cos(a) * 0.38, pos.y + p.getHeight() + 0.25, pos.z + Math.sin(a) * 0.38, 0, 0, 0);
            }
        }
        // Luft-Partikel (Ambience): viele weiche Lichtpunkte in verschiedenen Groessen treiben in der Luft um dich, dazu Glitzer
        if (cfg.fxOrbs) {
            int dens = Math.max(1, Math.min(3, cfg.airDensity));
            int n = dens * 2;
            for (int i = 0; i < n; i++) {
                double ang = Math.random() * Math.PI * 2, dist = 1.5 + Math.random() * (7.0 + dens * 3.0);
                double sz = Math.random() < 0.18 ? 2.6 + Math.random() * 1.2 : 0.8 + Math.random() * 1.4; // wenige grosse "Bokeh"-Punkte
                mc.particleManager.addParticle(effect((float) sz), pos.x + Math.cos(ang) * dist, pos.y - 0.5 + Math.random() * 5.5, pos.z + Math.sin(ang) * dist,
                    (Math.random() - 0.5) * 0.02, 0.01 + Math.random() * 0.025, (Math.random() - 0.5) * 0.02);
            }
            if (tk % 4 == 0) for (int i = 0; i < dens; i++) {
                double ang = Math.random() * Math.PI * 2, dist = 1.0 + Math.random() * 9.0;
                mc.particleManager.addParticle(net.minecraft.particle.ParticleTypes.END_ROD, pos.x + Math.cos(ang) * dist, pos.y + Math.random() * 4.0, pos.z + Math.sin(ang) * dist,
                    0, 0.01, 0);
            }
        }
        // Jump Circles: Ring aus Licht am Boden, wo du abspringst
        boolean gnd = p.isOnGround();
        if (cfg.fxJump && jumpPrevGround && !gnd && p.getVelocity().y > 0.05) { jumpRing = 0; jumpPos = pos; }
        jumpPrevGround = gnd;
        if (jumpRing >= 0) {
            if (!cfg.fxJump) jumpRing = -1;
            else {
                double r = 0.4 + jumpRing * 0.2;
                for (int i = 0; i < 24; i++) {
                    double a3 = i * Math.PI * 2 / 24;
                    mc.particleManager.addParticle(effect(1.1f), jumpPos.x + Math.cos(a3) * r, jumpPos.y + 0.05, jumpPos.z + Math.sin(a3) * r, 0, 0.005, 0);
                }
                if (++jumpRing > 9) jumpRing = -1;
            }
        }
        // Wetter (Regen / Schnee / Glut) um dich herum, nur Partikel
        if (cfg.weatherMode > 0) {
            for (int i = 0; i < 14; i++) {
                double ox = (Math.random() - 0.5) * 24, oz = (Math.random() - 0.5) * 24, oy = 4 + Math.random() * 8;
                switch (cfg.weatherMode) {
                    case 1 -> mc.particleManager.addParticle(new DustColorTransitionParticleEffect(0x9CC8FF, 0xE0F0FF, 0.5f), pos.x + ox, pos.y + oy, pos.z + oz, 0, -0.9, 0);
                    case 2 -> mc.particleManager.addParticle(net.minecraft.particle.ParticleTypes.SNOWFLAKE, pos.x + ox, pos.y + oy, pos.z + oz, 0, -0.05, 0);
                    case 5 -> { // Sakura: rosa Blueten schweben schraeg nach unten
                        var pt = mc.particleManager.addParticle(new DustColorTransitionParticleEffect(0xFFB7D5, 0xFF7FB0, 0.9f + (float) Math.random() * 0.5f), pos.x + ox, pos.y + oy, pos.z + oz, 0.03 + Math.random() * 0.03, -0.05, (Math.random() - 0.5) * 0.04);
                        if (pt != null) pt.setMaxAge(90);
                    }
                    case 6 -> mc.particleManager.addParticle(new DustColorTransitionParticleEffect(0xFFC83D, 0xFF8A1F, 0.8f), pos.x + ox, pos.y - 1 + Math.random() * 6, pos.z + oz, (Math.random() - 0.5) * 0.02, 0.02, (Math.random() - 0.5) * 0.02);
                    default -> mc.particleManager.addParticle(new DustColorTransitionParticleEffect(0xFF8A1F, 0xFF3A10, 0.7f), pos.x + ox, pos.y - 1 + Math.random() * 3, pos.z + oz, (Math.random() - 0.5) * 0.02, 0.06, (Math.random() - 0.5) * 0.02);
                }
            }
        }
        // Block-Kontur: lila Partikel entlang der 12 Kanten des anvisierten Blocks
        if (cfg.blockOutline && tk % 2 == 0 && mc.crosshairTarget instanceof BlockHitResult bhr && bhr.getType() == HitResult.Type.BLOCK) {
            var bp = bhr.getBlockPos();
            for (int a = 0; a < 2; a++) for (int b = 0; b < 2; b++) for (int s = 0; s <= 4; s++) {
                double u = s / 4.0;
                mc.particleManager.addParticle(effect(0.45f), bp.getX() + u, bp.getY() + a, bp.getZ() + b, 0, 0, 0);
                mc.particleManager.addParticle(effect(0.45f), bp.getX() + a, bp.getY() + u, bp.getZ() + b, 0, 0, 0);
                mc.particleManager.addParticle(effect(0.45f), bp.getX() + a, bp.getY() + b, bp.getZ() + u, 0, 0, 0);
            }
        }
        ToastyBody.tick(mc, cfg, tk);
        // Schwert-Slash: heller Bogen vor dir, sobald du zuschlaegst
        boolean sw = p.handSwinging;
        if (cfg.fxSlash && sw && !wasSwing) {
            double yaw = Math.toRadians(p.getYaw());
            double fx = -Math.sin(yaw), fz = Math.cos(yaw), rx = Math.cos(yaw), rz = Math.sin(yaw);
            for (int i = 0; i <= 16; i++) {
                double a2 = Math.toRadians(-75 + i * 150.0 / 16);
                double dx = fx * Math.cos(a2) + rx * Math.sin(a2), dz = fz * Math.cos(a2) + rz * Math.sin(a2);
                double r2 = 1.7;
                mc.particleManager.addParticle(effect(1.2f), pos.x + dx * r2, pos.y + 1.0 + Math.sin(a2) * 0.45, pos.z + dz * r2,
                    rx * Math.cos(a2) * 0.05, 0.01, rz * Math.cos(a2) * 0.05);
            }
        }
        wasSwing = sw;
        // Aura: zwei Spiralen aus Partikeln um den Koerper, Farben/Dichte/Groesse einstellbar (nur 3. Person)
        if (cfg.aura && !mc.options.getPerspective().isFirstPerson()) {
            Integer a1 = ToastyTheme.parseHex(cfg.auraColor1), a2 = ToastyTheme.parseHex(cfg.auraColor2);
            int c1 = a1 == null ? (ToastyTheme.PURPLE & 0xFFFFFF) : (a1 & 0xFFFFFF), c2 = a2 == null ? (ToastyTheme.BLUE & 0xFFFFFF) : (a2 & 0xFFFFFF);
            ParticleEffect ae = new DustColorTransitionParticleEffect(c1, c2, 0.8f);
            double rad = 0.45 + 0.2 * cfg.auraSize;
            int n = 1 + cfg.auraDensity;
            for (int k = 0; k < n; k++) {
                double ang = tk * 0.14 + k * Math.PI * 2 / n;
                double hy = ((tk * 0.035 + k / (double) n) % 1.0) * p.getHeight();
                mc.particleManager.addParticle(ae, pos.x + Math.cos(ang) * rad, pos.y + hy, pos.z + Math.sin(ang) * rad, 0, 0.01, 0);
            }
        }
        // Boden-Ring: langsam drehender Ring um die Fuesse
        if (cfg.fxRing && tk % 3 == 0) {
            for (int i = 0; i < 12; i++) {
                double a = -tk * 0.05 + i * (Math.PI * 2 / 12);
                mc.particleManager.addParticle(effect(0.8f), pos.x + Math.cos(a) * 1.1, pos.y + 0.06, pos.z + Math.sin(a) * 1.1, 0, 0, 0);
            }
        }

        // Shockwave: beim Landen nach einem Fall von >= 2.5 Bloecken
        if (cfg.fxShock) {
            boolean ground = p.isOnGround();
            if (!ground && wasGround) fallStartY = p.getY();
            if (!ground) fallStartY = Math.max(fallStartY, p.getY());
            if (ground && !wasGround && fallStartY - p.getY() >= 2.5 && !p.isTouchingWater()) { ringTick = 0; ringPos = pos; }
            wasGround = ground;
            if (ringTick >= 0) {
                double r = 0.6 + ringTick * 0.55;
                int pts = (int) Math.min(48, 14 + ringTick * 4);
                for (int i = 0; i < pts; i++) {
                    double a = i * (Math.PI * 2 / pts) + ringTick * 0.15;
                    mc.particleManager.addParticle(effect(1.2f), ringPos.x + Math.cos(a) * r, ringPos.y + 0.08, ringPos.z + Math.sin(a) * r, 0, 0.02, 0);
                }
                if (++ringTick > 12) ringTick = -1;
            }
        } else { ringTick = -1; wasGround = true; }
        lastPos = pos;
    }
}
