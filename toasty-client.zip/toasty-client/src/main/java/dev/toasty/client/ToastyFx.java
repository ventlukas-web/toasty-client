package dev.toasty.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.particle.DustColorTransitionParticleEffect;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;

/** Effekte in Toasty-Farben: Lichtschweif hinter dir (Trail) und Ring beim Landen (Shockwave). Reine Client-Partikel. */
public final class ToastyFx {
    private ToastyFx() {}

    private static boolean jumpPrevGround = true;
    private static final java.util.ArrayList<double[]> JUMP = new java.util.ArrayList<>();

    static ParticleEffect effect(float size) {
        // Uebergang Lila -> Blau (Toasty-Farben); Farbe ohne Alpha
        return new DustColorTransitionParticleEffect(ToastyTheme.PURPLE & 0xFFFFFF, ToastyTheme.BLUE & 0xFFFFFF, size);
    }

    /** Partikel mit kurzer, eigener Lebensdauer (Dust lebt sonst sehr lange und stapelt sich). */
    static void add(MinecraftClient mc, ParticleEffect e, double x, double y, double z, double vx, double vy, double vz, int maxAge) {
        try {
            var pt = mc.particleManager.addParticle(e, x, y, z, vx, vy, vz);
            if (pt != null) pt.setMaxAge(maxAge);
        } catch (Throwable ignored) {}
    }

    /** Aktive Pfuetzen-Ringe: {x, y, z, Alter}. */
    private static final java.util.ArrayList<double[]> RINGS = new java.util.ArrayList<>();
    private static final int RAIN_DROP = 0xFFCFE6FF;

    /** Realistischerer Regen: fallende Tropfen-Streifen, Spritzer und sich ausbreitende Pfuetzen-Ringe am Boden (nur Client-Partikel). */
    private static void rain(MinecraftClient mc, ToastyConfig cfg, Vec3d pos) {
        float g = mc.world.getRainGradient(1f);
        if (g < 0.15f) { RINGS.clear(); return; }
        int dens = Math.max(1, Math.min(3, cfg.rainDensity));
        int n = (int) Math.ceil(dens * 6 * g);
        var rng = mc.world.getRandom();
        for (int i = 0; i < n; i++) {
            double ang = rng.nextDouble() * Math.PI * 2, dist = 0.5 + rng.nextDouble() * 11.0;
            int bx = (int) Math.floor(pos.x + Math.cos(ang) * dist), bz = (int) Math.floor(pos.z + Math.sin(ang) * dist);
            int top = mc.world.getTopY(net.minecraft.world.Heightmap.Type.MOTION_BLOCKING, bx, bz);
            if (top <= mc.world.getBottomY()) continue;
            var bp = new net.minecraft.util.math.BlockPos(bx, top, bz);
            if (!mc.world.getBiome(bp).value().hasPrecipitation()) continue;
            double x = bx + rng.nextDouble(), z = bz + rng.nextDouble();
            // Tropfen-Streifen: fallen schnell von oberhalb des Kopfes bis zum Boden
            double y0 = Math.min(top + 9.0, pos.y + 7.0 + rng.nextDouble() * 3.0);
            if (y0 > top + 0.3) add(mc, new DustColorTransitionParticleEffect(RAIN_DROP & 0xFFFFFF, 0x9CC8F0, 0.5f), x, y0, z, 0, -0.9, 0, Math.max(2, (int) ((y0 - top) / 0.9)));
            // Spritzer am Boden
            if (rng.nextInt(2) == 0) mc.particleManager.addParticle(net.minecraft.particle.ParticleTypes.RAIN, x, top + 0.02, z, 0, 0, 0);
            // Pfuetzen-Ring (breitet sich aus, spiegelt das helle Himmelslicht)
            if (RINGS.size() < 40 && rng.nextInt(3) == 0) RINGS.add(new double[]{x, top + 0.03, z, 0});
        }
        for (var it = RINGS.iterator(); it.hasNext(); ) {
            double[] r = it.next();
            double rad = 0.08 + r[3] * 0.06;
            int pts = 10;
            for (int i = 0; i < pts; i++) {
                double a = i * Math.PI * 2 / pts;
                add(mc, new DustColorTransitionParticleEffect(0xFFFFFF, 0xBFD8F0, 0.35f), r[0] + Math.cos(a) * rad, r[1], r[2] + Math.sin(a) * rad, 0, 0, 0, 2);
            }
            if (++r[3] > 7) it.remove();
        }
    }

    public static void tick(MinecraftClient mc) {
        ToastyConfig cfg = ToastyConfig.get();
        if ((!cfg.fxOrbs && !cfg.fxJump && !cfg.blockOutline && !cfg.skeleton && !cfg.rainFx) || mc.player == null || mc.world == null || mc.isPaused()) { return; }
        var p = mc.player;
        Vec3d pos = new Vec3d(p.getX(), p.getY(), p.getZ());
        long tk = mc.world.getTime();

        // Luft-Partikel: weiche Lichtkugeln (Anzeige in ToastyAirOrbs.render)
        if (cfg.fxOrbs) ToastyAirOrbs.tick(mc); else ToastyAirOrbs.clear();
        // Jump-Ringe (Stil wie Jessentials): beim Absprung ein einziger duenner, sauberer Ring aus 36 feinen Punkten,
        // der sich ruhig ausbreitet und verschwindet (7 Schritte, kurze Lebensdauer)
        boolean gnd = p.isOnGround();
        if (cfg.fxJump && jumpPrevGround && !gnd && p.getVelocity().y > 0.02) { JUMP.add(new double[]{p.getX(), p.getY(), p.getZ(), 0}); while (JUMP.size() > 3) JUMP.remove(0); }
        jumpPrevGround = gnd;
        if (!cfg.fxJump) JUMP.clear();
        for (var it = JUMP.iterator(); it.hasNext(); ) {
            double[] r = it.next();
            int age = (int) r[3]++;
            float t = (age + 1) / 7f;
            double ease = 1 - (1 - t) * (1 - t);
            double rad = 0.25 + (1.4 - 0.25) * ease;
            int from = ToastyTheme.lerp(ToastyTheme.PURPLE, ToastyTheme.BLUE, t) & 0xFFFFFF;
            var fx = new DustColorTransitionParticleEffect(from, ToastyTheme.BLUE & 0xFFFFFF, 0.55f);
            for (int k = 0; k < 36; k++) {
                double a3 = k * Math.PI * 2 / 36;
                add(mc, fx, r[0] + Math.cos(a3) * rad, r[1] + 0.06, r[2] + Math.sin(a3) * rad, 0, 0, 0, 2);
            }
            if (age + 1 >= 7) it.remove();
        }
        // Block-Kontur: lila Partikel entlang der 12 Kanten des anvisierten Blocks
        if (cfg.blockOutline && tk % 2 == 0 && mc.crosshairTarget instanceof BlockHitResult bhr && bhr.getType() == HitResult.Type.BLOCK) {
            var bp = bhr.getBlockPos();
            for (int a = 0; a < 2; a++) for (int b = 0; b < 2; b++) for (int s = 0; s <= 4; s++) {
                double u = s / 4.0;
                add(mc, effect(0.45f), bp.getX() + u, bp.getY() + a, bp.getZ() + b, 0, 0, 0, 3);
                add(mc, effect(0.45f), bp.getX() + a, bp.getY() + u, bp.getZ() + b, 0, 0, 0, 3);
                add(mc, effect(0.45f), bp.getX() + a, bp.getY() + b, bp.getZ() + u, 0, 0, 0, 3);
            }
        }
        if (cfg.rainFx) rain(mc, cfg, pos); else RINGS.clear();
        ToastyBody.tick(mc, cfg, tk);
    }
}
