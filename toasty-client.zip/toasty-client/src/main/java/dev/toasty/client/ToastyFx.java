package dev.toasty.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.particle.DustColorTransitionParticleEffect;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;

/** Effekte in Toasty-Farben: Lichtschweif hinter dir (Trail) und Ring beim Landen (Shockwave). Reine Client-Partikel. */
public final class ToastyFx {
    private ToastyFx() {}

    private static boolean jumpPrevGround = true;
    private static int jumpRing = -1;
    private static Vec3d jumpPos = Vec3d.ZERO;

    static ParticleEffect effect(float size) {
        // Uebergang Lila -> Blau (Toasty-Farben); Farbe ohne Alpha
        return new DustColorTransitionParticleEffect(ToastyTheme.PURPLE & 0xFFFFFF, ToastyTheme.BLUE & 0xFFFFFF, size);
    }

    /** Partikel mit kurzer, eigener Lebensdauer (Dust lebt sonst sehr lange und stapelt sich). */
    static void add(MinecraftClient mc, ParticleEffect e, double x, double y, double z, double vx, double vy, double vz, int maxAge) {
        try {
            var pt = mc.particleManager.addParticle(e, x, y, z, vx, vy, vz);
            if (pt != null) pt.setMaxAge(maxAge);
        } catch (Throwable ignored) {}
    }

    /** Aktive Pfuetzen-Ringe: {x, y, z, Alter}. */
    private static final java.util.ArrayList<double[]> RINGS = new java.util.ArrayList<>();
    private static final int RAIN_DROP = 0xFFCFE6FF;

    /** Realistischerer Regen: fallende Tropfen-Streifen, Spritzer und sich ausbreitende Pfuetzen-Ringe am Boden (nur Client-Partikel). */
    private static void rain(MinecraftClient mc, ToastyConfig cfg, Vec3d pos) {
        float g = mc.world.getRainGradient(1f);
        if (g < 0.15f) { RINGS.clear(); return; }
        int dens = Math.max(1, Math.min(3, cfg.rainDensity));
        int n = (int) Math.ceil(dens * 6 * g);
        var rng = mc.world.getRandom();
        for (int i = 0; i < n; i++) {
            double ang = rng.nextDouble() * Math.PI * 2, dist = 0.5 + rng.nextDouble() * 11.0;
            int bx = (int) Math.floor(pos.x + Math.cos(ang) * dist), bz = (int) Math.floor(pos.z + Math.sin(ang) * dist);
            int top = mc.world.getTopY(net.minecraft.world.Heightmap.Type.MOTION_BLOCKING, bx, bz);
            if (top <= mc.world.getBottomY()) continue;
            var bp = new net.minecraft.util.math.BlockPos(bx, top, bz);
            if (!mc.world.getBiome(bp).value().hasPrecipitation()) continue;
            double x = bx + rng.nextDouble(), z = bz + rng.nextDouble();
            // Tropfen-Streifen: fallen schnell von oberhalb des Kopfes bis zum Boden
            double y0 = Math.min(top + 9.0, pos.y + 7.0 + rng.nextDouble() * 3.0);
            if (y0 > top + 0.3) add(mc, new DustColorTransitionParticleEffect(RAIN_DROP & 0xFFFFFF, 0x9CC8F0, 0.5f), x, y0, z, 0, -0.9, 0, Math.max(2, (int) ((y0 - top) / 0.9)));
            // Spritzer am Boden
            if (rng.nextInt(2) == 0) mc.particleManager.addParticle(net.minecraft.particle.ParticleTypes.RAIN, x, top + 0.02, z, 0, 0, 0);
            // Pfuetzen-Ring (breitet sich aus, spiegelt das helle Himmelslicht)
            if (RINGS.size() < 40 && rng.nextInt(3) == 0) RINGS.add(new double[]{x, top + 0.03, z, 0});
        }
        for (var it = RINGS.iterator(); it.hasNext(); ) {
            double[] r = it.next();
            double rad = 0.08 + r[3] * 0.06;
            int pts = 10;
            for (int i = 0; i < pts; i++) {
                double a = i * Math.PI * 2 / pts;
                add(mc, new DustColorTransitionParticleEffect(0xFFFFFF, 0xBFD8F0, 0.35f), r[0] + Math.cos(a) * rad, r[1], r[2] + Math.sin(a) * rad, 0, 0, 0, 2);
            }
            if (++r[3] > 7) it.remove();
        }
    }

    public static void tick(MinecraftClient mc) {
        ToastyConfig cfg = ToastyConfig.get();
        if ((!cfg.fxOrbs && !cfg.fxJump && !cfg.blockOutline && !cfg.skeleton && !cfg.rainFx) || mc.player == null || mc.world == null || mc.isPaused()) { return; }
        var p = mc.player;
        Vec3d pos = new Vec3d(p.getX(), p.getY(), p.getZ());
        long tk = mc.world.getTime();

        // Luft-Partikel (Ambience): viele weiche Lichtpunkte in verschiedenen Groessen treiben in der Luft um dich, dazu Glitzer
        if (cfg.fxOrbs) {
            int dens = Math.max(1, Math.min(3, cfg.airDensity));
            int n = dens * 2;
            for (int i = 0; i < n; i++) {
                double ang = Math.random() * Math.PI * 2, dist = 1.5 + Math.random() * (7.0 + dens * 3.0);
                double sz = Math.random() < 0.18 ? 2.6 + Math.random() * 1.2 : 0.8 + Math.random() * 1.4; // wenige grosse "Bokeh"-Punkte
                add(mc, effect((float) sz), pos.x + Math.cos(ang) * dist, pos.y - 0.5 + Math.random() * 5.5, pos.z + Math.sin(ang) * dist,
                    (Math.random() - 0.5) * 0.02, 0.01 + Math.random() * 0.025, (Math.random() - 0.5) * 0.02, 30 + (int) (Math.random() * 25));
            }
            if (tk % 4 == 0) for (int i = 0; i < dens; i++) {
                double ang = Math.random() * Math.PI * 2, dist = 1.0 + Math.random() * 9.0;
                mc.particleManager.addParticle(net.minecraft.particle.ParticleTypes.END_ROD, pos.x + Math.cos(ang) * dist, pos.y + Math.random() * 4.0, pos.z + Math.sin(ang) * dist,
                    0, 0.01, 0);
            }
        }
        // Jump Circles: Ring aus Licht am Boden, wo du abspringst
        boolean gnd = p.isOnGround();
        if (cfg.fxJump && jumpPrevGround && !gnd && p.getVelocity().y > 0.05) { jumpRing = 0; jumpPos = pos; }
        jumpPrevGround = gnd;
        if (jumpRing >= 0) {
            if (!cfg.fxJump) jumpRing = -1;
            else {
                double r = 0.4 + jumpRing * 0.2;
                for (int i = 0; i < 24; i++) {
                    double a3 = i * Math.PI * 2 / 24;
                    add(mc, effect(1.1f), jumpPos.x + Math.cos(a3) * r, jumpPos.y + 0.05, jumpPos.z + Math.sin(a3) * r, 0, 0.005, 0, 6);
                }
                if (++jumpRing > 9) jumpRing = -1;
            }
        }
        // Block-Kontur: lila Partikel entlang der 12 Kanten des anvisierten Blocks
        if (cfg.blockOutline && tk % 2 == 0 && mc.crosshairTarget instanceof BlockHitResult bhr && bhr.getType() == HitResult.Type.BLOCK) {
            var bp = bhr.getBlockPos();
            for (int a = 0; a < 2; a++) for (int b = 0; b < 2; b++) for (int s = 0; s <= 4; s++) {
                double u = s / 4.0;
                add(mc, effect(0.45f), bp.getX() + u, bp.getY() + a, bp.getZ() + b, 0, 0, 0, 3);
                add(mc, effect(0.45f), bp.getX() + a, bp.getY() + u, bp.getZ() + b, 0, 0, 0, 3);
                add(mc, effect(0.45f), bp.getX() + a, bp.getY() + b, bp.getZ() + u, 0, 0, 0, 3);
            }
        }
        if (cfg.rainFx) rain(mc, cfg, pos); else RINGS.clear();
        ToastyBody.tick(mc, cfg, tk);
    }
}
