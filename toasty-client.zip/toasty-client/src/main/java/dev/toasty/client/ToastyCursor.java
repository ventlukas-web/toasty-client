package dev.toasty.client;

import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import org.lwjgl.BufferUtils;
import org.lwjgl.glfw.GLFW;
import org.lwjgl.glfw.GLFWImage;

import java.nio.ByteBuffer;

/**
 * Eigener Mauszeiger in allen Menues. Die Formen sind ECHTE Hardware-Cursor (GLFW-Cursor-Bild): sie laufen ohne Verzoegerung
 * mit der Maus, egal wie niedrig die FPS sind. Nur "Toast" und "Regenbogen" (Logo/Animation) werden weiter im Bild gezeichnet.
 */
public final class ToastyCursor {
    public static final String[] STYLES = {"Standard", "Pfeil", "Kreuz", "Ring", "Punkt", "Toast", "Raute", "Stern", "Herz", "Fadenkreuz", "Regenbogen"};
    public static final float[] SIZES = {1f, 1.5f, 2f, 3f, 0.75f};

    private ToastyCursor() {}

    public static void register() {
        ScreenEvents.AFTER_INIT.register((client, screen, w, h) ->
            ScreenEvents.afterRender(screen).register((s, ctx, mx, my, delta) -> draw(ctx, client, mx, my)));
    }

    private static boolean hidden;
    private static long cursorHandle;
    private static String cursorKey = "";
    private static int lastStyle = -1, lastC1, lastC2;
    private static float lastSc;

    // ---------- Hardware-Cursor: Form in ein Pixelbild zeichnen ----------
    private static final int S = 40, O = 20;
    private static int[] buf;

    private static void fill(int x0, int y0, int x1, int y1, int c) {
        for (int y = y0; y < y1; y++) for (int x = x0; x < x1; x++) {
            int px = O + x, py = O + y;
            if (px >= 0 && py >= 0 && px < S && py < S) buf[py * S + px] = c;
        }
    }

    private static void disc(double r, int c) {
        for (int y = -O; y < O; y++) for (int x = -O; x < O; x++)
            if ((x + 0.5) * (x + 0.5) + (y + 0.5) * (y + 0.5) <= r * r) fill(x, y, x + 1, y + 1, c);
    }

    private static void ring(double rOut, double rIn, int c) {
        for (int y = -O; y < O; y++) for (int x = -O; x < O; x++) {
            double d = (x + 0.5) * (x + 0.5) + (y + 0.5) * (y + 0.5);
            if (d <= rOut * rOut && d >= rIn * rIn) fill(x, y, x + 1, y + 1, c);
        }
    }

    /** Zeichnet den Stil in buf (Mittelpunkt = O,O). Rueckgabe: Hotspot-Versatz (0 = Mitte, 1 = Pfeilspitze). */
    private static int paint(int style, int c1, int c2) {
        int shadow = 0xC0000000, white = 0xFFFFFFFF, mid = ToastyTheme.lerp(c1, c2, 0.5f);
        switch (style) {
            case 1 -> {
                for (int r = 0; r < 14; r++) { int wd = r < 10 ? r + 1 : 3, x0 = r < 10 ? 0 : 3; fill(-6 + x0 - 1, -6 + r - 1, -6 + x0 + wd + 1, -6 + r + 2, shadow); }
                for (int r = 0; r < 14; r++) { int wd = r < 10 ? r + 1 : 3, x0 = r < 10 ? 0 : 3; fill(-6 + x0, -6 + r, -6 + x0 + wd, -6 + r + 1, ToastyTheme.lerp(c1, c2, r / 13f)); }
                return 1;
            }
            case 2 -> {
                int g = 3, l = 6;
                int[][] arms = {{-g - l, -1, -g, 1}, {g, -1, g + l, 1}, {-1, -g - l, 1, -g}, {-1, g, 1, g + l}};
                for (int[] a : arms) fill(a[0] - 1, a[1] - 1, a[2] + 1, a[3] + 1, shadow);
                for (int i = 0; i < 4; i++) { int[] a = arms[i]; fill(a[0], a[1], a[2], a[3], ToastyTheme.lerp(c1, c2, i / 3f)); }
            }
            case 3 -> { ring(8, 6, shadow); ring(7.4, 6.6, mid); fill(-2, -2, 2, 2, shadow); fill(-1, -1, 1, 1, white); }
            case 4 -> { disc(3, shadow); disc(2, mid); }
            case 6 -> {
                for (int pass = 0; pass < 2; pass++) for (int r = -7; r <= 7; r++) {
                    int half = 7 - Math.abs(r), e = pass == 0 ? 1 : 0;
                    fill(-half - e, r - e, half + 1 + e, r + 1 + e, pass == 0 ? shadow : ToastyTheme.lerp(c1, c2, (r + 7) / 14f));
                }
            }
            case 7 -> {
                for (int pass = 0; pass < 2; pass++) for (int r = -9; r <= 9; r++) {
                    int half = (int) Math.round(9 * Math.pow(1 - Math.abs(r) / 10.0, 3)), e = pass == 0 ? 1 : 0;
                    fill(-half - e, r - e, half + 1 + e, r + 1 + e, pass == 0 ? shadow : ToastyTheme.lerp(c1, c2, (r + 9) / 18f));
                }
            }
            case 8 -> {
                String[] h = {".XX.XX.", "XXXXXXX", "XXXXXXX", ".XXXXX.", "..XXX..", "...X..."};
                for (int pass = 0; pass < 2; pass++) for (int r = 0; r < h.length; r++) for (int cx = 0; cx < 7; cx++) {
                    if (h[r].charAt(cx) != 'X') continue;
                    int e = pass == 0 ? 1 : 0;
                    fill(cx * 2 - 7 - e, r * 2 - 6 - e, cx * 2 - 5 + e, r * 2 - 4 + e, pass == 0 ? shadow : ToastyTheme.lerp(0xFFFF5C8A, 0xFFB14CFF, r / 5f));
                }
                fill(-5, -5, -3, -3, 0xAAFFFFFF);
            }
            case 9 -> {
                int g = 3, l = 6;
                int[][] arms = {{-g - l, 0, -g, 1}, {g, 0, g + l, 1}, {0, -g - l, 1, -g}, {0, g, 1, g + l}};
                for (int[] a : arms) fill(a[0] - 1, a[1] - 1, a[2] + 1, a[3] + 1, shadow);
                for (int[] a : arms) fill(a[0], a[1], a[2], a[3], white);
                fill(-1, -1, 2, 2, shadow); fill(0, 0, 1, 1, mid);
            }
            default -> { }
        }
        return 0;
    }

    /** Erzeugt (bei Aenderung) den GLFW-Cursor und setzt ihn. */
    private static void applyHardware(long win, int style, float sc, int c1, int c2) {
        if (cursorHandle != 0 && style == lastStyle && sc == lastSc && c1 == lastC1 && c2 == lastC2) return;
        lastStyle = style; lastSc = sc; lastC1 = c1; lastC2 = c2;
        String key = style + "|" + sc;
        buf = new int[S * S];
        int hot = paint(style, c1, c2);
        int n = Math.max(8, Math.round(S * sc));
        ByteBuffer px = BufferUtils.createByteBuffer(n * n * 4);
        for (int y = 0; y < n; y++) for (int x = 0; x < n; x++) {
            int c = buf[Math.min(S - 1, (int) (y / sc)) * S + Math.min(S - 1, (int) (x / sc))];
            px.put((byte) ((c >> 16) & 255)).put((byte) ((c >> 8) & 255)).put((byte) (c & 255)).put((byte) ((c >>> 24) & 255));
        }
        px.flip();
        GLFWImage img = GLFWImage.malloc();
        img.set(n, n, px);
        int hx = hot == 1 ? Math.round((O - 6) * sc) : Math.round(O * sc), hy = hx;
        long cur = GLFW.glfwCreateCursor(img, hx, hy);
        img.free();
        if (cur == 0) return;
        GLFW.glfwSetCursor(win, cur);
        if (cursorHandle != 0) GLFW.glfwDestroyCursor(cursorHandle);
        cursorHandle = cur;
        cursorKey = key;
    }

    private static void resetHardware(long win) {
        if (cursorHandle != 0) { GLFW.glfwSetCursor(win, 0); GLFW.glfwDestroyCursor(cursorHandle); cursorHandle = 0; cursorKey = ""; lastStyle = -1; }
    }

    private static void draw(DrawContext ctx, MinecraftClient mc, int mx, int my) {
        ToastyConfig cfg = ToastyConfig.get();
        long win = mc.getWindow().getHandle();
        int style = Math.floorMod(cfg.cursorStyle, STYLES.length);
        float sc = SIZES[Math.floorMod(cfg.cursorSize, SIZES.length)];
        if (style == 0) {
            resetHardware(win);
            if (hidden) { GLFW.glfwSetInputMode(win, GLFW.GLFW_CURSOR, GLFW.GLFW_CURSOR_NORMAL); hidden = false; }
            return;
        }
        if (style != 5 && style != 10) {
            // Hardware-Cursor: kein Nachziehen
            if (hidden) { GLFW.glfwSetInputMode(win, GLFW.GLFW_CURSOR, GLFW.GLFW_CURSOR_NORMAL); hidden = false; }
            try { applyHardware(win, style, sc, ToastyTheme.PURPLE, ToastyTheme.BLUE); } catch (Throwable t) { resetHardware(win); }
            return;
        }
        // Toast / Regenbogen: im Bild gezeichnet
        resetHardware(win);
        if (GLFW.glfwGetInputMode(win, GLFW.GLFW_CURSOR) != GLFW.GLFW_CURSOR_HIDDEN) GLFW.glfwSetInputMode(win, GLFW.GLFW_CURSOR, GLFW.GLFW_CURSOR_HIDDEN);
        hidden = true;
        double[] cx = new double[1], cy = new double[1];
        GLFW.glfwGetCursorPos(win, cx, cy);
        float gx = (float) (cx[0] * mc.getWindow().getScaledWidth() / Math.max(1, mc.getWindow().getWidth()));
        float gy = (float) (cy[0] * mc.getWindow().getScaledHeight() / Math.max(1, mc.getWindow().getHeight()));
        var m = ctx.getMatrices();
        m.pushMatrix();
        m.translate(gx, gy);
        m.scale(sc, sc);
        int shadow = 0xC0000000;
        if (style == 10) {
            int col = 0xFF000000 | java.awt.Color.HSBtoRGB((System.currentTimeMillis() / 12 % 360) / 360f, 0.65f, 1f);
            ToastyTheme.roundRectExact(ctx, -5, -5, 10, 10, 5, shadow);
            ToastyTheme.roundRectExact(ctx, -4, -4, 8, 8, 4, col);
            ctx.fill(-2, -3, 0, -2, 0xCCFFFFFF);
        } else ToastyLogo.draw(ctx, 0, 0, 18);
        m.popMatrix();
    }
}
