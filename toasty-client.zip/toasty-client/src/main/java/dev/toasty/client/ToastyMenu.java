package dev.toasty.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Supplier;

/** Mod-Menue mit allen Funktionen des Toasty Clients. */
public class ToastyMenu extends ToastyScreen {
    private static final int PW = 300;
    private static final String[] TABS = {"General", "Gamble", "HUD", "Design", "Visuals", "FPS", "Lyrics", "Sell", "Extras", "Twitch", "Notizen"};
    private static int tab = 0;
    private final Screen parent;

    private record Label(String text, int x, int y, int color) {}
    private final List<Label> labels = new ArrayList<>();
    private int left, top;
    private boolean glassOn;

    public ToastyMenu(Screen parent) {
        super(Text.literal("Toasty Client"));
        this.parent = parent;
    }

    @Override
    protected void build() {
        labels.clear();
        left = width / 2 - PW / 2;
        top = Math.max(32, (height - 302) / 2 + 28);

        int tw = PW / 4;
        for (int i = 0; i < TABS.length; i++) {
            final int idx = i;
            button(() -> TABS[idx], () -> { tab = idx; clearAndInit(); },
                left + (i % 4) * tw, top + (i / 4) * 21, tw - 2, 19, tab == i);
        }
        int y = top + 66;
        switch (tab) {
            case 0 -> generalTab(y);
            case 1 -> gambleTab(y);
            case 2 -> hudTab(y);
            case 3 -> designTab(y);
            case 4 -> visualsTab(y);
            case 5 -> perfTab(y);
            case 6 -> lyricsTab(y);
            case 7 -> sellTab(y);
            case 8 -> extrasTab(y);
            case 9 -> eventsTab(y);
            default -> notesTab(y);
        }
        button(() -> "Tasten …", () -> MinecraftClient.getInstance().setScreen(new ToastyKeysScreen(this)), left, top + 242, 96, 20, true);
        button(() -> "Schließen", this::close, left + 102, top + 242, 96, 20);
        button(() -> "HUD verschieben", () -> MinecraftClient.getInstance().setScreen(new ToastyHudEditor(this)), left + 204, top + 242, 96, 20, true);
    }

    // ---------- General ----------

    private void generalTab(int y) {
        ToastyConfig c = ToastyConfig.get();
        MinecraftClient mc = MinecraftClient.getInstance();
        button(() -> "Rechner öffnen", () -> mc.setScreen(new ToastyCalculatorScreen(this)), left, y, 146, 20, true);
        button(() -> "Tasten ändern …", () -> mc.setScreen(new ToastyKeysScreen(this)), left + 154, y, 146, 20, true);
        y += 24;
        button(() -> "HUD verschieben", () -> mc.setScreen(new ToastyHudEditor(this)), left, y, 146, 20, true);
        toggle("Modul-Liste", () -> c.moduleList, v -> { c.moduleList = v; c.save(); }, left + 154, y, 146);
        y += 24;
        button(() -> "HUD kleiner", () -> { c.hudScale = Math.max(0.5f, Math.round((c.hudScale - 0.1f) * 10) / 10f); c.save(); }, left, y, 146, 20);
        button(() -> "HUD größer (" + c.hudScale + ")", () -> { c.hudScale = Math.min(3f, Math.round((c.hudScale + 0.1f) * 10) / 10f); c.save(); }, left + 154, y, 146, 20);
        y += 24;
        toggle("Stats-HUD", () -> c.hud, v -> { c.hud = v; c.save(); }, left, y, 146);
        toggle("Zahlungs-HUD", () -> c.payHud, v -> { c.payHud = v; c.save(); }, left + 154, y, 146);
        y += 24;
        toggle("Keystrokes", () -> c.keystrokes, v -> { c.keystrokes = v; c.save(); }, left, y, 146);
        toggle("Koordinaten", () -> c.coords, v -> { c.coords = v; c.save(); }, left + 154, y, 146);
        y += 24;
        toggle("Benachrichtigungen", () -> c.notify, v -> { c.notify = v; c.save(); }, left, y, 146);
        toggle("Wasserzeichen", () -> c.watermark, v -> { c.watermark = v; c.save(); }, left + 154, y, 146);
    }

    // ---------- Gamble ----------

    private void gambleTab(int y) {
        ToastyConfig c = ToastyConfig.get();
        labels.add(new Label("Mindesteinsatz", left, y, ToastyTheme.MUTED));
        labels.add(new Label("Höchsteinsatz (leer = unbegrenzt)", left + 152, y, ToastyTheme.MUTED));
        field(left, y + 10, 146, c.minBet == 0 ? "" : ToastyStats.fmt(c.minBet), s -> {
            Long v = parseAmount(s); c.minBet = v == null ? 0 : v; c.save();
        });
        field(left + 154, y + 10, 146, c.maxBet == Long.MAX_VALUE ? "" : ToastyStats.fmt(c.maxBet), s -> {
            Long v = parseAmount(s); c.maxBet = v == null ? Long.MAX_VALUE : v; c.save();
        });

        y += 36;
        labels.add(new Label("Gewinn-Multiplikator", left, y, ToastyTheme.MUTED));
        labels.add(new Label("2.0 = Einsatz x2 wird ausgezahlt", left + 152, y + 14, ToastyTheme.MUTED));
        field(left, y + 10, 146, String.valueOf(c.winMultiplier), s -> {
            try { c.winMultiplier = Double.parseDouble(s.replace(',', '.')); c.save(); } catch (Exception ignored) {}
        });

        y += 36;
        labels.add(new Label("Chat-Muster (Regex mit player, amount, suffix)", left, y, ToastyTheme.MUTED));
        TextFieldWidget f = field(left, y + 10, PW, c.pattern, s -> {
            try { java.util.regex.Pattern.compile(s); c.pattern = s; c.save(); } catch (Exception ignored) {}
        });
        f.setMaxLength(400);

        y += 38;
        button(() -> "Gewinn (letzter)", () -> ToastyGamble.chat(ToastyGamble.settle(null, true)), left, y, 96, 20, true);
        button(() -> "Verlust (letzter)", () -> ToastyGamble.chat(ToastyGamble.settle(null, false)), left + 102, y, 96, 20, true);
        button(() -> "Statistik reset", () -> { ToastyStats.reset(); ToastyGamble.chat("Statistik zurückgesetzt."); }, left + 204, y, 96, 20);
        toggle("Auto-Auszahlung bei /win", () -> c.autoPay, v -> { c.autoPay = v; c.save(); }, left, y + 24, PW);
        labels.add(new Label("Befehle: /win /lose [Spieler] · /toasty stats|debug", left, y + 48, ToastyTheme.MUTED));
    }

    // ---------- HUD ----------

    private void hudTab(int y) {
        ToastyConfig c = ToastyConfig.get();
        toggle("Stats-HUD", () -> c.hud, v -> { c.hud = v; c.save(); }, left, y, 146);
        toggle("Keystrokes", () -> c.keystrokes, v -> { c.keystrokes = v; c.save(); }, left + 154, y, 146);
        y += 24;
        toggle("Koordinaten", () -> c.coords, v -> { c.coords = v; c.save(); }, left, y, 146);
        toggle("FPS", () -> c.showFps, v -> { c.showFps = v; c.save(); }, left + 154, y, 146);
        y += 24;
        toggle("Ping", () -> c.ping, v -> { c.ping = v; c.save(); }, left, y, 146);
        toggle("Speed", () -> c.speed, v -> { c.speed = v; c.save(); }, left + 154, y, 146);
        y += 24;
        toggle("Uhrzeit", () -> c.clock, v -> { c.clock = v; c.save(); }, left, y, 146);
        toggle("Modul-Liste", () -> c.moduleList, v -> { c.moduleList = v; c.save(); }, left + 154, y, 146);
        y += 24;
        toggle("Zahlungs-HUD", () -> c.payHud, v -> { c.payHud = v; c.save(); }, left, y, 146);
        toggle("Twitch-Chat", () -> c.twitch, v -> { c.twitch = v; c.save(); }, left + 154, y, 146);
        y += 28;
        button(() -> "HUD kleiner", () -> { c.hudScale = Math.max(0.5f, Math.round((c.hudScale - 0.1f) * 10) / 10f); c.save(); }, left, y, 146, 20);
        button(() -> "HUD größer", () -> { c.hudScale = Math.min(3f, Math.round((c.hudScale + 0.1f) * 10) / 10f); c.save(); }, left + 154, y, 146, 20);
    }

    // ---------- Design ----------

    private static final String[][] PRESETS = {
        {"Lila-Blau", "#A855F7", "#7DD3FC"},
        {"Sunset", "#FB7185", "#FBBF24"},
        {"Mint", "#34D399", "#7DD3FC"},
        {"Neon", "#F472B6", "#22D3EE"},
        {"Feuer", "#EF4444", "#F97316"},
        {"Gold", "#F59E0B", "#FDE68A"},
    };

    private void designTab(int y) {
        ToastyConfig c = ToastyConfig.get();
        labels.add(new Label("Vorlagen", left, y, ToastyTheme.MUTED));
        for (int i = 0; i < PRESETS.length; i++) {
            final String[] p = PRESETS[i];
            int bx = left + (i % 2) * 154, by = y + 11 + (i / 2) * 22;
            button(() -> p[0], () -> {
                c.color1 = p[1]; c.color2 = p[2]; c.save(); ToastyTheme.reload(c); clearAndInit();
            }, bx, by, 146, 20);
        }
        int y1 = y + 82;
        labels.add(new Label("Farbe 1 (#RRGGBB)", left, y1, ToastyTheme.MUTED));
        labels.add(new Label("Farbe 2 (#RRGGBB)", left + 154, y1, ToastyTheme.MUTED));
        field(left, y1 + 10, 146, c.color1, s -> {
            Integer v = ToastyTheme.parseHex(s);
            if (v != null) { c.color1 = ToastyTheme.toHex(v); c.save(); ToastyTheme.reload(c); }
        });
        field(left + 154, y1 + 10, 146, c.color2, s -> {
            Integer v = ToastyTheme.parseHex(s);
            if (v != null) { c.color2 = ToastyTheme.toHex(v); c.save(); ToastyTheme.reload(c); }
        });
        int y2 = y + 124;
        button(() -> "Hintergrund heller", () -> { c.bgOpacity = Math.max(32, c.bgOpacity - 24); c.save(); ToastyTheme.reload(c); }, left, y2, 146, 20);
        button(() -> "Hintergrund dunkler", () -> { c.bgOpacity = Math.min(255, c.bgOpacity + 24); c.save(); ToastyTheme.reload(c); }, left + 154, y2, 146, 20);
    }

    // ---------- Visuals ----------

    private void visualsTab(int y) {
        ToastyConfig c = ToastyConfig.get();
        toggle("Sound", () -> c.sound, v -> { c.sound = v; c.save(); }, left, y, 146);
        toggle("Overlay-Effekte", () -> c.effects, v -> { c.effects = v; c.save(); }, left + 154, y, 146);
        y += 24;
        toggle("Konfetti", () -> c.confetti, v -> { c.confetti = v; c.save(); }, left, y, 146);
        toggle("Wasserzeichen", () -> c.watermark, v -> { c.watermark = v; c.save(); }, left + 154, y, 146);
        y += 24;
        toggle("Start-Animation", () -> c.titleAnimation, v -> { c.titleAnimation = v; c.save(); }, left, y, PW);
        y += 28;
        glassOn = ToastyGlass.isOn();
        button(() -> "Unsichtbares Glas (/glass): " + (glassOn ? "AN" : "AUS"), () -> {
            if (ToastyGlass.toggle()) glassOn = !glassOn; else ToastyGamble.chat("Glas-Pack nicht gefunden.");
        }, left, y, PW, 20);
        labels.add(new Label("Glas lädt Texturen neu (kurzer Ruckler).", left, y + 24, ToastyTheme.MUTED));
        y += 40;
        toggle("Rüstung-HUD", () -> c.armorHud, v -> { c.armorHud = v; c.save(); }, left, y, 146);
        toggle("Effekte-HUD", () -> c.potionHud, v -> { c.potionHud = v; c.save(); }, left + 154, y, 146);
        y += 24;
        toggle("Session-HUD", () -> c.sessionHud, v -> { c.sessionHud = v; c.save(); }, left, y, 146);
        toggle("Auto-Sprint", () -> c.autoSprint, v -> { c.autoSprint = v; c.save(); }, left + 154, y, 146);
    }

    // ---------- FPS ----------

    private void perfTab(int y) {
        ToastyConfig c = ToastyConfig.get();
        toggle("Partikel minimal", () -> c.perfParticles, v -> { c.perfParticles = v; ToastyPerf.apply(); }, left, y, PW);
        y += 24;
        toggle("Entity-Schatten aus", () -> c.perfShadows, v -> { c.perfShadows = v; ToastyPerf.apply(); }, left, y, PW);
        y += 24;
        toggle("Weniger Distanz (Render 8, Simulation 6)", () -> c.perfDistance, v -> { c.perfDistance = v; ToastyPerf.apply(); }, left, y, PW);
        y += 24;
        toggle("Wolken aus", () -> c.perfClouds, v -> { c.perfClouds = v; ToastyPerf.apply(); }, left, y, 146);
        toggle("Biom-Blend 0", () -> c.perfBlend, v -> { c.perfBlend = v; ToastyPerf.apply(); }, left + 154, y, 146);
        y += 24;
        toggle("Weiches Licht aus", () -> c.perfAo, v -> { c.perfAo = v; ToastyPerf.apply(); }, left, y, 146);
        toggle("FPS-Limit/VSync aus", () -> c.perfFps, v -> { c.perfFps = v; ToastyPerf.apply(); }, left + 154, y, 146);
        y += 30;
        labels.add(new Label("Ändert nur normale Spieloptionen. Beim Ausschalten", left, y, ToastyTheme.MUTED));
        labels.add(new Label("werden deine alten Werte wiederhergestellt.", left, y + 11, ToastyTheme.MUTED));
        labels.add(new Label("Tipp: Für noch mehr FPS zusätzlich Sodium nutzen.", left, y + 28, ToastyTheme.MUTED));
    }

    // ---------- Lyrics ----------

    private void lyricsTab(int y) {
        ToastyConfig c = ToastyConfig.get();
        toggle("Sky Lyrics", () -> c.skyLyrics, v -> { c.skyLyrics = v; c.save(); }, left, y, 146);
        button(() -> "Rechner öffnen (J)", () -> MinecraftClient.getInstance().setScreen(new ToastyCalculatorScreen(this)),
            left + 154, y, 146, 20, true);
        y += 24;
        button(() -> "Lyrics kleiner", () -> { c.lyricsScale = Math.max(1f, c.lyricsScale - 0.25f); c.save(); }, left, y, 146, 20);
        button(() -> "Lyrics größer", () -> { c.lyricsScale = Math.min(5f, c.lyricsScale + 0.25f); c.save(); }, left + 154, y, 146, 20);
        y += 24;
        button(() -> "Lyrics höher", () -> { c.lyricsHeight = Math.min(70f, c.lyricsHeight + 3f); c.save(); }, left, y, 146, 20);
        button(() -> "Lyrics tiefer", () -> { c.lyricsHeight = Math.max(5f, c.lyricsHeight - 3f); c.save(); }, left + 154, y, 146, 20);
        y += 24;
        button(() -> "-", () -> { c.lyricsOffset = Math.round((c.lyricsOffset - 0.25f) * 100) / 100f; c.save(); }, left, y, 30, 20);
        button(() -> String.format(java.util.Locale.ROOT, "Zeit-Offset: %+.2f s", c.lyricsOffset), () -> { c.lyricsOffset = 0; c.save(); }, left + 34, y, 232, 20);
        button(() -> "+", () -> { c.lyricsOffset = Math.round((c.lyricsOffset + 0.25f) * 100) / 100f; c.save(); }, left + 270, y, 30, 20);
        y += 28;
        button(() -> "Status in den Chat", () -> ToastyGamble.chatLong(ToastyLyrics.info()), left, y, PW, 20, true);
        labels.add(new Label("Offset: Klick auf die Mitte = 0. Plus = Lyrics früher.", left, y + 26, ToastyTheme.MUTED));
        labels.add(new Label("Der Player muss laufen (Apple Music / Spotify).", left, y + 38, ToastyTheme.MUTED));
    }

    // ---------- Sell ----------

    private static String ms(int v) {
        return v % 1000 == 0 ? (v / 1000) + " s" : String.format(java.util.Locale.ROOT, "%.1f s", v / 1000.0);
    }

    private static int stepMs(int v, int dir) {
        int st = (dir > 0 ? v >= 3000 : v > 3000) ? 1000 : 100;
        return Math.max(100, Math.min(3_600_000, v + dir * st));
    }

    private void sellTab(int y) {
        ToastyConfig c = ToastyConfig.get();
        labels.add(new Label("Sell-Befehl (Standard /sell)", left, y, ToastyTheme.MUTED));
        field(left, y + 10, PW, c.sellCommand == null ? "" : c.sellCommand, s -> { c.sellCommand = s; c.save(); });

        y += 34;
        toggle("Auto", () -> c.sellAuto, v -> { c.sellAuto = v; c.save(); }, left, y, 146);
        button(() -> "-", () -> { c.sellIntervalMs = stepMs(c.sellIntervalMs, -1); c.save(); }, left + 154, y, 30, 20);
        button(() -> "alle " + ms(c.sellIntervalMs), () -> {}, left + 188, y, 54, 20);
        button(() -> "+", () -> { c.sellIntervalMs = stepMs(c.sellIntervalMs, 1); c.save(); }, left + 246, y, 30, 20);
        y += 24;
        button(() -> ToastyMacro.isRunning() ? "Sell-Makro stoppen" : "Sell-Makro starten", ToastyMacro::toggle, left, y, 146, 20, true);
        button(() -> "Sell-Items wählen …", () -> MinecraftClient.getInstance().setScreen(new ToastySellScreen(this)),
            left + 154, y, 146, 20, true);
        y += 24;
        toggle("Shift = ganzes Inventar", () -> c.sellShiftAll, v -> { c.sellShiftAll = v; c.save(); }, left, y, PW);
        labels.add(new Label("Auto = startet selbst, sobald gewählte Items da sind.", left, y + 26, ToastyTheme.MUTED));
        labels.add(new Label("Shift beim Start/Füllen halten: ALLES aus dem Inventar", left, y + 38, ToastyTheme.MUTED));
        labels.add(new Label("kommt auf einmal ins Sell-Menü (auch nicht gewählte Items!).", left, y + 49, ToastyTheme.MUTED));
    }

    // ---------- Extras ----------

    private void extrasTab(int y) {
        ToastyConfig c = ToastyConfig.get();
        toggle("Fullbright", () -> c.fullbright, v -> { c.fullbright = v; c.save(); }, left, y, 146);
        toggle("Item-Highlight", () -> c.itemGlow, v -> { c.itemGlow = v; c.save(); }, left + 154, y, 146);
        y += 24;
        toggle("Block-Highlight", () -> c.blockHighlight, v -> { c.blockHighlight = v; c.save(); }, left, y, 146);
        toggle("Anti-Leak", () -> c.antiLeak, v -> { c.antiLeak = v; c.save(); }, left + 154, y, 146);
        y += 24;
        toggle("Autoclicker", () -> c.autoClick, v -> { c.autoClick = v; c.save(); }, left, y, 146);
        button(() -> "Taste: " + (c.autoRight ? "Rechts" : "Links"), () -> { c.autoRight = !c.autoRight; c.save(); }, left + 154, y, 146, 20);
        y += 24;
        button(() -> "-", () -> { c.autoCps = Math.max(1, c.autoCps - 1); c.save(); }, left, y, 30, 20);
        button(() -> "CPS: " + c.autoCps, () -> {}, left + 34, y, 232, 20);
        button(() -> "+", () -> { c.autoCps = Math.min(40, c.autoCps + 1); c.save(); }, left + 270, y, 30, 20);
        y += 24;
        button(() -> "Totem-Sound: " + ToastyMisc.TOTEM[c.totemIdx % ToastyMisc.TOTEM.length][0],
            () -> { c.totemIdx = (c.totemIdx + 1) % ToastyMisc.TOTEM.length; c.save(); ToastyMisc.playTotem(c.totemIdx); }, left, y, 200, 20, true);
        button(() -> "Test", () -> ToastyMisc.playTotem(c.totemIdx), left + 204, y, 96, 20);
        y += 28;
        labels.add(new Label("Anti-Leak: gesperrte Wörter (Komma getrennt)", left, y, ToastyTheme.MUTED));
        TextFieldWidget f = field(left, y + 10, PW, c.leakWords, s -> { c.leakWords = s; c.save(); });
        f.setMaxLength(300);
        labels.add(new Label("Sperrt auch Koordinaten, IPs und deinen PC-Namen im Chat.", left, y + 32, ToastyTheme.MUTED));
    }

    // ---------- Events: Twitch, Auktion, Giveaway ----------

    private void eventsTab(int y) {
        ToastyConfig c = ToastyConfig.get();
        labels.add(new Label("Twitch-Kanal (Name)", left, y, ToastyTheme.MUTED));
        field(left, y + 10, PW, c.twitchChannel, s -> { c.twitchChannel = s.trim(); c.save(); });
        y += 34;
        toggle("Twitch-Chat", () -> c.twitch, v -> { c.twitch = v; c.save(); }, left, y, 146);
        button(() -> "Zeilen: " + c.twitchLines, () -> { c.twitchLines = c.twitchLines >= 15 ? 3 : c.twitchLines + 1; c.save(); }, left + 154, y, 146, 20);
        y += 24;
        toggle("Ansagen im Chat", () -> c.auctionAnnounce, v -> { c.auctionAnnounce = v; c.save(); }, left, y, 146);
        button(() -> "Auktion beenden", () -> ToastyEvents.endAuction(false), left + 154, y, 146, 20, true);
        y += 28;
        labels.add(new Label("Giveaway-Stichwort", left, y, ToastyTheme.MUTED));
        field(left, y + 10, 146, c.giveawayKeyword, s -> { c.giveawayKeyword = s.trim(); c.save(); });
        button(() -> "Gewinner ziehen", () -> ToastyEvents.drawWinner(true), left + 154, y + 9, 146, 20, true);
        y += 34;
        labels.add(new Label("/auction start <Preis> <Sek> <Item> · /giveaway start <Sek> <Preis>", left, y, ToastyTheme.MUTED));
        labels.add(new Label("Gebote = erkannte Zahlungen an dich · /twitch <Kanal>", left, y + 11, ToastyTheme.MUTED));
    }

    // ---------- Notizen ----------

    private static String draft = "";

    private void notesTab(int y) {
        ToastyConfig c = ToastyConfig.get();
        labels.add(new Label("Neue Notiz", left, y, ToastyTheme.MUTED));
        TextFieldWidget f = field(left, y + 10, 214, draft, s -> draft = s);
        f.setMaxLength(120);
        button(() -> "Hinzufügen", () -> {
            if (!draft.isBlank()) { c.notes.add(draft.trim()); draft = ""; c.save(); clearAndInit(); }
        }, left + 218, y + 9, 82, 20, true);
        y += 34;
        toggle("Notizen-HUD", () -> c.notesHud, v -> { c.notesHud = v; c.save(); }, left, y, PW);
        y += 26;
        int shown = Math.min(5, c.notes.size());
        for (int i = 0; i < shown; i++) {
            final int idx = i;
            labels.add(new Label((i + 1) + ". " + textRenderer.trimToWidth(c.notes.get(i), 224), left, y + 6, ToastyTheme.TEXT));
            button(() -> "Löschen", () -> { if (idx < c.notes.size()) { c.notes.remove(idx); c.save(); clearAndInit(); } }, left + 244, y, 56, 20);
            y += 22;
        }
        if (c.notes.size() > shown) labels.add(new Label("+" + (c.notes.size() - shown) + " weitere (/note list)", left, y + 4, ToastyTheme.MUTED));
        if (c.notes.isEmpty()) labels.add(new Label("Auch per /note add <Text>, /note remove <Nr>, /note clear", left, y + 4, ToastyTheme.MUTED));
    }

    // ---------- Helper ----------

    private void toggle(String name, Supplier<Boolean> get, Consumer<Boolean> set, int x, int y, int w) {
        button(() -> name + ": " + (get.get() ? "AN" : "AUS"), () -> set.accept(!get.get()), x, y, w, 20);
    }

    private TextFieldWidget field(int x, int y, int w, String value, Consumer<String> onChange) {
        TextFieldWidget f = new TextFieldWidget(textRenderer, x, y, w, 18, Text.empty());
        f.setMaxLength(60);
        f.setText(value);
        f.setChangedListener(onChange);
        addDrawableChild(f);
        return f;
    }

    /** "5k", "1.5m", "100" -> Zahl; leer -> null */
    static Long parseAmount(String s) {
        s = s.trim().replace(" ", "");
        if (s.isEmpty()) return null;
        try {
            String suf = s.replaceAll("[^KkMmBbTt]", "");
            String num = s.replaceAll("[KkMmBbTt]", "");
            return ToastyGamble.parseAmount(num, suf.length() > 0 ? suf.substring(0, 1) : "");
        } catch (Exception e) { return null; }
    }

    // ---------- Rendering ----------

    @Override
    public void renderBackground(DrawContext ctx, int mouseX, int mouseY, float delta) {
        ctx.fillGradient(0, 0, width, height,
            ToastyTheme.alpha(ToastyTheme.lerp(0xFF05030C, ToastyTheme.PURPLE, 0.15f), 0xF0),
            ToastyTheme.alpha(ToastyTheme.lerp(0xFF05030C, ToastyTheme.BLUE, 0.18f), 0xF0));
        ToastyTheme.panel(ctx, left - 12, top - 28, PW + 24, 302);
        ToastyTheme.gradientText(ctx, textRenderer, "Toasty Client", left, top - 20);
        if (tab == 3) ToastyTheme.hGradient(ctx, left, top + 66 + 114, PW, 5, ToastyTheme.PURPLE, ToastyTheme.BLUE);
    }

    @Override
    protected void extra(DrawContext ctx, int mouseX, int mouseY) {
        for (Label l : labels) ctx.drawTextWithShadow(textRenderer, l.text(), l.x(), l.y(), l.color());
        String hint = "Rechte Shift = Menü";
        ctx.drawTextWithShadow(textRenderer, hint, left + PW - textRenderer.getWidth(hint), top - 20, ToastyTheme.MUTED);
    }

    @Override
    public boolean shouldPause() { return false; }

    @Override
    public void close() { MinecraftClient.getInstance().setScreen(parent); }
}
