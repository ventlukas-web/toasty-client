package dev.toasty.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Supplier;

/** Mod-Menue mit allen Funktionen des Toasty Clients. */
public class ToastyMenu extends ToastyScreen {
    private static final int PW = 300;
    private static final String[] TABS = {"Gamble", "HUD", "Design", "Visuals", "FPS", "Tools"};
    private static int tab = 0;
    private final Screen parent;

    private record Label(String text, int x, int y, int color) {}
    private final List<Label> labels = new ArrayList<>();
    private int left, top;
    private boolean glassOn;

    public ToastyMenu(Screen parent) {
        super(Text.literal("Toasty Client"));
        this.parent = parent;
    }

    @Override
    protected void build() {
        labels.clear();
        left = width / 2 - PW / 2;
        top = Math.max(32, (height - 262) / 2 + 28);

        int tw = PW / TABS.length;
        for (int i = 0; i < TABS.length; i++) {
            final int idx = i;
            button(() -> TABS[idx], () -> { tab = idx; clearAndInit(); },
                left + i * tw, top, tw - 2, 20, tab == i);
        }
        int y = top + 30;
        switch (tab) {
            case 0 -> gambleTab(y);
            case 1 -> hudTab(y);
            case 2 -> designTab(y);
            case 3 -> visualsTab(y);
            case 4 -> perfTab(y);
            default -> toolsTab(y);
        }
        button(() -> "Schließen", this::close, left + PW / 2 - 50, top + 204, 100, 20);
    }

    // ---------- Gamble ----------

    private void gambleTab(int y) {
        ToastyConfig c = ToastyConfig.get();
        labels.add(new Label("Mindesteinsatz", left, y, ToastyTheme.MUTED));
        labels.add(new Label("Höchsteinsatz (leer = unbegrenzt)", left + 152, y, ToastyTheme.MUTED));
        field(left, y + 10, 146, c.minBet == 0 ? "" : ToastyStats.fmt(c.minBet), s -> {
            Long v = parseAmount(s); c.minBet = v == null ? 0 : v; c.save();
        });
        field(left + 154, y + 10, 146, c.maxBet == Long.MAX_VALUE ? "" : ToastyStats.fmt(c.maxBet), s -> {
            Long v = parseAmount(s); c.maxBet = v == null ? Long.MAX_VALUE : v; c.save();
        });

        y += 36;
        labels.add(new Label("Gewinn-Multiplikator", left, y, ToastyTheme.MUTED));
        labels.add(new Label("2.0 = Einsatz x2 wird ausgezahlt", left + 152, y + 14, ToastyTheme.MUTED));
        field(left, y + 10, 146, String.valueOf(c.winMultiplier), s -> {
            try { c.winMultiplier = Double.parseDouble(s.replace(',', '.')); c.save(); } catch (Exception ignored) {}
        });

        y += 36;
        labels.add(new Label("Chat-Muster (Regex mit player, amount, suffix)", left, y, ToastyTheme.MUTED));
        TextFieldWidget f = field(left, y + 10, PW, c.pattern, s -> {
            try { java.util.regex.Pattern.compile(s); c.pattern = s; c.save(); } catch (Exception ignored) {}
        });
        f.setMaxLength(400);

        y += 38;
        button(() -> "Gewinn (letzter)", () -> ToastyGamble.chat(ToastyGamble.settle(null, true)), left, y, 96, 20, true);
        button(() -> "Verlust (letzter)", () -> ToastyGamble.chat(ToastyGamble.settle(null, false)), left + 102, y, 96, 20, true);
        button(() -> "Statistik reset", () -> { ToastyStats.reset(); ToastyGamble.chat("Statistik zurückgesetzt."); }, left + 204, y, 96, 20);
        labels.add(new Label("Befehle: /toasty win|lose [Spieler], /toasty stats", left, y + 26, ToastyTheme.MUTED));
    }

    // ---------- HUD ----------

    private void hudTab(int y) {
        ToastyConfig c = ToastyConfig.get();
        toggle("Stats-HUD", () -> c.hud, v -> { c.hud = v; c.save(); }, left, y, 146);
        toggle("Keystrokes", () -> c.keystrokes, v -> { c.keystrokes = v; c.save(); }, left + 154, y, 146);
        y += 24;
        toggle("Koordinaten", () -> c.coords, v -> { c.coords = v; c.save(); }, left, y, 146);
        toggle("FPS", () -> c.showFps, v -> { c.showFps = v; c.save(); }, left + 154, y, 146);
        y += 24;
        toggle("Ping", () -> c.ping, v -> { c.ping = v; c.save(); }, left, y, 146);
        toggle("Speed", () -> c.speed, v -> { c.speed = v; c.save(); }, left + 154, y, 146);
        y += 24;
        toggle("Uhrzeit", () -> c.clock, v -> { c.clock = v; c.save(); }, left, y, 146);
        toggle("Modul-Liste", () -> c.moduleList, v -> { c.moduleList = v; c.save(); }, left + 154, y, 146);
        y += 28;
        button(() -> "HUD kleiner", () -> { c.hudScale = Math.max(0.5f, Math.round((c.hudScale - 0.1f) * 10) / 10f); c.save(); }, left, y, 146, 20);
        button(() -> "HUD größer", () -> { c.hudScale = Math.min(3f, Math.round((c.hudScale + 0.1f) * 10) / 10f); c.save(); }, left + 154, y, 146, 20);
        labels.add(new Label("HUD-Größe wirkt auf alle HUD-Elemente.", left, y + 26, ToastyTheme.MUTED));
    }

    // ---------- Design ----------

    private static final String[][] PRESETS = {
        {"Lila-Blau", "#A855F7", "#7DD3FC"},
        {"Sunset", "#FB7185", "#FBBF24"},
        {"Mint", "#34D399", "#7DD3FC"},
        {"Neon", "#F472B6", "#22D3EE"},
        {"Feuer", "#EF4444", "#F97316"},
        {"Gold", "#F59E0B", "#FDE68A"},
    };

    private void designTab(int y) {
        ToastyConfig c = ToastyConfig.get();
        labels.add(new Label("Vorlagen", left, y, ToastyTheme.MUTED));
        for (int i = 0; i < PRESETS.length; i++) {
            final String[] p = PRESETS[i];
            int bx = left + (i % 2) * 154, by = y + 11 + (i / 2) * 22;
            button(() -> p[0], () -> {
                c.color1 = p[1]; c.color2 = p[2]; c.save(); ToastyTheme.reload(c); clearAndInit();
            }, bx, by, 146, 20);
        }
        int y1 = y + 82;
        labels.add(new Label("Farbe 1 (#RRGGBB)", left, y1, ToastyTheme.MUTED));
        labels.add(new Label("Farbe 2 (#RRGGBB)", left + 154, y1, ToastyTheme.MUTED));
        field(left, y1 + 10, 146, c.color1, s -> {
            Integer v = ToastyTheme.parseHex(s);
            if (v != null) { c.color1 = ToastyTheme.toHex(v); c.save(); ToastyTheme.reload(c); }
        });
        field(left + 154, y1 + 10, 146, c.color2, s -> {
            Integer v = ToastyTheme.parseHex(s);
            if (v != null) { c.color2 = ToastyTheme.toHex(v); c.save(); ToastyTheme.reload(c); }
        });
        int y2 = y + 124;
        button(() -> "Hintergrund heller", () -> { c.bgOpacity = Math.max(32, c.bgOpacity - 24); c.save(); ToastyTheme.reload(c); }, left, y2, 146, 20);
        button(() -> "Hintergrund dunkler", () -> { c.bgOpacity = Math.min(255, c.bgOpacity + 24); c.save(); ToastyTheme.reload(c); }, left + 154, y2, 146, 20);
    }

    // ---------- Visuals ----------

    private void visualsTab(int y) {
        ToastyConfig c = ToastyConfig.get();
        toggle("Sound", () -> c.sound, v -> { c.sound = v; c.save(); }, left, y, 146);
        toggle("Overlay-Effekte", () -> c.effects, v -> { c.effects = v; c.save(); }, left + 154, y, 146);
        y += 24;
        toggle("Konfetti", () -> c.confetti, v -> { c.confetti = v; c.save(); }, left, y, 146);
        toggle("Wasserzeichen", () -> c.watermark, v -> { c.watermark = v; c.save(); }, left + 154, y, 146);
        y += 24;
        toggle("Start-Animation", () -> c.titleAnimation, v -> { c.titleAnimation = v; c.save(); }, left, y, PW);
        y += 28;
        glassOn = ToastyGlass.isOn();
        button(() -> "Unsichtbares Glas (/glass): " + (glassOn ? "AN" : "AUS"), () -> {
            if (ToastyGlass.toggle()) glassOn = !glassOn; else ToastyGamble.chat("Glas-Pack nicht gefunden.");
        }, left, y, PW, 20);
        labels.add(new Label("Glas lädt Texturen neu (kurzer Ruckler).", left, y + 24, ToastyTheme.MUTED));
    }

    // ---------- FPS ----------

    private void perfTab(int y) {
        ToastyConfig c = ToastyConfig.get();
        toggle("Partikel minimal", () -> c.perfParticles, v -> { c.perfParticles = v; ToastyPerf.apply(); }, left, y, PW);
        y += 24;
        toggle("Entity-Schatten aus", () -> c.perfShadows, v -> { c.perfShadows = v; ToastyPerf.apply(); }, left, y, PW);
        y += 24;
        toggle("Weniger Distanz (Render 8, Simulation 6)", () -> c.perfDistance, v -> { c.perfDistance = v; ToastyPerf.apply(); }, left, y, PW);
        y += 30;
        labels.add(new Label("Ändert nur normale Spieloptionen. Beim Ausschalten", left, y, ToastyTheme.MUTED));
        labels.add(new Label("werden deine alten Werte wiederhergestellt.", left, y + 11, ToastyTheme.MUTED));
        labels.add(new Label("Tipp: Für noch mehr FPS zusätzlich Sodium nutzen.", left, y + 28, ToastyTheme.MUTED));
    }

    // ---------- Tools: Rechner, Sky Lyrics, Makro ----------

    private void toolsTab(int y) {
        ToastyConfig c = ToastyConfig.get();
        toggle("Sky Lyrics", () -> c.skyLyrics, v -> { c.skyLyrics = v; c.save(); }, left, y, 146);
        button(() -> "Rechner öffnen (J)", () -> MinecraftClient.getInstance().setScreen(new ToastyCalculatorScreen(this)),
            left + 154, y, 146, 20, true);
        y += 24;
        button(() -> "Lyrics kleiner", () -> { c.lyricsScale = Math.max(1f, c.lyricsScale - 0.25f); c.save(); }, left, y, 146, 20);
        button(() -> "Lyrics größer", () -> { c.lyricsScale = Math.min(5f, c.lyricsScale + 0.25f); c.save(); }, left + 154, y, 146, 20);
        y += 24;
        button(() -> "Lyrics höher", () -> { c.lyricsHeight = Math.min(70f, c.lyricsHeight + 3f); c.save(); }, left, y, 146, 20);
        button(() -> "Lyrics tiefer", () -> { c.lyricsHeight = Math.max(5f, c.lyricsHeight - 3f); c.save(); }, left + 154, y, 146, 20);

        y += 28;
        labels.add(new Label("Sell-Makro: Befehl (Standard /sell)", left, y, ToastyTheme.MUTED));
        field(left, y + 10, PW, c.sellCommand == null ? "" : c.sellCommand, s -> { c.sellCommand = s; c.save(); });

        y += 34;
        toggle("Auto", () -> c.sellAuto, v -> { c.sellAuto = v; c.save(); }, left, y, 146);
        button(() -> "-", () -> { c.sellIntervalSec = Math.max(3, c.sellIntervalSec - 1); c.save(); }, left + 154, y, 30, 20);
        button(() -> "alle " + c.sellIntervalSec + " s", () -> {}, left + 188, y, 54, 20);
        button(() -> "+", () -> { c.sellIntervalSec = Math.min(3600, c.sellIntervalSec + 1); c.save(); }, left + 246, y, 30, 20);

        y += 24;
        button(() -> ToastyMacro.isRunning() ? "Sell-Makro stoppen" : "Sell-Makro starten", ToastyMacro::toggle, left, y, 146, 20, true);
        button(() -> "Sell-Items wählen …", () -> MinecraftClient.getInstance().setScreen(new ToastySellScreen(this)),
            left + 154, y, 146, 20, true);
        labels.add(new Label("Auto = startet selbst, sobald gewählte Items im Inventar sind.", left, y + 25, ToastyTheme.MUTED));
    }

    // ---------- Helper ----------

    private void toggle(String name, Supplier<Boolean> get, Consumer<Boolean> set, int x, int y, int w) {
        button(() -> name + ": " + (get.get() ? "AN" : "AUS"), () -> set.accept(!get.get()), x, y, w, 20);
    }

    private TextFieldWidget field(int x, int y, int w, String value, Consumer<String> onChange) {
        TextFieldWidget f = new TextFieldWidget(textRenderer, x, y, w, 18, Text.empty());
        f.setMaxLength(60);
        f.setText(value);
        f.setChangedListener(onChange);
        addDrawableChild(f);
        return f;
    }

    /** "5k", "1.5m", "100" -> Zahl; leer -> null */
    static Long parseAmount(String s) {
        s = s.trim().replace(" ", "");
        if (s.isEmpty()) return null;
        try {
            String suf = s.replaceAll("[^KkMmBbTt]", "");
            String num = s.replaceAll("[KkMmBbTt]", "");
            return ToastyGamble.parseAmount(num, suf.length() > 0 ? suf.substring(0, 1) : "");
        } catch (Exception e) { return null; }
    }

    // ---------- Rendering ----------

    @Override
    public void renderBackground(DrawContext ctx, int mouseX, int mouseY, float delta) {
        ctx.fillGradient(0, 0, width, height,
            ToastyTheme.alpha(ToastyTheme.lerp(0xFF05030C, ToastyTheme.PURPLE, 0.15f), 0xF0),
            ToastyTheme.alpha(ToastyTheme.lerp(0xFF05030C, ToastyTheme.BLUE, 0.18f), 0xF0));
        ToastyTheme.panel(ctx, left - 12, top - 28, PW + 24, 262);
        ToastyTheme.gradientText(ctx, textRenderer, "Toasty Client", left, top - 20);
        if (tab == 2) ToastyTheme.hGradient(ctx, left, top + 30 + 114, PW, 5, ToastyTheme.PURPLE, ToastyTheme.BLUE);
    }

    @Override
    protected void extra(DrawContext ctx, int mouseX, int mouseY) {
        for (Label l : labels) ctx.drawTextWithShadow(textRenderer, l.text(), l.x(), l.y(), l.color());
        String hint = "Rechte Shift = Menü";
        ctx.drawTextWithShadow(textRenderer, hint, left + PW - textRenderer.getWidth(hint), top - 20, ToastyTheme.MUTED);
    }

    @Override
    public boolean shouldPause() { return false; }

    @Override
    public void close() { MinecraftClient.getInstance().setScreen(parent); }
}
