package dev.toasty.client.mixin;

import dev.toasty.client.ToastyConfig;
import dev.toasty.client.ToastyTheme;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.widget.EntryListWidget;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Listen (Multiplayer, Welten, Optionen ...): Dirt-Hintergrund und Trennlinien durch durchsichtige Wolken-Flaeche ersetzen. */
@Mixin(EntryListWidget.class)
public abstract class ListBackgroundMixin {
    @Inject(method = "drawMenuListBackground", at = @At("HEAD"), cancellable = true, require = 0)
    private void toasty$listBg(DrawContext ctx, CallbackInfo ci) {
        try {
            if (!ToastyConfig.get().niceButtons) return;
            EntryListWidget<?> w = (EntryListWidget<?>) (Object) this;
            ToastyTheme.roundRectExact(ctx, w.getX(), w.getY(), w.getWidth(), w.getHeight(), 8, ToastyTheme.alpha(0xFFFFFFFF, 0x18));
            ToastyTheme.roundOutlineExact(ctx, w.getX(), w.getY(), w.getWidth(), w.getHeight(), 8, ToastyTheme.alpha(0xFFFFFFFF, 0x38));
            ci.cancel();
        } catch (Throwable t) {
            dev.toasty.client.ToastyProf.mixinErrors++;
            dev.toasty.client.ToastyProf.mixinLastError = String.valueOf(t);
        }
    }

    @Inject(method = "drawHeaderAndFooterSeparators", at = @At("HEAD"), cancellable = true, require = 0)
    private void toasty$seps(DrawContext ctx, CallbackInfo ci) {
        if (ToastyConfig.get().niceButtons) ci.cancel();
    }
}
