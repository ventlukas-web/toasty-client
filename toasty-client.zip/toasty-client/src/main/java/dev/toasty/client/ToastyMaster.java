package dev.toasty.client;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/** Grosser "Toasty Client"-Schalter: alle Features auf einmal aus-/einschalten (merkt sich den vorherigen Zustand). */
public final class ToastyMaster {
    /** Kein Feature, sondern Look/Unteroptionen: bleiben unveraendert. */
    private static final Set<String> KEEP = Set.of("masterOn", "joinButton", "introTrailer", "titleAnimation", "titleToast",
        "niceInventory", "niceButtons", "sound", "streamerHideXyz", "sbNumbers", "sbBorderOn",
        "sbTheme", "auctionAnnounce", "armorWarn", "autoPay", "chDot", "chOutline");

    private ToastyMaster() {}

    public static void toggle() {
        ToastyConfig c = ToastyConfig.get();
        try {
            if (c.masterOn) {
                Map<String, Boolean> saved = new HashMap<>();
                for (Field f : ToastyConfig.class.getFields()) {
                    if (f.getType() != boolean.class || Modifier.isStatic(f.getModifiers()) || KEEP.contains(f.getName())) continue;
                    saved.put(f.getName(), f.getBoolean(c));
                    f.setBoolean(c, false);
                }
                c.masterSaved = saved;
                c.masterOn = false;
            } else {
                if (c.masterSaved != null) {
                    for (Map.Entry<String, Boolean> e : c.masterSaved.entrySet()) {
                        try { ToastyConfig.class.getField(e.getKey()).setBoolean(c, e.getValue()); } catch (Exception ignored) {}
                    }
                }
                c.masterOn = true;
            }
        } catch (Exception ignored) {}
        ToastyGlass.setCloak(c.antiLeak);
        c.save();
    }
}
