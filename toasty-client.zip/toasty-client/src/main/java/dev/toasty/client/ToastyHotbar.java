package dev.toasty.client;

import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.item.ItemStack;

/** Hotbar im Toastentials-Design: dunkles, rundes Panel, Mint-Auswahl, Items wie gewohnt. */
public final class ToastyHotbar {
    private ToastyHotbar() {}

    public static void register() {
        HudElementRegistry.replaceElement(VanillaHudElements.HOTBAR, orig -> (ctx, tick) -> {
            MinecraftClient mc = MinecraftClient.getInstance();
            ToastyConfig c = ToastyConfig.get();
            var p = mc.player;
            if (!c.hotbarNice || p == null || mc.options == null || mc.interactionManager == null
                || mc.interactionManager.getCurrentGameMode().isSpectator()) { orig.render(ctx, tick); return; }
            try {
                draw(ctx, mc, p, tick.getTickProgress(false));
            } catch (Throwable t) { orig.render(ctx, tick); }
        });
    }

    private static void draw(DrawContext ctx, MinecraftClient mc, net.minecraft.entity.player.PlayerEntity p, float td) {
        int w = ctx.getScaledWindowWidth(), h = ctx.getScaledWindowHeight();
        int x0 = w / 2 - 91, y0 = h - 22;
        int sel = p.getInventory().getSelectedSlot();
        ToastyTheme.roundRectExact(ctx, x0, y0, 182, 22, 6, ToastyTheme.alpha(0xFF0A1210, 0xB8));
        ToastyTheme.roundOutlineExact(ctx, x0, y0, 182, 22, 6, ToastyTheme.alpha(ToastyTheme.PURPLE, 0x55));
        // Auswahl
        int sx = x0 + 1 + sel * 20;
        ToastyTheme.roundRectExact(ctx, sx, y0 + 1, 20, 20, 5, ToastyTheme.alpha(ToastyTheme.PURPLE, 0x40));
        ToastyTheme.roundOutlineExact(ctx, sx, y0 + 1, 20, 20, 5, ToastyTheme.alpha(ToastyTheme.lerp(ToastyTheme.PURPLE, ToastyTheme.BLUE, 0.4f), 0xE6));
        // Offhand
        ItemStack off = p.getOffHandStack();
        if (!off.isEmpty()) {
            ToastyTheme.roundRectExact(ctx, x0 - 26, y0, 22, 22, 6, ToastyTheme.alpha(0xFF0A1210, 0xB8));
            ToastyTheme.roundOutlineExact(ctx, x0 - 26, y0, 22, 22, 6, ToastyTheme.alpha(ToastyTheme.PURPLE, 0x55));
            ctx.drawItem(off, x0 - 25, y0 + 3);
            ctx.drawStackOverlay(mc.textRenderer, off, x0 - 25, y0 + 3);
        }
        for (int i = 0; i < 9; i++) {
            ItemStack st = p.getInventory().getStack(i);
            if (st.isEmpty()) continue;
            int ix = x0 + 3 + i * 20, iy = y0 + 3;
            ctx.drawItem(st, ix, iy);
            ctx.drawStackOverlay(mc.textRenderer, st, ix, iy);
        }
    }
}
