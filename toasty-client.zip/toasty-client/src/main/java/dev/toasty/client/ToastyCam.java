package dev.toasty.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.player.PlayerEntity;

/**
 * Freecam (Taste umschalten) und Freelook (Taste halten) ueber eine unsichtbare Kamera-Figur.
 * Die echte Blickrichtung des Spielers bleibt fuer den Server eingefroren, nur die Kamera dreht sich.
 */
public final class ToastyCam {
    private ToastyCam() {}

    private static int mode = 0; // 0 aus, 1 Freecam, 2 Freelook
    private static ArmorStandEntity cam;
    private static double cx, cy, cz, eyeOff;
    private static float yaw, pitch, lockYaw, lockPitch;
    private static boolean fw, bk, lf, rt, up, dn, sprint;
    private static long lastNs = System.nanoTime();

    public static boolean active() { return mode != 0; }

    public static void toggleFreecam() {
        if (mode == 1) stop(); else { stop(); start(1); }
    }

    private static void start(int m) {
        MinecraftClient mc = MinecraftClient.getInstance();
        PlayerEntity p = mc.player;
        if (p == null || mc.world == null) return;
        mode = m;
        lockYaw = p.getYaw(); lockPitch = p.getPitch();
        yaw = lockYaw; pitch = lockPitch;
        cam = new ArmorStandEntity(mc.world, p.getX(), p.getY(), p.getZ());
        cam.setInvisible(true);
        cam.setNoGravity(true);
        eyeOff = cam.getEyeY() - cam.getY();
        cx = p.getX(); cy = p.getEyeY(); cz = p.getZ();
        place();
        mc.setCameraEntity(cam);
        ToastyGamble.chat(m == 1 ? "Freecam an – Taste nochmal = zurück (Bewegung/Klicks sind gesperrt)." : "Freelook an.");
    }

    public static void stop() {
        if (mode == 0) return;
        mode = 0;
        MinecraftClient mc = MinecraftClient.getInstance();
        mc.setCameraEntity(mc.player);
        cam = null;
    }

    private static void place() {
        if (cam == null) return;
        cam.refreshPositionAndAngles(cx, cy - eyeOff, cz, yaw, pitch);
    }

    /** Am Tick-Anfang: Tasten lesen, Freelook halten, Freecam-Eingaben sperren. */
    public static void tickStart(MinecraftClient mc) {
        if (mc.player == null || mc.world == null) { if (mode != 0) { mode = 0; cam = null; } return; }
        if (ToastyMisc.freelookKey != null) {
            boolean held = ToastyMisc.freelookKey.isPressed() && mc.currentScreen == null;
            if (held && mode == 0) start(2);
            else if (!held && mode == 2) stop();
        }
        while (ToastyMisc.freecamKey != null && ToastyMisc.freecamKey.wasPressed()) {
            if (mc.currentScreen == null) toggleFreecam();
        }
        if (mode == 1) {
            var o = mc.options;
            fw = o.forwardKey.isPressed(); bk = o.backKey.isPressed(); lf = o.leftKey.isPressed(); rt = o.rightKey.isPressed();
            up = o.jumpKey.isPressed(); dn = o.sneakKey.isPressed(); sprint = o.sprintKey.isPressed();
            KeyBinding[] lock = {o.forwardKey, o.backKey, o.leftKey, o.rightKey, o.jumpKey, o.sneakKey, o.sprintKey, o.attackKey, o.useKey};
            for (KeyBinding k : lock) { k.setPressed(false); while (k.wasPressed()) { } }
        }
    }

    /** Jedes Frame (aus dem HUD): Mausbewegung auf die Kamera umlenken und Kamera bewegen. */
    public static void frame(MinecraftClient mc) {
        long ns = System.nanoTime();
        float dt = Math.min(0.1f, (ns - lastNs) / 1e9f);
        lastNs = ns;
        if (mode == 0) return;
        PlayerEntity p = mc.player;
        if (p == null || cam == null) { mode = 0; return; }
        yaw += p.getYaw() - lockYaw;
        pitch = Math.max(-90f, Math.min(90f, pitch + p.getPitch() - lockPitch));
        p.setYaw(lockYaw); p.setPitch(lockPitch);
        if (mode == 1) {
            double sp = (sprint ? 40.0 : 14.0) * dt;
            double ya = Math.toRadians(yaw), pa = Math.toRadians(pitch);
            double fx = -Math.sin(ya) * Math.cos(pa), fy = -Math.sin(pa), fz = Math.cos(ya) * Math.cos(pa);
            double rx = -Math.cos(ya), rz = -Math.sin(ya);
            double mf = (fw ? 1 : 0) - (bk ? 1 : 0), mr = (rt ? 1 : 0) - (lf ? 1 : 0), mu = (up ? 1 : 0) - (dn ? 1 : 0);
            cx += (fx * mf + rx * mr) * sp;
            cy += (fy * mf + mu) * sp;
            cz += (fz * mf + rz * mr) * sp;
        } else {
            double ya = Math.toRadians(yaw), pa = Math.toRadians(pitch);
            double fx = -Math.sin(ya) * Math.cos(pa), fy = -Math.sin(pa), fz = Math.cos(ya) * Math.cos(pa);
            cx = p.getX() - fx * 3.5; cy = p.getEyeY() - fy * 3.5; cz = p.getZ() - fz * 3.5;
        }
        place();
    }
}
