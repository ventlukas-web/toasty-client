package dev.toasty.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.player.PlayerEntity;

/**
 * Freecam (Taste umschalten) und Freelook (Taste halten) ueber eine unsichtbare Kamera-Figur.
 * Die echte Blickrichtung des Spielers bleibt fuer den Server eingefroren, nur die Kamera dreht sich.
 */
public final class ToastyCam {
    private ToastyCam() {}

    private static int mode = 0; // 0 aus, 1 Freecam, 2 Freelook
    private static Stand cam;
    private static double cx, cy, cz, eyeOff;
    private static float yaw, pitch, lockYaw, lockPitch, basePitch;
    private static boolean fw, bk, lf, rt, up, dn, sprint;
    private static PlayerEntity owner;
    private static double orbitDist = 3.5;

    private static float wrap180(float d) { return d > 180f ? d - 360f : (d < -180f ? d + 360f : d); }

    /** Aktuelle Kamera-Drehung inkl. Mausbewegung dieses Frames (damit die Kamera nicht hinterherhinkt). */
    static float liveYaw() { return owner == null ? yaw : yaw + wrap180(owner.getYaw() - lockYaw); }
    static float livePitch() { return owner == null ? pitch : Math.max(-90f, Math.min(90f, pitch + owner.getPitch() - basePitch)); }

    /** Kamera-Figur, die Drehung (und beim Freelook die Position) live berechnet. */
    private static final class Stand extends ArmorStandEntity {
        Stand(net.minecraft.world.World w, double x, double y, double z) { super(w, x, y, z); }
        public float getYaw(float d) { return liveYaw(); }
        public float getPitch(float d) { return livePitch(); }
        public net.minecraft.util.math.Vec3d getLerpedPos(float d) {
            if (mode == 2 && owner != null) {
                double ya = Math.toRadians(liveYaw()), pa = Math.toRadians(livePitch());
                double fx = -Math.sin(ya) * Math.cos(pa), fy = -Math.sin(pa), fz = Math.cos(ya) * Math.cos(pa);
                return new net.minecraft.util.math.Vec3d(owner.getX() - fx * orbitDist, owner.getEyeY() - fy * orbitDist - eyeOff, owner.getZ() - fz * orbitDist);
            }
            return new net.minecraft.util.math.Vec3d(cx, cy - eyeOff, cz);
        }
    }
    private static long lastNs = System.nanoTime();

    public static boolean active() { return mode != 0; }

    public static void toggleFreecam() {
        if (mode == 1) stop(); else { stop(); start(1); }
    }

    private static void start(int m) {
        MinecraftClient mc = MinecraftClient.getInstance();
        PlayerEntity p = mc.player;
        if (p == null || mc.world == null) return;
        mode = m; owner = p;
        lockYaw = p.getYaw(); lockPitch = p.getPitch(); basePitch = lockPitch;
        yaw = lockYaw; pitch = lockPitch;
        cam = new Stand(mc.world, p.getX(), p.getY(), p.getZ());
        cam.setInvisible(true);
        cam.setNoGravity(true);
        eyeOff = cam.getEyeY() - cam.getY();
        cx = p.getX(); cy = p.getEyeY(); cz = p.getZ();
        place();
        mc.setCameraEntity(cam);
        ToastyGamble.chat(m == 1 ? "Freecam an – Taste nochmal = zurück (Bewegung/Klicks sind gesperrt)." : "Freelook an.");
    }

    public static void stop() {
        if (mode == 0) return;
        mode = 0;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player != null) mc.setCameraEntity(mc.player);
        cam = null; owner = null;
        KeyBinding.updateKeysByCode(); // gehaltene Tasten wieder korrekt erkennen
    }

    private static void place() {
        if (cam == null) return;
        cam.refreshPositionAndAngles(cx, cy - eyeOff, cz, yaw, pitch);
    }

    /** Am Tick-Anfang: Tasten lesen, Freelook halten, Freecam-Eingaben sperren. */
    public static void tickStart(MinecraftClient mc) {
        if (mc.player == null || mc.world == null || (mode != 0 && mc.player != owner)) {
            if (mode != 0) { mode = 0; cam = null; owner = null; if (mc.player != null) mc.setCameraEntity(mc.player); }
            if (mc.player == null || mc.world == null) return;
        }
        if (ToastyMisc.freelookKey != null) {
            boolean held = ToastyMisc.freelookKey.isPressed() && mc.currentScreen == null;
            if (held && mode == 0) start(2);
            else if (!held && mode == 2) stop();
        }
        while (ToastyMisc.freecamKey != null && ToastyMisc.freecamKey.wasPressed()) {
            if (mc.currentScreen == null) toggleFreecam();
        }
        if (mode != 0) {
            // Mausbewegung seit dem letzten Frame uebernehmen, dann echte Blickrichtung fuer den Server wiederherstellen
            absorb(mc.player);
            mc.player.setPitch(lockPitch); mc.player.setYaw(lockYaw);
            basePitch = lockPitch;
            // Klicks sperren, solange die Kamera nicht beim Spieler ist (sonst Geister-Interaktionen)
            KeyBinding[] clicks = {mc.options.attackKey, mc.options.useKey};
            for (KeyBinding k : clicks) { k.setPressed(false); while (k.wasPressed()) { } }
        }
        if (mode == 1) {
            var o = mc.options;
            fw = o.forwardKey.isPressed(); bk = o.backKey.isPressed(); lf = o.leftKey.isPressed(); rt = o.rightKey.isPressed();
            up = o.jumpKey.isPressed(); dn = o.sneakKey.isPressed(); sprint = o.sprintKey.isPressed();
            KeyBinding[] lock = {o.forwardKey, o.backKey, o.leftKey, o.rightKey, o.jumpKey, o.sneakKey, o.sprintKey, o.attackKey, o.useKey};
            for (KeyBinding k : lock) { k.setPressed(false); while (k.wasPressed()) { } }
        }
    }

    private static void absorb(PlayerEntity p) {
        float dy = p.getYaw() - lockYaw;
        if (dy > 180f) dy -= 360f; else if (dy < -180f) dy += 360f;
        yaw += dy;
        pitch = Math.max(-90f, Math.min(90f, pitch + p.getPitch() - basePitch));
    }

    /** Wie weit darf die Kamera vom Spieler weg, ohne in einen Block zu geraten? */
    private static double clip(MinecraftClient mc, double ex, double ey, double ez, double dx, double dy, double dz, double max) {
        double allowed = max;
        for (double d = 0.25; d <= max; d += 0.1) {
            var bp = net.minecraft.util.math.BlockPos.ofFloored(ex - dx * d, ey - dy * d, ez - dz * d);
            if (!mc.world.getBlockState(bp).getCollisionShape(mc.world, bp).isEmpty()) { allowed = d - 0.3; break; }
        }
        return Math.max(0.3, allowed);
    }

    /** Jedes Frame (aus dem HUD): Mausbewegung auf die Kamera umlenken und Kamera bewegen. */
    public static void frame(MinecraftClient mc) {
        long ns = System.nanoTime();
        float dt = Math.min(0.1f, (ns - lastNs) / 1e9f);
        lastNs = ns;
        if (mode == 0) return;
        PlayerEntity p = mc.player;
        if (p == null || cam == null) { mode = 0; return; }
        absorb(p);
        // Spieler-Pitch auf 0 setzen, damit die Maus nicht an der +-90-Grad-Grenze des Spielers haengen bleibt
        p.setYaw(lockYaw); p.setPitch(0f);
        basePitch = 0f;
        if (mode == 1) {
            double sp = (sprint ? 40.0 : 14.0) * dt;
            double ya = Math.toRadians(yaw), pa = Math.toRadians(pitch);
            double fx = -Math.sin(ya) * Math.cos(pa), fy = -Math.sin(pa), fz = Math.cos(ya) * Math.cos(pa);
            double rx = -Math.cos(ya), rz = -Math.sin(ya);
            double mf = (fw ? 1 : 0) - (bk ? 1 : 0), mr = (rt ? 1 : 0) - (lf ? 1 : 0), mu = (up ? 1 : 0) - (dn ? 1 : 0);
            cx += (fx * mf + rx * mr) * sp;
            cy += (fy * mf + mu) * sp;
            cz += (fz * mf + rz * mr) * sp;
        } else {
            double ya = Math.toRadians(yaw), pa = Math.toRadians(pitch);
            double fx = -Math.sin(ya) * Math.cos(pa), fy = -Math.sin(pa), fz = Math.cos(ya) * Math.cos(pa);
            double dist = clip(mc, p.getX(), p.getEyeY(), p.getZ(), fx, fy, fz, 3.5);
            orbitDist = dist;
            cx = p.getX() - fx * dist; cy = p.getEyeY() - fy * dist; cz = p.getZ() - fz * dist;
        }
        place();
    }
}
