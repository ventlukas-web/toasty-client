package dev.toasty.client;

import it.unimi.dsi.fastutil.longs.LongOpenHashSet;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import net.minecraft.util.Util;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.EmptyBlockView;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Stream;

/**
 * Ingame-Schematic-Vorschau: listet alle .litematic aus .minecraft/schematics und zeigt sie als drehbares 3D-Modell
 * (Maus ziehen = drehen, Mausrad = Zoom), mit Ebenen-Ansicht und Materialliste.
 */
public class ToastySchematicScreen extends ToastyScreen {
    private static final int MAX_POINTS = 30_000;
    private final Screen parent;

    private static List<Path> files = new ArrayList<>();
    private static int listScroll = 0;
    private static Path selected;
    private static float yaw = 45, pitch = 30, zoom = 0;
    private static int layer = Integer.MAX_VALUE;
    private static boolean showMats = true;

    // geladene Daten (vom Hintergrund-Thread)
    private static volatile ToastySchematic schem;
    private static volatile Model model;
    private static volatile String state = "";
    private static List<Map.Entry<String, Integer>> mats = List.of();
    private static int loadId = 0;

    private record Model(float[] x, float[] y, float[] z, int[] color, int n, int total, int layerShown) {}

    private int px, py, pw, ph, lx, ly, lw, lh, vx, vy, vw, vh;
    private Integer[] order;
    private float sortYaw = Float.NaN, sortPitch = Float.NaN;
    private Model sortedFor;
    private boolean dragging;

    public ToastySchematicScreen(Screen parent) {
        super(Text.literal("Schematic-Vorschau"));
        this.parent = parent;
    }

    public static Path dir() { return FabricLoader.getInstance().getGameDir().resolve("schematics"); }

    private static void scan() {
        List<Path> out = new ArrayList<>();
        try {
            Files.createDirectories(dir());
            try (Stream<Path> st = Files.walk(dir(), 5)) {
                st.filter(p -> Files.isRegularFile(p) && p.getFileName().toString().toLowerCase(Locale.ROOT).endsWith(".litematic")).forEach(out::add);
            }
        } catch (Exception ignored) {}
        out.sort(Comparator.comparing(p -> p.getFileName().toString().toLowerCase(Locale.ROOT)));
        files = out;
    }

    @Override
    protected void build() {
        if (files.isEmpty()) scan();
        px = 16; py = 16; pw = width - 32; ph = height - 32;
        lx = px + 8; ly = py + 22; lw = Math.min(150, pw / 3); lh = ph - 22 - 30;
        vx = lx + lw + 8; vy = ly; vw = px + pw - 8 - vx; vh = lh;
        int rows = Math.max(1, (lh - 4) / 14);
        listScroll = Math.max(0, Math.min(listScroll, Math.max(0, files.size() - rows)));
        for (int i = 0; i < rows && listScroll + i < files.size(); i++) {
            final Path f = files.get(listScroll + i);
            hitbox(() -> open(f), lx, ly + 2 + i * 14, lw, 14);
        }
        int by = py + ph - 26, bw = 70;
        int x = lx;
        button(() -> "Neu laden", () -> { scan(); clearAndInit(); }, x, by, bw, 20); x += bw + 4;
        button(() -> "Ordner öffnen", () -> { try { Files.createDirectories(dir()); } catch (Exception ignored) {} Util.getOperatingSystem().open(dir().toUri()); }, x, by, bw + 6, 20); x += bw + 10;
        button(() -> "Ebene −", () -> setLayer(-1), x, by, 54, 20); x += 58;
        button(() -> "Ebene +", () -> setLayer(+1), x, by, 54, 20); x += 58;
        button(() -> "Alle Ebenen", () -> { layer = Integer.MAX_VALUE; rebuildModel(); }, x, by, bw, 20); x += bw + 4;
        button(() -> "Ansicht zurück", () -> { yaw = 45; pitch = 30; zoom = 0; }, x, by, bw + 10, 20); x += bw + 14;
        button(() -> showMats ? "Materialien: an" : "Materialien: aus", () -> showMats = !showMats, x, by, bw + 20, 20, true);
        button(() -> "Schließen", this::close, px + pw - 8 - 70, by, 70, 20);
    }

    private void open(Path f) {
        selected = f;
        layer = Integer.MAX_VALUE;
        zoom = 0;
        schem = null; model = null; mats = List.of();
        state = "lade …";
        final int id = ++loadId;
        CompletableFuture.runAsync(() -> {
            try {
                ToastySchematic s = ToastySchematic.load(f);
                if (id != loadId) return;
                schem = s;
                mats = materials(s);
                model = buildModel(s, layer);
                state = "";
            } catch (Throwable t) {
                if (id == loadId) state = "Fehler: " + t.getMessage();
            }
        });
    }

    private void setLayer(int d) {
        ToastySchematic s = schem;
        if (s == null) return;
        int cur = layer == Integer.MAX_VALUE ? s.maxY : layer;
        layer = Math.max(s.minY, Math.min(s.maxY, cur + d));
        if (layer == s.maxY && d > 0) layer = Integer.MAX_VALUE;
        rebuildModel();
    }

    private void rebuildModel() {
        ToastySchematic s = schem;
        if (s == null) return;
        final int l = layer, id = loadId;
        CompletableFuture.runAsync(() -> {
            Model m = buildModel(s, l);
            if (id == loadId) model = m;
        });
    }

    private static long pack(int x, int y, int z) { return ((long) (x & 0x3FFFFF) << 42) | ((long) (y & 0xFFFFF) << 22) | (z & 0x3FFFFF); }

    /** Nur sichtbare Blöcke (mindestens eine freie Seite), mit Farbe aus der Kartenfarbe des Blocks. */
    private static Model buildModel(ToastySchematic s, int layerMax) {
        LongOpenHashSet set = new LongOpenHashSet(s.count * 2);
        for (int i = 0; i < s.count; i++) if (s.ys[i] <= layerMax) set.add(pack(s.xs[i], s.ys[i], s.zs[i]));
        int[] col = new int[s.palette.length];
        for (int i = 0; i < col.length; i++) col[i] = colorOf(s.palette[i]);
        float cx = (s.minX + s.maxX) / 2f, cy = (s.minY + s.maxY) / 2f, cz = (s.minZ + s.maxZ) / 2f;
        float hy = Math.max(1, s.maxY - s.minY);
        List<Integer> vis = new ArrayList<>();
        for (int i = 0; i < s.count; i++) {
            int x = s.xs[i], y = s.ys[i], z = s.zs[i];
            if (y > layerMax) continue;
            boolean top = y == layerMax;
            if (top || !set.contains(pack(x + 1, y, z)) || !set.contains(pack(x - 1, y, z)) || !set.contains(pack(x, y + 1, z))
                || !set.contains(pack(x, y - 1, z)) || !set.contains(pack(x, y, z + 1)) || !set.contains(pack(x, y, z - 1))) vis.add(i);
        }
        int n = vis.size(), step = Math.max(1, (n + MAX_POINTS - 1) / MAX_POINTS);
        int m = (n + step - 1) / step;
        float[] X = new float[m], Y = new float[m], Z = new float[m];
        int[] C = new int[m];
        int k = 0;
        for (int j = 0; j < n && k < m; j += step) {
            int i = vis.get(j);
            X[k] = s.xs[i] - cx; Y[k] = s.ys[i] - cy; Z[k] = s.zs[i] - cz;
            float b = 0.62f + 0.38f * (s.ys[i] - s.minY) / hy;
            C[k] = shade(col[s.st[i]], b);
            k++;
        }
        return new Model(X, Y, Z, C, k, s.count, layerMax == Integer.MAX_VALUE ? Integer.MAX_VALUE : layerMax);
    }

    private static int colorOf(BlockState st) {
        try {
            int c = st.getMapColor(EmptyBlockView.INSTANCE, BlockPos.ORIGIN).color;
            if (c != 0) return 0xFF000000 | c;
        } catch (Throwable ignored) {}
        return 0xB0C8DCE8; // Glas & Co.: hell, halbdurchsichtig
    }

    private static int shade(int argb, float b) {
        int a = argb >>> 24, r = (int) (((argb >> 16) & 255) * b), g = (int) (((argb >> 8) & 255) * b), bl = (int) ((argb & 255) * b);
        return (a << 24) | (Math.min(255, r) << 16) | (Math.min(255, g) << 8) | Math.min(255, bl);
    }

    private static List<Map.Entry<String, Integer>> materials(ToastySchematic s) {
        Map<Block, Integer> cnt = new HashMap<>();
        for (int i = 0; i < s.count; i++) cnt.merge(s.palette[s.st[i]].getBlock(), 1, Integer::sum);
        List<Map.Entry<String, Integer>> out = new ArrayList<>();
        for (var e : cnt.entrySet()) out.add(Map.entry(e.getKey().getName().getString(), e.getValue()));
        out.sort((a, b) -> Integer.compare(b.getValue(), a.getValue()));
        return out;
    }

    // ---------- Zeichnen ----------
    @Override
    public void renderBackground(DrawContext ctx, int mouseX, int mouseY, float delta) {
        ctx.fillGradient(0, 0, width, height,
            ToastyTheme.alpha(ToastyTheme.lerp(0xFF140B2B, ToastyTheme.PURPLE, 0.15f), 0xC8),
            ToastyTheme.alpha(ToastyTheme.lerp(0xFF140B2B, ToastyTheme.BLUE, 0.12f), 0xF0));
        ToastyTheme.panel(ctx, px, py, pw, ph);
        ToastyLogo.draw(ctx, px + 8, py + 6, 10);
        ToastyTheme.gradientText(ctx, textRenderer, "Schematic-Vorschau", px + 22, py + 7);
        String hint = "Ziehen = drehen · Mausrad = Zoom · Ordner: .minecraft/schematics";
        ctx.drawTextWithShadow(textRenderer, hint, px + pw - 8 - textRenderer.getWidth(hint), py + 7, ToastyTheme.MUTED);
        ToastyTheme.softRect(ctx, lx, ly, lw, lh, 0x22FFFFFF);
        ToastyTheme.softRect(ctx, vx, vy, vw, vh, 0x18FFFFFF);
    }

    @Override
    protected void extra(DrawContext ctx, int mouseX, int mouseY) {
        // Dateiliste
        int rows = Math.max(1, (lh - 4) / 14);
        if (files.isEmpty()) {
            ctx.drawTextWithShadow(textRenderer, "Keine .litematic", lx + 6, ly + 6, ToastyTheme.MUTED);
            ctx.drawTextWithShadow(textRenderer, "im Ordner schematics", lx + 6, ly + 18, ToastyTheme.MUTED);
        }
        for (int i = 0; i < rows && listScroll + i < files.size(); i++) {
            Path f = files.get(listScroll + i);
            int ry = ly + 2 + i * 14;
            boolean sel = f.equals(selected), hov = mouseX >= lx && mouseX < lx + lw && mouseY >= ry && mouseY < ry + 14;
            if (sel || hov) ToastyTheme.roundRectExact(ctx, lx + 2, ry, lw - 4, 13, 4, ToastyTheme.alpha(ToastyTheme.PURPLE, sel ? 0x90 : 0x40));
            String n = f.getFileName().toString().replaceFirst("(?i)\\.litematic$", "");
            ctx.drawTextWithShadow(textRenderer, textRenderer.trimToWidth(n, lw - 10), lx + 6, ry + 3, sel ? 0xFFFFFFFF : ToastyTheme.TEXT);
        }
        if (files.size() > rows) {
            String sc = (listScroll + 1) + "-" + Math.min(files.size(), listScroll + rows) + " / " + files.size();
            ctx.drawTextWithShadow(textRenderer, sc, lx + lw - 4 - textRenderer.getWidth(sc), ly + lh - 10, ToastyTheme.MUTED);
        }

        // 3D-Ansicht
        ToastySchematic s = schem;
        Model m = model;
        if (selected == null) { center(ctx, "Links eine Schematic auswählen"); return; }
        if (!state.isEmpty() && m == null) { center(ctx, state); return; }
        if (s == null || m == null) { center(ctx, "lade …"); return; }

        int sx = s.maxX - s.minX + 1, sy = s.maxY - s.minY + 1, sz = s.maxZ - s.minZ + 1;
        float fit = Math.min(vw, vh) * 0.8f / (float) Math.max(1, Math.sqrt((double) sx * sx + (double) sy * sy + (double) sz * sz));
        float scale = (float) (fit * Math.pow(1.15, zoom));
        double ry = Math.toRadians(yaw), rp = Math.toRadians(pitch);
        float cyw = (float) Math.cos(ry), syw = (float) Math.sin(ry), cp = (float) Math.cos(rp), sp = (float) Math.sin(rp);

        if (order == null || sortedFor != m || sortYaw != yaw || sortPitch != pitch) {
            float[] depth = new float[m.n()];
            Integer[] o = new Integer[m.n()];
            for (int i = 0; i < m.n(); i++) {
                float xr = m.x()[i] * cyw - m.z()[i] * syw;
                float zr = m.x()[i] * syw + m.z()[i] * cyw;
                depth[i] = m.y()[i] * sp + zr * cp;
                o[i] = i;
            }
            Arrays.sort(o, (a, b) -> Float.compare(depth[b], depth[a]));
            order = o; sortedFor = m; sortYaw = yaw; sortPitch = pitch;
        }
        int ox = vx + vw / 2, oy = vy + vh / 2;
        int size = Math.max(1, (int) Math.ceil(scale));
        int half = size / 2;
        ctx.enableScissor(vx, vy, vx + vw, vy + vh);
        for (Integer idx : order) {
            int i = idx;
            float xr = m.x()[i] * cyw - m.z()[i] * syw;
            float zr = m.x()[i] * syw + m.z()[i] * cyw;
            float yr = m.y()[i] * cp - zr * sp;
            int qx = ox + Math.round(xr * scale) - half, qy = oy - Math.round(yr * scale) - half;
            ctx.fill(qx, qy, qx + size, qy + size, m.color()[i]);
        }
        ctx.disableScissor();

        // Infos
        String info = s.name + "  ·  " + sx + "×" + sy + "×" + sz + "  ·  " + String.format(Locale.ROOT, "%,d", s.count).replace(',', '.') + " Blöcke";
        ctx.drawTextWithShadow(textRenderer, textRenderer.trimToWidth(info, vw - 12), vx + 6, vy + 6, ToastyTheme.TEXT);
        String lay = m.layerShown() == Integer.MAX_VALUE ? "Alle Ebenen" : "Ebene " + (m.layerShown() - s.minY + 1) + " / " + sy;
        if (m.n() < 1) lay += " (leer)";
        ctx.drawTextWithShadow(textRenderer, lay, vx + 6, vy + 18, ToastyTheme.MUTED);

        if (showMats && !mats.isEmpty()) {
            int mw = Math.min(170, vw / 3), mx = vx + vw - mw - 6, my = vy + 6;
            int lines = Math.min(mats.size(), Math.max(1, (vh - 30) / 11));
            ToastyTheme.panel(ctx, mx - 4, my - 3, mw + 8, lines * 11 + 18, 0xB0);
            ctx.drawTextWithShadow(textRenderer, "Materialien (" + mats.size() + ")", mx, my, ToastyTheme.PURPLE);
            for (int i = 0; i < lines; i++) {
                var e = mats.get(i);
                int c = e.getValue();
                String amt = c >= 64 ? (c / 64) + "×64" + (c % 64 > 0 ? "+" + c % 64 : "") : String.valueOf(c);
                int ty = my + 13 + i * 11;
                ctx.drawTextWithShadow(textRenderer, textRenderer.trimToWidth(e.getKey(), mw - textRenderer.getWidth(amt) - 6), mx, ty, ToastyTheme.TEXT);
                ctx.drawTextWithShadow(textRenderer, amt, mx + mw - textRenderer.getWidth(amt), ty, ToastyTheme.MUTED);
            }
        }
    }

    private void center(DrawContext ctx, String s) {
        ctx.drawTextWithShadow(textRenderer, s, vx + vw / 2 - textRenderer.getWidth(s) / 2, vy + vh / 2 - 4, ToastyTheme.MUTED);
    }

    // ---------- Maus ----------
    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        if (click.x() >= vx && click.x() < vx + vw && click.y() >= vy && click.y() < vy + vh) { dragging = true; return true; }
        return super.mouseClicked(click, doubled);
    }

    @Override
    public boolean mouseReleased(Click click) {
        dragging = false;
        return super.mouseReleased(click);
    }

    @Override
    public boolean mouseDragged(Click click, double dx, double dy) {
        if (dragging) {
            yaw = (float) ((yaw + dx * 0.6) % 360);
            pitch = (float) Math.max(-89, Math.min(89, pitch + dy * 0.6));
            return true;
        }
        return super.mouseDragged(click, dx, dy);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double h, double v) {
        if (mouseX >= lx && mouseX < lx + lw && mouseY >= ly && mouseY < ly + lh) {
            listScroll = Math.max(0, listScroll - (int) Math.signum(v) * 3);
            clearAndInit();
            return true;
        }
        if (mouseX >= vx && mouseX < vx + vw && mouseY >= vy && mouseY < vy + vh) {
            zoom = (float) Math.max(-10, Math.min(30, zoom + v));
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, h, v);
    }

    @Override
    public boolean shouldPause() { return false; }

    @Override
    public void close() { MinecraftClient.getInstance().setScreen(parent); }

    /** Für Befehle: nach dem Schließen des Chats öffnen. */
    public static void openLater() {
        MinecraftClient mc = MinecraftClient.getInstance();
        mc.send(() -> mc.setScreen(new ToastySchematicScreen(null)));
    }
}
