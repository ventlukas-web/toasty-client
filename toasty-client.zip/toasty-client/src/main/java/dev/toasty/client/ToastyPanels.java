package dev.toasty.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.List;

/** Zusaetzliche HUD-Panels: Zahlungen, Auktion/Giveaway, Twitch-Chat, Toasts. */
public final class ToastyPanels {
    private ToastyPanels() {}

    private record Row(String left, String mid, String right, int color) {}

    public static void render(DrawContext ctx, TextRenderer tr, MinecraftClient mc, ToastyConfig cfg, float delta) {
        if (cfg.payHud) pay(ctx, tr, mc, cfg);
        events(ctx, tr, mc, cfg);
        if (cfg.armorHud) armor(ctx, tr, mc, cfg);
        if (cfg.potionHud) potions(ctx, tr, mc, cfg);
        if (cfg.sessionHud) session(ctx, tr, mc, cfg);
        if (cfg.notesHud) notes(ctx, tr, mc, cfg);
        if (cfg.twitch) twitch(ctx, tr, mc, cfg);
        ToastyEsp.render(ctx, mc, cfg, delta);
        if (cfg.notify) ToastyNotify.render(ctx, tr, mc);
    }

    private static void panel(DrawContext ctx, TextRenderer tr, MinecraftClient mc, ToastyConfig cfg, String id, String title,
                              List<Row> rows, float defX, float defY, int minW) {
        int w = Math.max(minW, tr.getWidth(title) + 4);
        for (Row r : rows) w = Math.max(w, tr.getWidth(r.left()) + 12 + tr.getWidth(r.mid()) + (r.mid().isEmpty() ? 0 : 10) + tr.getWidth(r.right()));
        int pad = 6, h = 17 + rows.size() * 11 + pad;
        float[] pos = ToastyHud.place(id, defX < 0 ? (mc.getWindow().getScaledWidth() - (w + pad * 2) * cfg.hudScale) / 2f : defX, defY,
            (w + pad * 2) * cfg.hudScale, h * cfg.hudScale, mc);
        ctx.getMatrices().pushMatrix();
        ctx.getMatrices().translate(pos[0], pos[1]);
        ctx.getMatrices().scale(cfg.hudScale, cfg.hudScale);
        ToastyTheme.panel(ctx, 0, 0, w + pad * 2, h);
        ToastyTheme.gradientText(ctx, tr, title, pad, 5);
        int y = 17;
        for (Row r : rows) {
            ctx.drawTextWithShadow(tr, r.left(), pad, y, r.color());
            if (!r.mid().isEmpty()) ctx.drawTextWithShadow(tr, r.mid(), pad + tr.getWidth(r.left()) + 10, y, ToastyTheme.TEXT);
            ctx.drawTextWithShadow(tr, r.right(), w + pad - tr.getWidth(r.right()), y, r.color());
            y += 11;
        }
        ctx.getMatrices().popMatrix();
    }

    // Fertige Zahlungen oben (kurz sichtbar), darunter alle wartenden. Wird eine fertig, rutschen die naechsten nach oben.
    private static void pay(DrawContext ctx, TextRenderer tr, MinecraftClient mc, ToastyConfig cfg) {
        long now = System.currentTimeMillis();
        List<Row> rows = new ArrayList<>();
        List<ToastyStats.Done> d = ToastyStats.done;
        for (int i = d.size() - 1; i >= 0 && rows.size() < 4; i--) {
            ToastyStats.Done e = d.get(i);
            if (now - e.at() > 6000) break;
            boolean win = e.result() == 1;
            rows.add(new Row(e.name(), ToastyStats.fmt(e.amount()), win ? "bezahlt" : "verloren", win ? ToastyTheme.GOOD : ToastyTheme.BAD));
        }
        int shown = 0, total = ToastyStats.pending.size();
        for (var e : ToastyStats.pending.entrySet()) {
            if (shown++ >= 14) break;
            rows.add(new Row(e.getKey(), ToastyStats.fmt(e.getValue()), "wartend", 0xFFFBBF24));
        }
        if (total > 14) rows.add(new Row("+" + (total - 14) + " weitere wartend", "", "", ToastyTheme.MUTED));
        if (rows.isEmpty()) rows.add(new Row("keine offenen Zahlungen", "", "", ToastyTheme.MUTED));
        panel(ctx, tr, mc, cfg, "pay", "Zahlungen", rows, -1, 6, 110);
    }

    private static final long START = System.currentTimeMillis();

    private static void armor(DrawContext ctx, TextRenderer tr, MinecraftClient mc, ToastyConfig cfg) {
        if (mc.player == null) return;
        net.minecraft.entity.EquipmentSlot[] sl = {net.minecraft.entity.EquipmentSlot.HEAD, net.minecraft.entity.EquipmentSlot.CHEST,
            net.minecraft.entity.EquipmentSlot.LEGS, net.minecraft.entity.EquipmentSlot.FEET, net.minecraft.entity.EquipmentSlot.MAINHAND};
        List<net.minecraft.item.ItemStack> st = new ArrayList<>();
        for (var s : sl) { var is = mc.player.getEquippedStack(s); if (!is.isEmpty()) st.add(is); }
        int w = 74, rows = Math.max(1, st.size()), h = rows * 18 + 8;
        float[] pos = ToastyHud.place("armor", mc.getWindow().getScaledWidth() - w - 6, mc.getWindow().getScaledHeight() - h - 30,
            w * cfg.hudScale, h * cfg.hudScale, mc);
        ctx.getMatrices().pushMatrix();
        ctx.getMatrices().translate(pos[0], pos[1]);
        ctx.getMatrices().scale(cfg.hudScale, cfg.hudScale);
        ToastyTheme.panel(ctx, 0, 0, w, h);
        int y = 4;
        if (st.isEmpty()) ctx.drawTextWithShadow(tr, "Rüstung", 8, 8, ToastyTheme.MUTED);
        for (var is : st) {
            ctx.drawItem(is, 5, y);
            String t = is.isDamageable() ? String.valueOf(is.getMaxDamage() - is.getDamage()) : (is.getCount() > 1 ? "x" + is.getCount() : "");
            float frac = is.isDamageable() ? 1f - (float) is.getDamage() / Math.max(1, is.getMaxDamage()) : 1f;
            ctx.drawTextWithShadow(tr, t, 26, y + 5, ToastyTheme.lerp(ToastyTheme.BAD, ToastyTheme.GOOD, frac));
            y += 18;
        }
        ctx.getMatrices().popMatrix();
    }

    private static void potions(DrawContext ctx, TextRenderer tr, MinecraftClient mc, ToastyConfig cfg) {
        if (mc.player == null) return;
        List<Row> rows = new ArrayList<>();
        for (var e : mc.player.getStatusEffects()) {
            var type = e.getEffectType().value();
            String name = type.getName().getString() + (e.getAmplifier() > 0 ? " " + (e.getAmplifier() + 1) : "");
            int d = e.getDuration();
            String time = d < 0 || d > 100000 ? "∞" : String.format(java.util.Locale.ROOT, "%d:%02d", d / 1200, (d / 20) % 60);
            rows.add(new Row(name, "", time, type.isBeneficial() ? ToastyTheme.GOOD : ToastyTheme.BAD));
        }
        if (rows.isEmpty()) rows.add(new Row("keine Effekte", "", "", ToastyTheme.MUTED));
        panel(ctx, tr, mc, cfg, "potions", "Effekte", rows, mc.getWindow().getScaledWidth() - 140, 60, 110);
    }

    private static void session(DrawContext ctx, TextRenderer tr, MinecraftClient mc, ToastyConfig cfg) {
        if (mc.player == null) return;
        long sec = (System.currentTimeMillis() - START) / 1000;
        int free = 0;
        for (int i = 0; i < 36; i++) if (mc.player.getInventory().getStack(i).isEmpty()) free++;
        List<Row> rows = new ArrayList<>();
        rows.add(new Row("Spielzeit", "", String.format(java.util.Locale.ROOT, "%d:%02d:%02d", sec / 3600, (sec / 60) % 60, sec % 60), ToastyTheme.TEXT));
        rows.add(new Row("Freie Slots", "", free + "/36", free == 0 ? ToastyTheme.BAD : ToastyTheme.TEXT));
        if (mc.world != null) {
            long t = (mc.world.getTimeOfDay() / 1000 + 6) % 24;
            long m = (mc.world.getTimeOfDay() % 1000) * 60 / 1000;
            rows.add(new Row("Welt-Zeit", "", String.format(java.util.Locale.ROOT, "%02d:%02d", t, m), ToastyTheme.TEXT));
        }
        panel(ctx, tr, mc, cfg, "session", "Session", rows, 6, mc.getWindow().getScaledHeight() / 2f - 60, 120);
    }

    private static void notes(DrawContext ctx, TextRenderer tr, MinecraftClient mc, ToastyConfig cfg) {
        List<Row> rows = new ArrayList<>();
        int n = cfg.notes.size();
        for (int i = 0; i < Math.min(n, 10); i++)
            rows.add(new Row((i + 1) + ". " + tr.trimToWidth(cfg.notes.get(i), 170), "", "", ToastyTheme.TEXT));
        if (n > 10) rows.add(new Row("+" + (n - 10) + " weitere", "", "", ToastyTheme.MUTED));
        if (rows.isEmpty()) rows.add(new Row("/note add <Text>", "", "", ToastyTheme.MUTED));
        panel(ctx, tr, mc, cfg, "notes", "Notizen", rows, mc.getWindow().getScaledWidth() - 190, mc.getWindow().getScaledHeight() / 2f, 150);
    }

    private static void events(DrawContext ctx, TextRenderer tr, MinecraftClient mc, ToastyConfig cfg) {
        List<String[]> r = ToastyEvents.rows();
        if (r.isEmpty()) return;
        List<Row> rows = new ArrayList<>();
        for (String[] s : r) rows.add(new Row(s[0], "", s[1], ToastyTheme.TEXT));
        panel(ctx, tr, mc, cfg, "events", "Events", rows, 6, 120, 120);
    }

    private static void twitch(DrawContext ctx, TextRenderer tr, MinecraftClient mc, ToastyConfig cfg) {
        List<ToastyTwitch.Msg> m = ToastyTwitch.last(Math.max(3, Math.min(15, cfg.twitchLines)));
        int w = 220, pad = 6, h = 17 + Math.max(1, m.size()) * 11 + pad;
        float[] pos = ToastyHud.place("twitch", 6, mc.getWindow().getScaledHeight() / 2f, (w + pad * 2) * cfg.hudScale, h * cfg.hudScale, mc);
        ctx.getMatrices().pushMatrix();
        ctx.getMatrices().translate(pos[0], pos[1]);
        ctx.getMatrices().scale(cfg.hudScale, cfg.hudScale);
        ToastyTheme.panel(ctx, 0, 0, w + pad * 2, h);
        ToastyTheme.gradientText(ctx, tr, "Twitch", pad, 5);
        String st = ToastyTwitch.state;
        ctx.drawTextWithShadow(tr, st, w + pad - tr.getWidth(st), 5, ToastyTheme.MUTED);
        int y = 17;
        if (m.isEmpty()) ctx.drawTextWithShadow(tr, cfg.twitchChannel.isBlank() ? "Kanal im Menü (Extras) setzen" : "warte auf Nachrichten …", pad, y, ToastyTheme.MUTED);
        for (var e : m) {
            String name = e.user() + ": ";
            ctx.drawTextWithShadow(tr, name, pad, y, e.color());
            ctx.drawTextWithShadow(tr, tr.trimToWidth(e.text(), Math.max(10, w - tr.getWidth(name))), pad + tr.getWidth(name), y, ToastyTheme.TEXT);
            y += 11;
        }
        ctx.getMatrices().popMatrix();
    }
}
