package dev.toasty.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.client.sound.SoundInstance;
import net.minecraft.sound.SoundEvent;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

/** Trailer mit Musik (16,5 s) - laeuft beim Spielstart und per Menue/Befehl. Ueberspringen: Skip-Button unten rechts, Leertaste, Enter oder ESC. */
public class ToastyTrailerScreen extends Screen {
    private static final String[][] FEATS = {
        {"Gamble-Helper", "/win · /lose · Auto-Auszahlung · Wartezeit-Ansage"},
        {"Zahlungs-HUD", "Wer hat gezahlt – wartend und fertig, live im Blick"},
        {"Sell-Macro", "Ganzes Inventar per Shift-Klick ins /sell-Menü"},
        {"Freecam & Freelook", "Freecam auf #  ·  Freelook auf B"},
        {"Stream-Chat", "Twitch- und YouTube-Chat im Spiel"},
        {"Mehr HUDs", "Kompass · Armor Durability · Sell Status · Scoreboard"},
    };
    private static final double T_INTRO = 3.5, T_F = 1.5;
    private static final double T_OUT = T_INTRO + T_F * FEATS.length, DUR = T_OUT + 4.0;
    private static final String NAME = "TOASTY CLIENT";
    private static SoundInstance music;

    private final Screen parent;
    private long start;
    private boolean prevClick = true, closed;

    public ToastyTrailerScreen(Screen parent) {
        super(Text.literal("Toasty Trailer"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        if (start != 0) return;
        start = System.currentTimeMillis();
        try {
            MinecraftClient mc = MinecraftClient.getInstance();
            stopMusic();
            music = PositionedSoundInstance.master(SoundEvent.of(Identifier.of("toastyclient", "trailer")), 1.0f);
            mc.getSoundManager().play(music);
        } catch (Throwable ignored) {}
    }

    private static void stopMusic() {
        try { if (music != null) MinecraftClient.getInstance().getSoundManager().stop(music); } catch (Throwable ignored) {}
        music = null;
    }

    @Override
    public void removed() { stopMusic(); }

    @Override
    public void close() {
        if (closed) return;
        closed = true;
        stopMusic();
        MinecraftClient.getInstance().setScreen(parent);
    }

    @Override
    public boolean shouldPause() { return false; }

    private static double clamp(double v) { return Math.max(0, Math.min(1, v)); }
    private static double ease(double t) { t = clamp(t); return 1 - Math.pow(1 - t, 3); }
    private static double back(double t) { t = clamp(t); double c = 1.70158; return 1 + (c + 1) * Math.pow(t - 1, 3) + c * Math.pow(t - 1, 2); }
    private static int a(double alpha) { return (int) Math.max(0, Math.min(255, alpha * 255)); }
    private static int col(int rgb, double alpha) { return ToastyTheme.alpha(0xFF000000 | rgb, a(alpha)); }

    /** Text mit Skalierung, linksbuendig (x,y = obere linke Ecke). */
    private static void text(DrawContext ctx, TextRenderer tr, String s, float x, float y, float scale, int color) {
        ctx.getMatrices().pushMatrix();
        ctx.getMatrices().translate(x, y);
        ctx.getMatrices().scale(scale, scale);
        ctx.drawTextWithShadow(tr, s, 0, 0, color);
        ctx.getMatrices().popMatrix();
    }

    private static void gradText(DrawContext ctx, TextRenderer tr, String s, float x, float y, float scale, double alpha, boolean center) {
        float tot = tr.getWidth(s) * scale;
        float cx = center ? x - tot / 2f : x;
        int n = Math.max(1, s.length() - 1);
        for (int i = 0; i < s.length(); i++) {
            String ch = String.valueOf(s.charAt(i));
            text(ctx, tr, ch, cx, y, scale, ToastyTheme.alpha(ToastyTheme.lerp(ToastyTheme.PURPLE, ToastyTheme.BLUE, (float) i / n), a(alpha)));
            cx += tr.getWidth(ch) * scale;
        }
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        MinecraftClient mc = MinecraftClient.getInstance();
        TextRenderer tr = mc.textRenderer;
        double t = (System.currentTimeMillis() - start) / 1000.0;
        if (start == 0) t = 0;
        long win = mc.getWindow().getHandle();
        boolean click = GLFW.glfwGetMouseButton(win, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        boolean key = GLFW.glfwGetKey(win, GLFW.GLFW_KEY_SPACE) == GLFW.GLFW_PRESS || GLFW.glfwGetKey(win, GLFW.GLFW_KEY_ENTER) == GLFW.GLFW_PRESS;
        int bw = 60, bh = 20, bx = width - bw - 8, by = height - bh - 8;
        boolean over = mx >= bx && mx < bx + bw && my >= by && my < by + bh;
        if (t > 0.3 && ((click && !prevClick && over) || key)) { close(); return; }
        prevClick = click;
        if (t >= DUR) { close(); return; }

        int w = width, h = height;
        int dark = 0xFF05030C;
        ctx.fillGradient(0, 0, w, h, ToastyTheme.lerp(dark, ToastyTheme.PURPLE, 0.38f), ToastyTheme.lerp(dark, ToastyTheme.BLUE, 0.42f));
        for (int i = 0; i < 4; i++) {
            int sz = (int) (h * (0.8 + 0.25 * i));
            int bx = (int) (w * (0.15 + 0.7 * (0.5 + 0.5 * Math.sin(t * 0.35 + i * 1.9))) - sz / 2.0);
            int by = (int) (h * (0.15 + 0.7 * (0.5 + 0.5 * Math.cos(t * 0.27 + i * 2.3))) - sz / 2.0);
            ToastyTheme.roundRectExact(ctx, bx, by, sz, sz, sz / 2, ToastyTheme.alpha(i % 2 == 0 ? ToastyTheme.PURPLE : ToastyTheme.BLUE, 0x1A));
        }
        for (int i = 0; i < 55; i++) {
            float seed = i * 37.17f;
            float px = (float) ((Math.sin(seed) * 0.5 + 0.5) * w + Math.sin(t + i) * 4);
            float py = h - (float) ((t * (14 + (i % 7) * 7) * 0.9 + (seed % 90) * 4) % (h + 20));
            int al = (int) (190 * (0.4 + 0.6 * Math.abs(Math.sin(t * 1.6 + i))));
            int sz = 1 + (i % 4 == 0 ? 1 : 0);
            ctx.fill((int) px, (int) py, (int) px + sz, (int) py + sz,
                ToastyTheme.alpha(ToastyTheme.lerp(ToastyTheme.PURPLE, ToastyTheme.BLUE, (i % 10) / 9f), al));
        }

        // virtuelle 640x360-Flaeche, passend in den Bildschirm eingepasst
        float sc = (float) Math.min(w / 640.0, h / 360.0);
        ctx.getMatrices().pushMatrix();
        ctx.getMatrices().translate((w - 640 * sc) / 2f, (h - 360 * sc) / 2f);
        ctx.getMatrices().scale(sc, sc);

        if (t < T_INTRO) {
            int s = (int) (back(t / 1.0) * 150);
            int bob = (int) (Math.sin(t * 2.2) * 3);
            ToastyLogo.draw(ctx, 320 - s / 2, 125 + bob - s / 2, s);
            float ns = 5.4f;
            float tot = tr.getWidth(NAME) * ns, x = 320 - tot / 2f;
            for (int i = 0; i < NAME.length(); i++) {
                String ch = String.valueOf(NAME.charAt(i));
                double al = ease((t - 1.0 - i * 0.06) / 0.35);
                if (al > 0.02 && !ch.equals(" "))
                    text(ctx, tr, ch, x, (float) (205 + (1 - al) * 14), ns,
                        ToastyTheme.alpha(ToastyTheme.lerp(ToastyTheme.PURPLE, ToastyTheme.BLUE, i / 12f), a(al)));
                x += tr.getWidth(ch) * ns;
            }
            int ln = (int) (ease((t - 1.6) / 0.8) * 350);
            if (ln > 0) ToastyTheme.hGradient(ctx, 320 - ln / 2, 272, ln, 2, ToastyTheme.PURPLE, ToastyTheme.BLUE);
            String sub = "Fabric-Client für WindSMP";
            float ss = 1.9f;
            text(ctx, tr, sub, 320 - tr.getWidth(sub) * ss / 2f, 290, ss, col(0xF3EEFF, ease((t - 2.3) / 0.6)));
        } else if (t < T_OUT) {
            double k = t - T_INTRO;
            int idx = Math.min(FEATS.length - 1, (int) (k / T_F));
            double lt = (k - idx * T_F) / T_F;
            ToastyLogo.draw(ctx, 22, 17, 42);
            gradText(ctx, tr, NAME, 70, 29, 1.9f, 1.0, false);
            double al = Math.min(ease(lt / 0.22), 1 - ease((lt - 0.82) / 0.18));
            int off = (int) ((1 - ease(lt / 0.3)) * 45);
            int cx0 = 60, cy0 = 125, cw = 520, ch = 150;
            ToastyTheme.roundRectExact(ctx, cx0 + off, cy0, cw, ch, 19, ToastyTheme.alpha(0xFF140B2B, a(al * 0.8)));
            ToastyTheme.roundOutlineExact(ctx, cx0 + off, cy0, cw, ch, 19, ToastyTheme.alpha(ToastyTheme.lerp(ToastyTheme.PURPLE, ToastyTheme.BLUE, 0.5f), a(al * 0.47)));
            text(ctx, tr, String.format("%02d", idx + 1), cx0 + 28 + off, cy0 + 20, 1.9f, col(0x7DD3FC, al));
            String title = FEATS[idx][0], desc = FEATS[idx][1];
            float tsc = (float) Math.min(4.6, 460.0 / Math.max(1, tr.getWidth(title)));
            gradText(ctx, tr, title, cx0 + 28 + off, cy0 + 44, tsc, al, false);
            float dsc = (float) Math.min(1.9, 464.0 / Math.max(1, tr.getWidth(desc)));
            text(ctx, tr, desc, cx0 + 29 + off, cy0 + 112, dsc, col(0xF3EEFF, al * 0.92));
            for (int i = 0; i < FEATS.length; i++) {
                int x = 320 - FEATS.length * 14 + i * 28;
                if (i == idx) ToastyTheme.roundRectExact(ctx, x, 320, 17, 4, 2, 0xFF7DD3FC);
                else ToastyTheme.roundRectExact(ctx, x, 320, 7, 4, 2, 0x966E64A0);
            }
        } else {
            double k = t - T_OUT;
            int s = (int) (back(k / 0.8) * 165);
            int bob = (int) (Math.sin(t * 2.2) * 3);
            ToastyLogo.draw(ctx, 320 - s / 2, 117 + bob - s / 2, s);
            float ns = (float) Math.min(5.4, 560.0 / tr.getWidth(NAME));
            gradText(ctx, tr, NAME, 320, 190, ns, ease((k - 0.5) / 0.6), true);
            String l1 = "Alles im Mod-Menü  ·  Rechte Shift", l2 = "Fabric 1.21.11  ·  für WindSMP";
            text(ctx, tr, l1, 320 - tr.getWidth(l1) * 1.9f / 2f, 255, 1.9f, col(0xF3EEFF, ease((k - 1.0) / 0.6)));
            text(ctx, tr, l2, 320 - tr.getWidth(l2) * 1.6f / 2f, 280, 1.6f, col(0xB8B5E6, ease((k - 1.3) / 0.6)));
        }
        ctx.getMatrices().popMatrix();

        // Ein- und Ausblenden + Skip-Hinweis
        double fade = 0;
        if (t < 0.4) fade = 1 - t / 0.4;
        double fo = clamp((t - (DUR - 0.5)) / 0.5);
        fade = Math.max(fade, fo);
        if (fade > 0.01) ctx.fill(0, 0, w, h, ToastyTheme.alpha(dark, a(fade)));
        if (t > 0.3) {
            ToastyTheme.roundRectExact(ctx, bx, by, bw, bh, bh / 2, ToastyTheme.alpha(over ? ToastyTheme.PURPLE : 0xFF140B2B, over ? 0xF0 : 0xB8));
            ToastyTheme.roundOutlineExact(ctx, bx, by, bw, bh, bh / 2, ToastyTheme.alpha(ToastyTheme.BLUE, over ? 0xFF : 0x90));
            String sk = "Skip »";
            ctx.drawTextWithShadow(tr, sk, bx + (bw - tr.getWidth(sk)) / 2, by + (bh - 8) / 2, ToastyTheme.TEXT);
        }
    }
}
