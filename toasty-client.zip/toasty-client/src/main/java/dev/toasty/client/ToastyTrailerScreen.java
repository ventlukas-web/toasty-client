package dev.toasty.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.sound.AbstractSoundInstance;
import net.minecraft.sound.SoundCategory;
import net.minecraft.client.sound.SoundInstance;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

/** Edit-Trailer mit Musik (27,5 s) - laeuft beim Spielstart und per Menue/Befehl. Ueberspringen: Skip-Button unten rechts, Leertaste, Enter oder ESC. */
public class ToastyTrailerScreen extends Screen {
    private static final double DROP = 4.0, OUT = 22.0, DUR = 27.5, BEAT = 0.4;
    private static final String[][] SC = {
        {"ALLES IN EINEM MENÜ", "Right Shift · 7 Bereiche, alles ausklappbar"},
        {"EIN KLICK. ALLES AN/AUS.", "Der große Toasty-Client-Schalter"},
        {"GAMBLE-HELPER", "Roulette mit rollender Kugel · Stats live"},
        {"ZAHLUNGEN & SELL", "Warteschlange und Sell-Status im HUD"},
        {"PVP-HUDS", "Keystrokes · CPS · Reach · Combo"},
        {"9 THEMES", "Farben, Hintergrund und Deckkraft – ein Klick"},
        {"EIGENER MAUSZEIGER", "Kreuz · Ring · Punkt · Raute"},
        {"STREAMING", "Twitch- und YouTube-Chat direkt im Spiel"},
        {"UND NOCH VIEL MEHR", "Alles im Mod-Menü"}};
    private static final String NAME = "TOASTY CLIENT";
    private static SoundInstance music;

    /** Eigene Sound-Instanz (unabhaengig von Registry-Signaturen): Musik ohne Position, Lautstaerke ueber "Master". */
    private static final class TrailerSound extends AbstractSoundInstance {
        TrailerSound() {
            super(Identifier.of("toastyclient", "trailer"), SoundCategory.MASTER, net.minecraft.util.math.random.Random.create());
            this.volume = 1.0f;
            this.pitch = 1.0f;
            this.relative = true;
            this.attenuationType = SoundInstance.AttenuationType.NONE;
        }
    }

    private final Screen parent;
    private long start;
    private boolean prevClick = true, closed;

    public ToastyTrailerScreen(Screen parent) {
        super(Text.literal("Toasty Trailer"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        if (start != 0) return;
        start = System.currentTimeMillis();
        try {
            MinecraftClient mc = MinecraftClient.getInstance();
            stopMusic();
            music = new TrailerSound();
            mc.getSoundManager().play(music);
        } catch (Throwable ignored) {}
    }

    private static void stopMusic() {
        try { if (music != null) MinecraftClient.getInstance().getSoundManager().stop(music); } catch (Throwable ignored) {}
        music = null;
    }

    @Override
    public void removed() { stopMusic(); }

    @Override
    public void close() {
        if (closed) return;
        closed = true;
        stopMusic();
        MinecraftClient.getInstance().setScreen(parent);
    }

    @Override
    public boolean shouldPause() { return false; }

    private static double clamp(double v) { return Math.max(0, Math.min(1, v)); }
    private static double ease(double t) { t = clamp(t); return 1 - Math.pow(1 - t, 3); }
    private static double back(double t) { t = clamp(t); double c = 1.70158; return 1 + (c + 1) * Math.pow(t - 1, 3) + c * Math.pow(t - 1, 2); }
    private static int a(double alpha) { return (int) Math.max(0, Math.min(255, alpha * 255)); }
    private static int col(int rgb, double alpha) { return ToastyTheme.alpha(0xFF000000 | rgb, a(alpha)); }

    /** Text mit Skalierung, linksbuendig (x,y = obere linke Ecke). */
    private static void text(DrawContext ctx, TextRenderer tr, String s, float x, float y, float scale, int color) {
        ctx.getMatrices().pushMatrix();
        ctx.getMatrices().translate(x, y);
        ctx.getMatrices().scale(scale, scale);
        ctx.drawTextWithShadow(tr, s, 0, 0, color);
        ctx.getMatrices().popMatrix();
    }

    private static void gradText(DrawContext ctx, TextRenderer tr, String s, float x, float y, float scale, double alpha, boolean center) {
        float tot = tr.getWidth(s) * scale;
        float cx = center ? x - tot / 2f : x;
        int n = Math.max(1, s.length() - 1);
        for (int i = 0; i < s.length(); i++) {
            String ch = String.valueOf(s.charAt(i));
            text(ctx, tr, ch, cx, y, scale, ToastyTheme.alpha(ToastyTheme.lerp(ToastyTheme.PURPLE, ToastyTheme.BLUE, (float) i / n), a(alpha)));
            cx += tr.getWidth(ch) * scale;
        }
    }

    private static int ca(int c, double al) {
        return ToastyTheme.alpha(c, a(((c >>> 24) & 0xFF) / 255.0 * al));
    }

    private static void ctext(DrawContext ctx, TextRenderer tr, String s, float cx, float y, float sc, int color) {
        text(ctx, tr, s, cx - tr.getWidth(s) * sc / 2f, y, sc, color);
    }

    private static void hudPanel(DrawContext ctx, TextRenderer tr, float x, float y, float w, String title, String[][] rows, int[] vc, double u, double t0) {
        double pop = ease((u - t0) / 0.4);
        if (pop <= 0.01) return;
        float h = 24 + rows.length * 13;
        float oy = (float) ((1 - back((u - t0) / 0.4)) * 12);
        ToastyTheme.roundRectExact(ctx, (int) x, (int) (y + oy), (int) w, (int) h, 7, ca(0xFF140B2B, pop * 0.88));
        ToastyTheme.roundOutlineExact(ctx, (int) x, (int) (y + oy), (int) w, (int) h, 7, ca(ToastyTheme.lerp(ToastyTheme.PURPLE, ToastyTheme.BLUE, 0.5f), pop * 0.45));
        gradText(ctx, tr, title, x + 8, y + oy + 6, 1.1f, pop, false);
        for (int i = 0; i < rows.length; i++) {
            float ry = y + oy + 22 + i * 13;
            text(ctx, tr, rows[i][0], x + 8, ry, 1.0f, ca(0xFFF3EEFF, pop));
            text(ctx, tr, rows[i][1], x + w - 8 - tr.getWidth(rows[i][1]), ry, 1.0f, ca(vc[i], pop));
        }
    }

    private static void win(DrawContext ctx, int x, int y, int w, int h, double al) {
        ToastyTheme.roundRectExact(ctx, x, y, w, h, 8, ca(0xFF222842, al * 0.92));
        ToastyTheme.roundRectExact(ctx, x, y, w, 20, 8, ca(0xFF000000, al * 0.25));
        ToastyTheme.roundOutlineExact(ctx, x, y, w, h, 8, ca(0xFFFFFFFF, al * 0.18));
    }

    private static void row(DrawContext ctx, TextRenderer tr, int x, int y, int w, String name, boolean on, double al) {
        text(ctx, tr, name, x + 6, y + 6, 1.0f, ca(on ? 0xFFF3EEFF : 0xFFC9C7E0, al));
        ToastyTheme.toggleSwitch(ctx, x + w - 30, y + 4, on);
    }

    private static void key(DrawContext ctx, TextRenderer tr, int x, int y, String k, boolean on, double al) {
        ToastyTheme.roundRectExact(ctx, x, y, 34, 34, 8, ca(on ? 0xFF4C6BE0 : 0xFF222842, al * 0.92));
        ToastyTheme.roundOutlineExact(ctx, x, y, 34, 34, 8, ca(on ? 0xFF7DD3FC : 0xFFFFFFFF, al * (on ? 0.8 : 0.2)));
        ctext(ctx, tr, k, x + 17, y + 13, 1.2f, ca(0xFFF3EEFF, al));
    }

    /** Eine Szene des Edits; u = Sekunden seit Szenenbeginn (0..2). */
    private void editScene(DrawContext ctx, TextRenderer tr, int si, double u) {
        int GR = 0xFF4ADE80, AM = 0xFFFBBF24, WH = 0xFFB8B5E6;
        double al = ease(u / 0.2);
        int beat = (int) (u / BEAT);
        switch (si) {
            case 0 -> {
                win(ctx, 190, 120, 260, 190, al);
                text(ctx, tr, "General", 199, 126, 1.2f, ca(0xFFF3EEFF, al));
                String[] n = {"Fullbright", "Zoom", "Keystrokes", "Crosshair", "Koordinaten"};
                for (int i = 0; i < n.length; i++) row(ctx, tr, 196, 150 + i * 28, 248, n[i], u > 0.3 + i * 0.28, al);
            }
            case 1 -> {
                boolean on = ((int) (u / 0.9)) % 2 == 0;
                ToastyTheme.bigPill(ctx, 170, 150, 300, 36, 0f, on);
                ctext(ctx, tr, "Toasty Client  ·  Alle Features " + (on ? "AN" : "AUS"), 320, 164, 1.2f, ca(0xFFFFFFFF, al));
                win(ctx, 190, 205, 260, 110, al);
                String[] n = {"HUD", "Keystrokes", "Fullbright"};
                for (int i = 0; i < n.length; i++) row(ctx, tr, 196, 214 + i * 28, 248, n[i], on, al);
            }
            case 2 -> {
                hudPanel(ctx, tr, 60, 150, 130, "Toasty", new String[][]{{"Profit", "+1.25M"}, {"Rounds", "13"}, {"Winrate", "57%"}}, new int[]{GR, WH, WH}, u, 0.0);
                double g = u - 0.35;
                if (g > 0) {
                    float sc = (float) (3.0 + 0.9 * (1 - back(g / 0.3)));
                    gradText(ctx, tr, "GEWONNEN", 400, 150, sc * 0.8f, Math.min(1, g / 0.15), true);
                    ctext(ctx, tr, "+1.25M", 400, 150 + 8 * sc * 0.8f + 8, 2.4f, ca(GR, Math.min(1, g / 0.15)));
                }
            }
            case 3 -> {
                hudPanel(ctx, tr, 60, 140, 176, "Zahlungen", new String[][]{{"Spieler1", "500k  0:10"}, {"Spieler2", "250k  0:05"}, {"Spieler3", "1M  0:00"}}, new int[]{AM, AM, AM}, u, 0.0);
                hudPanel(ctx, tr, 360, 140, 130, "Sell Status", new String[][]{{"Status", "läuft"}, {"Durchläufe", "8"}, {"Verkauft", "369 Items"}, {"Tempo", "1064/min"}}, new int[]{GR, WH, WH, WH}, u, 0.25);
            }
            case 4 -> {
                key(ctx, tr, 120, 150, "W", beat % 4 == 0, al);
                key(ctx, tr, 80, 190, "A", beat % 4 == 1, al);
                key(ctx, tr, 120, 190, "S", beat % 4 == 2, al);
                key(ctx, tr, 160, 190, "D", beat % 4 == 3, al);
                hudPanel(ctx, tr, 290, 140, 130, "PvP", new String[][]{{"CPS", String.valueOf(10 + beat % 5)}, {"Reach", "3.0"}, {"Combo", String.valueOf(2 + beat)}}, new int[]{WH, WH, GR}, u, 0.1);
            }
            case 5 -> {
                int[][] cols = {{0xA855F7, 0x7DD3FC}, {0xF472B6, 0xFBBF24}, {0x4ADE80, 0x22D3EE}, {0xFB7185, 0xF97316}, {0x60A5FA, 0xA78BFA},
                    {0xFACC15, 0xEF4444}, {0x2DD4BF, 0x3B82F6}, {0xE879F9, 0x818CF8}, {0xF43F5E, 0xF59E0B}};
                int sel = (int) Math.min(8, u / 0.2);
                ctx.fill(0, 90, 640, 270, ToastyTheme.alpha(0xFF000000 | cols[sel][0], 0x26));
                for (int i = 0; i < 9; i++) {
                    int x = 40 + i * 62;
                    ToastyTheme.roundRectExact(ctx, x, 180, 54, 22, 11, ca(0xFF000000 | cols[i][0], al));
                    ToastyTheme.hGradient(ctx, x + 11, 180, 32, 22, 0xFF000000 | cols[i][0], 0xFF000000 | cols[i][1]);
                    ToastyTheme.roundRectExact(ctx, x + 43, 180, 11, 22, 5, ca(0xFF000000 | cols[i][1], al));
                    if (i == sel) ToastyTheme.roundOutlineExact(ctx, x - 2, 178, 58, 26, 13, ca(0xFFFFFFFF, al));
                }
            }
            case 6 -> {
                int sel = beat % 4;
                String[] nm = {"Kreuz", "Ring", "Punkt", "Raute"};
                for (int i = 0; i < 4; i++) {
                    int cx = 140 + i * 120, cy = 190;
                    int c = ca(i == sel ? 0xFF7DD3FC : 0xFFFFFFFF, al);
                    ToastyTheme.roundRectExact(ctx, cx - 40, cy - 40, 80, 80, 12, ca(0xFF222842, al * 0.9));
                    if (i == sel) ToastyTheme.roundOutlineExact(ctx, cx - 40, cy - 40, 80, 80, 12, ca(0xFF7DD3FC, al));
                    switch (i) {
                        case 0 -> { ctx.fill(cx - 12, cy - 1, cx + 12, cy + 1, c); ctx.fill(cx - 1, cy - 12, cx + 1, cy + 12, c); }
                        case 1 -> ToastyTheme.roundOutlineExact(ctx, cx - 11, cy - 11, 22, 22, 11, c);
                        case 2 -> ToastyTheme.roundRectExact(ctx, cx - 4, cy - 4, 8, 8, 4, c);
                        default -> { for (int k = 0; k < 12; k++) { int wd = k < 6 ? k : 11 - k; ctx.fill(cx - wd - 1, cy - 6 + k, cx + wd + 1, cy - 5 + k, c); } }
                    }
                    ctext(ctx, tr, nm[i], cx, cy + 50, 1.0f, ca(0xFFB8B5E6, al));
                }
            }
            case 7 -> {
                String[][] tw = {{"Streamer", "gleich gehts los!"}, {"Viewer1", "Toasty Client is da"}, {"Viewer2", "LET'S GO"}};
                String[][] yt = {{"Nutzer A", "Hallo aus dem Chat"}, {"Nutzer B", "starker Client"}, {"Nutzer C", "GG"}};
                for (int p = 0; p < 2; p++) {
                    int x = 60 + p * 280;
                    win(ctx, x, 130, 240, 120, al);
                    text(ctx, tr, p == 0 ? "Twitch Chat" : "YouTube Chat", x + 9, 136, 1.2f, ca(p == 0 ? 0xFFA970FF : 0xFFFF5555, al));
                    String[][] m = p == 0 ? tw : yt;
                    for (int i = 0; i < 3; i++) {
                        double d0 = u - 0.25 - i * 0.3 - p * 0.1;
                        if (d0 < 0) continue;
                        double a2 = ease(d0 / 0.2);
                        text(ctx, tr, m[i][0] + ": " + m[i][1], x + 9 + (float) ((1 - a2) * 20), 162 + i * 24, 1.0f, ca(0xFFF3EEFF, a2));
                    }
                }
            }
            default -> {
                String[] t = {"Crosshair", "Wegpunkte", "Notizen", "Saturation-Rand", "NoFog", "Eigener Nametag", "Auto-Reconnect", "Auktionen"};
                for (int i = 0; i < 8; i++) {
                    double pop = ease((u - i * 0.15) / 0.25);
                    if (pop <= 0.01) continue;
                    int x = 20 + (i % 4) * 150, y = 130 + (i / 4) * 70;
                    ToastyTheme.roundRectExact(ctx, x, y, 140, 50, 10, ca(0xFF222842, pop * 0.92));
                    ToastyTheme.roundOutlineExact(ctx, x, y, 140, 50, 10, ca(ToastyTheme.BLUE, pop * 0.5));
                    float ts = Math.min(1.6f, 124f / tr.getWidth(t[i]));
                    gradText(ctx, tr, t[i], x + 70, y + 25 - 4 * ts, ts, pop, true);
                }
            }
        }
    }


    // ---- Mauszeiger im Edit: Keyframes {u, x, y} in der virtuellen 640x360-Flaeche ----
    private static double[][] curPath(int si) {
        switch (si) {
            case 0: return new double[][]{{0, 520, 120}, {0.25, 424, 164}, {0.6, 424, 192}, {0.9, 424, 220}, {1.2, 424, 248}, {1.5, 424, 276}, {2, 300, 300}};
            case 1: return new double[][]{{0, 520, 250}, {0.5, 320, 168}, {1.0, 322, 169}, {1.7, 322, 169}, {2, 322, 170}};
            case 2: return new double[][]{{0, 120, 300}, {0.4, 300, 230}, {1.0, 400, 190}, {2, 470, 210}};
            case 3: return new double[][]{{0, 520, 300}, {0.6, 130, 220}, {1.2, 330, 200}, {2, 430, 220}};
            case 4: return new double[][]{{0, 520, 300}, {0.5, 140, 168}, {1.0, 100, 208}, {1.4, 140, 208}, {1.8, 180, 208}, {2, 190, 212}};
            case 5: { double[][] k = new double[10][]; for (int i = 0; i < 9; i++) k[i] = new double[]{i * 0.2, 40 + i * 62 + 27, 191}; k[9] = new double[]{2, 560, 220}; return k; }
            case 6: return new double[][]{{0, 140, 190}, {0.4, 260, 190}, {0.8, 380, 190}, {1.2, 500, 190}, {1.6, 140, 190}, {2, 260, 190}};
            case 7: return new double[][]{{0, 520, 300}, {0.8, 180, 215}, {1.5, 460, 215}, {2, 500, 260}};
            default: return new double[][]{{0, 320, 300}, {0.4, 90, 155}, {0.8, 240, 155}, {1.2, 390, 155}, {1.6, 540, 155}, {2, 90, 225}};
        }
    }

    private static double[] curClicks(int si) {
        switch (si) {
            case 0: return new double[]{0.3, 0.58, 0.86, 1.14, 1.42};
            case 1: return new double[]{0.9, 1.8};
            case 2: return new double[]{0.35};
            case 3: return new double[]{0.6, 1.2};
            case 4: return new double[]{1.0, 1.4, 1.8};
            case 5: return new double[]{0.2, 0.4, 0.6, 0.8, 1.0, 1.2, 1.4, 1.6, 1.8};
            case 6: return new double[]{0.4, 0.8, 1.2, 1.6};
            case 7: return new double[]{0.8, 1.5};
            default: return new double[]{0.4, 0.8, 1.2, 1.6};
        }
    }

    private static void arrow(DrawContext ctx, int x, int y, double press, double al) {
        int[] wd = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 6, 7, 7, 4, 4, 3};
        int n = wd.length;
        for (int pass = 0; pass < 2; pass++) {
            int o = pass == 0 ? 1 : 0;
            int c = pass == 0 ? ToastyTheme.alpha(0xFF000000, a(0.45 * al)) : ToastyTheme.alpha(0xFFFFFFFF, a(al));
            for (int k = 0; k < n; k++) ctx.fill(x + o, y + k + o, x + wd[k] + o, y + k + 1 + o, c);
        }
    }

    private void cursorOverlay(DrawContext ctx, double u, double[][] kf, double[] clicks, double al) {
        double x = kf[0][1], y = kf[0][2];
        if (u >= kf[kf.length - 1][0]) { x = kf[kf.length - 1][1]; y = kf[kf.length - 1][2]; }
        else for (int i = 0; i + 1 < kf.length; i++) {
            if (u <= kf[i + 1][0]) {
                double p = ease((u - kf[i][0]) / Math.max(1e-6, kf[i + 1][0] - kf[i][0]));
                x = kf[i][1] + (kf[i + 1][1] - kf[i][1]) * p; y = kf[i][2] + (kf[i + 1][2] - kf[i][2]) * p;
                break;
            }
        }
        for (double ct : clicks) {
            double d = u - ct;
            if (d > 0 && d < 0.35) {
                int r = (int) (4 + d / 0.35 * 16);
                ToastyTheme.roundOutlineExact(ctx, (int) x - r, (int) y - r, r * 2, r * 2, r, ToastyTheme.alpha(0xFFFFFFFF, a(0.85 * (1 - d / 0.35) * al)));
            }
        }
        arrow(ctx, (int) x, (int) y, 0, al);
    }

    private void caption(DrawContext ctx, TextRenderer tr, String title, String sub, double u) {
        double a = ease(u / 0.22);
        float off = (float) ((1 - ease(u / 0.3)) * 18);
        float sc = (float) Math.min(3.0, 600.0 / tr.getWidth(title));
        gradText(ctx, tr, title, 320, 22 + off, sc, a, true);
        ctext(ctx, tr, sub, 320, 22 + 8 * sc + 8 + off * 0.5f, 1.3f, ca(0xFFF3EEFF, Math.min(1, Math.max(0, (u - 0.1) / 0.25))));
    }

    private void intro(DrawContext ctx, TextRenderer tr, double t) {
        String[] words = {"DEIN MINECRAFT.", "DEIN CLIENT.", "ALLES. IN EINEM MENÜ."};
        double[][] tw = {{0.45, 1.4}, {1.4, 2.3}, {2.3, 3.55}};
        for (int i = 0; i < 3; i++) {
            if (t < tw[i][0] || t >= tw[i][1]) continue;
            double u = t - tw[i][0], len = tw[i][1] - tw[i][0];
            double a = ease(u / 0.12) * (1 - ease((u - (len - 0.1)) / 0.1));
            float sc0 = (float) Math.min(5.0, 600.0 / tr.getWidth(words[i]));
            float sc = sc0 * (float) (1 + 0.22 * (1 - ease(u / 0.18)));
            float dx = (float) (5 * (1 - ease(u / 0.5)));
            float x = 320 - tr.getWidth(words[i]) * sc / 2f, y = 160 - 4 * sc;
            if (i < 2) {
                text(ctx, tr, words[i], x - dx, y, sc, ToastyTheme.alpha(0xFFFF3C5A, a((a * 0.7))));
                text(ctx, tr, words[i], x + dx, y, sc, ToastyTheme.alpha(0xFF3CDCFF, a((a * 0.7))));
                text(ctx, tr, words[i], x, y, sc, col(0xFFFFFF, a));
            } else gradText(ctx, tr, words[i], 320, y, sc, a, true);
        }
        if (t >= 3.55 && t < 3.95 && ((int) ((t - 3.55) * 30)) % 2 == 0) ToastyLogo.draw(ctx, 245, 105, 150);
    }

    private void outro(DrawContext ctx, TextRenderer tr, double t) {
        double k = t - OUT;
        int s = (int) (back(k / 0.8) * 150);
        int bob = (int) (Math.sin(t * 2.2) * 3);
        ToastyLogo.draw(ctx, 320 - s / 2, 85 + bob - s / 2, s);
        float ns = (float) Math.min(5.0, 560.0 / tr.getWidth(NAME));
        gradText(ctx, tr, NAME, 320, 170, ns, ease((k - 0.5) / 0.6), true);
        double ka = ease((k - 1.0) / 0.5);
        int kw = 150, kh = 34, kx = 320 - kw / 2, ky = 225;
        int edge = ToastyTheme.lerp(ToastyTheme.PURPLE, ToastyTheme.BLUE, 0.5f);
        ToastyTheme.roundRectExact(ctx, kx, ky + 4, kw, kh, 10, ca(ToastyTheme.lerp(0xFF05030C, edge, 0.35f), ka));
        ToastyTheme.roundRectExact(ctx, kx, ky, kw, kh, 10, ca(0xFF1B1240, ka * 0.97));
        ToastyTheme.roundOutlineExact(ctx, kx, ky, kw, kh, 10, ca(edge, ka * 0.9));
        gradText(ctx, tr, "Right Shift", 320, ky + 9, 2.0f, ka, true);
        String l1 = "Just one click away.", l2 = "Fabric 1.21.11";
        text(ctx, tr, l1, 320 - tr.getWidth(l1) * 1.9f / 2f, 280, 1.9f, col(0xF3EEFF, ease((k - 1.5) / 0.6)));
        text(ctx, tr, l2, 320 - tr.getWidth(l2) * 1.4f / 2f, 305, 1.4f, col(0xB8B5E6, ease((k - 1.8) / 0.6)));
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        MinecraftClient mc = MinecraftClient.getInstance();
        TextRenderer tr = mc.textRenderer;
        double t = (System.currentTimeMillis() - start) / 1000.0;
        if (start == 0) t = 0;
        long win = mc.getWindow().getHandle();
        boolean click = GLFW.glfwGetMouseButton(win, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        boolean key = GLFW.glfwGetKey(win, GLFW.GLFW_KEY_SPACE) == GLFW.GLFW_PRESS || GLFW.glfwGetKey(win, GLFW.GLFW_KEY_ENTER) == GLFW.GLFW_PRESS;
        int bw = 60, bh = 20, bx = width - bw - 8, by = height - bh - 8;
        boolean over = mx >= bx && mx < bx + bw && my >= by && my < by + bh;
        if (t > 0.3 && ((click && !prevClick && over) || key)) { close(); return; }
        prevClick = click;
        if (t >= DUR) { close(); return; }

        int w = width, h = height;
        int dark = 0xFF05030C;
        ctx.fillGradient(0, 0, w, h, ToastyTheme.lerp(dark, ToastyTheme.PURPLE, 0.20f), ToastyTheme.lerp(dark, ToastyTheme.BLUE, 0.55f));
        // virtuelle 640x360-Flaeche, passend in den Bildschirm eingepasst; im Takt leichtes Pumpen, Shake beim Drop
        float sc = (float) Math.min(w / 640.0, h / 360.0);
        double pump = 0;
        if (t >= DROP && t < OUT) pump = Math.exp(-((t - DROP) % BEAT) * 10) * 0.025;
        float shake = t >= DROP && t < DROP + 0.45 ? (float) (Math.exp(-(t - DROP) * 8) * 6) : 0;
        ctx.getMatrices().pushMatrix();
        ctx.getMatrices().translate(w / 2f + (float) Math.sin(t * 90) * shake, h / 2f + (float) Math.cos(t * 77) * shake);
        ctx.getMatrices().scale(sc * (float) (1 + pump), sc * (float) (1 + pump));
        ctx.getMatrices().translate(-320, -180);

        if (t < DROP) {
            intro(ctx, tr, t);
        } else if (t < OUT) {
            int si = Math.min(8, (int) ((t - DROP) / 2));
            double u = (t - DROP) - si * 2;
            editScene(ctx, tr, si, u);
            cursorOverlay(ctx, u, curPath(si), curClicks(si), ease(u / 0.15));
            caption(ctx, tr, SC[si][0], SC[si][1], u);
        } else {
            outro(ctx, tr, t);
            double ok = t - OUT;
            if (ok > 0.9) cursorOverlay(ctx, ok - 0.9, new double[][]{{0, 460, 330}, {0.5, 330, 245}, {1.5, 330, 245}}, new double[]{0.5}, ease((ok - 0.9) / 0.2));
        }
        ctx.getMatrices().popMatrix();

        // Ein- und Ausblenden + Skip-Hinweis
        double fade = 0;
        if (t < 0.4) fade = 1 - t / 0.4;
        double fo = clamp((t - (DUR - 0.5)) / 0.5);
        fade = Math.max(fade, fo);
        if (fade > 0.01) ctx.fill(0, 0, w, h, ToastyTheme.alpha(dark, a(fade)));
        for (int i = 0; i <= 10; i++) {
            double st = i < 10 ? DROP + 2 * i : OUT;
            if (i == 9) continue;
            double d0 = t - st;
            if (d0 >= 0 && d0 < 0.12) ctx.fill(0, 0, w, h, ToastyTheme.alpha(0xFFFFFFFF, a((1 - d0 / 0.12) * (i == 0 || i == 10 ? 0.6 : 0.4))));
        }
        if (t > 0.3) {
            ToastyTheme.roundRectExact(ctx, bx, by, bw, bh, bh / 2, ToastyTheme.alpha(over ? ToastyTheme.PURPLE : 0xFF140B2B, over ? 0xF0 : 0xB8));
            ToastyTheme.roundOutlineExact(ctx, bx, by, bw, bh, bh / 2, ToastyTheme.alpha(ToastyTheme.BLUE, over ? 0xFF : 0x90));
            String sk = "Skip »";
            ctx.drawTextWithShadow(tr, sk, bx + (bw - tr.getWidth(sk)) / 2, by + (bh - 8) / 2, ToastyTheme.TEXT);
        }
    }
}
