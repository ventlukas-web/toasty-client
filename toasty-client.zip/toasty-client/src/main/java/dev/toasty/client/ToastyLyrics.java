package dev.toasty.client;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Sky Lyrics: zeigt den synchronen Songtext des gerade laufenden Titels (Spotify, Apple Music, Browser ...).
 * Windows: ein dauerhaft laufender PowerShell-Prozess liest die System-Mediensteuerung (nur im Hintergrund-Thread).
 * Lyrics kommen von LRCLIB. Im Render-Thread wird nur Text gezeichnet, es gibt keine Netzwerk- oder Prozessarbeit.
 */
public final class ToastyLyrics {
    private ToastyLyrics() {}

    private static final HttpClient HTTP = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(6)).build();
    private static final Pattern LRC = Pattern.compile("\\[(\\d+):(\\d+)(?:[.:](\\d+))?]\\s*(.*)");

    private static final String PS = String.join("\n",
        "[Console]::OutputEncoding = [System.Text.Encoding]::UTF8",
        "Add-Type -AssemblyName System.Runtime.WindowsRuntime",
        "$asTask = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object { $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1' })[0]",
        "function Await($op, $t) { $m = $asTask.MakeGenericMethod($t); $task = $m.Invoke($null, @($op)); $task.Wait(-1) | Out-Null; $task.Result }",
        "$null = [Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager, Windows.Media.Control, ContentType = WindowsRuntime]",
        "$null = [Windows.Media.Control.GlobalSystemMediaTransportControlsSessionMediaProperties, Windows.Media.Control, ContentType = WindowsRuntime]",
        "$mgr = Await ([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager]::RequestAsync()) ([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager])",
        "while ($true) {",
        "  try {",
        "    $s = $mgr.GetCurrentSession()",
        "    if ($s) {",
        "      $p = Await ($s.TryGetMediaPropertiesAsync()) ([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionMediaProperties])",
        "      $tl = $s.GetTimelineProperties(); $pi = $s.GetPlaybackInfo()",
        "      $age = [int64]([DateTimeOffset]::UtcNow - $tl.LastUpdatedTime.ToUniversalTime()).TotalMilliseconds",
        "      $pos = [int64]$tl.Position.TotalMilliseconds",
        "      if ($pi.PlaybackStatus -eq 4 -and $age -gt 0 -and $age -lt 600000) { $pos += $age }",
        "      Write-Output ($p.Title + \"`t\" + $p.Artist + \"`t\" + $pos + \"`t\" + [int]$pi.PlaybackStatus)",
        "    } else { Write-Output \"`t`t0`t0\" }",
        "  } catch { Write-Output \"`t`t0`t0\" }",
        "  Start-Sleep -Milliseconds 600",
        "}");

    private static volatile Process proc;
    private static volatile boolean running = false;
    private static volatile String title = "", artist = "";
    private static volatile long posMs = 0, posAt = 0;
    private static volatile boolean playing = false;
    private static volatile long[] times = new long[0];
    private static volatile String[] lines = new String[0];
    private static volatile String state = ""; // "", "lädt", "keine Lyrics"
    private static String fetched = "";
    private static int idx = 0;

    public static void update(ToastyConfig cfg) {
        if (cfg.lyricsHud && !running) start();
        else if (!cfg.lyricsHud && running) stop();
    }

    private static void start() {
        if (!System.getProperty("os.name", "").toLowerCase().contains("win")) return;
        running = true;
        Thread t = new Thread(() -> {
            try {
                String enc = Base64.getEncoder().encodeToString(PS.getBytes(StandardCharsets.UTF_16LE));
                Process p = new ProcessBuilder("powershell.exe", "-NoProfile", "-NonInteractive", "-WindowStyle", "Hidden", "-EncodedCommand", enc)
                    .redirectErrorStream(true).start();
                proc = p;
                try (BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream(), StandardCharsets.UTF_8))) {
                    String ln;
                    while (running && (ln = r.readLine()) != null) parse(ln);
                }
            } catch (Exception ignored) {
            } finally { running = false; Process p = proc; if (p != null) p.destroyForcibly(); proc = null; }
        }, "toasty-lyrics");
        t.setDaemon(true);
        t.start();
    }

    private static void stop() {
        running = false;
        Process p = proc;
        if (p != null) p.destroyForcibly();
        proc = null;
        title = artist = ""; lines = new String[0]; times = new long[0]; state = ""; fetched = "";
    }

    private static void parse(String ln) {
        String[] f = ln.split("\t", -1);
        if (f.length < 4) return;
        try {
            title = f[0].trim(); artist = f[1].trim();
            posMs = Long.parseLong(f[2].trim()); posAt = System.currentTimeMillis();
            playing = f[3].trim().equals("4");
        } catch (NumberFormatException e) { return; }
        String key = artist + "|" + title;
        if (!title.isEmpty() && !key.equals(fetched)) { fetched = key; fetch(title, artist); }
    }

    private static void fetch(String t, String a) {
        state = "lädt"; lines = new String[0]; times = new long[0]; idx = 0;
        final String key = a + "|" + t;
        Thread th = new Thread(() -> {
            try {
                String clean = t.replaceAll("\\s*[\\(\\[].*?[\\)\\]]", "").replaceAll("\\s*-\\s*(Remaster|Live|Radio|Single|Version).*$", "").trim();
                String syn = get("https://lrclib.net/api/get?track_name=" + URLEncoder.encode(clean, StandardCharsets.UTF_8) + "&artist_name=" + URLEncoder.encode(a, StandardCharsets.UTF_8));
                String lrc = null;
                if (syn != null) lrc = syncedOf(JsonParser.parseString(syn));
                if (lrc == null) {
                    String s = get("https://lrclib.net/api/search?q=" + URLEncoder.encode(a + " " + clean, StandardCharsets.UTF_8));
                    if (s != null) {
                        JsonElement e = JsonParser.parseString(s);
                        if (e.isJsonArray()) for (JsonElement x : (JsonArray) e) { lrc = syncedOf(x); if (lrc != null) break; }
                    }
                }
                if (!key.equals(fetched)) return; // Song hat gewechselt
                if (lrc == null) { state = "keine Lyrics"; return; }
                List<Long> ts = new ArrayList<>(); List<String> ls = new ArrayList<>();
                for (String l : lrc.split("\n")) {
                    Matcher m = LRC.matcher(l.trim());
                    if (!m.matches()) continue;
                    long ms = Long.parseLong(m.group(1)) * 60000L + Long.parseLong(m.group(2)) * 1000L;
                    if (m.group(3) != null) { String fr = (m.group(3) + "00").substring(0, 3); ms += Long.parseLong(fr); }
                    ts.add(ms); ls.add(m.group(4).trim());
                }
                if (ls.isEmpty()) { state = "keine Lyrics"; return; }
                long[] ta = new long[ts.size()]; for (int i = 0; i < ta.length; i++) ta[i] = ts.get(i);
                times = ta; lines = ls.toArray(new String[0]); state = "";
            } catch (Exception e) { state = "keine Lyrics"; }
        }, "toasty-lyrics-fetch");
        th.setDaemon(true);
        th.start();
    }

    private static String syncedOf(JsonElement e) {
        if (!e.isJsonObject()) return null;
        JsonObject o = e.getAsJsonObject();
        JsonElement s = o.get("syncedLyrics");
        return s != null && !s.isJsonNull() && !s.getAsString().isBlank() ? s.getAsString() : null;
    }

    private static String get(String url) {
        try {
            HttpResponse<String> r = HTTP.send(HttpRequest.newBuilder(URI.create(url)).timeout(Duration.ofSeconds(8))
                .header("User-Agent", "ToastyClient (github.com/ventlukas-web/toasty-client)").GET().build(), HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
            return r.statusCode() == 200 ? r.body() : null;
        } catch (Exception e) { return null; }
    }

    // ---------- Anzeige (nur Text, kein I/O) ----------
    public static void render(DrawContext ctx, TextRenderer tr, MinecraftClient mc, ToastyConfig cfg) {
        if (!cfg.lyricsHud || title.isEmpty()) return;
        long pos = posMs + (playing ? System.currentTimeMillis() - posAt : 0);
        String[] ls = lines; long[] ts = times;
        String cur, next = "";
        if (ls.length == 0) { cur = state.isEmpty() ? "" : state; }
        else {
            if (idx >= ts.length || (idx > 0 && ts[idx] > pos)) idx = 0;
            while (idx + 1 < ts.length && ts[idx + 1] <= pos) idx++;
            cur = ts[idx] <= pos ? ls[idx] : "";
            if (cur.isBlank()) cur = "♪";
            if (idx + 1 < ls.length && ts[idx] <= pos) next = ls[idx + 1];
            else if (ts[0] > pos) next = ls[0];
        }
        String head = (artist.isEmpty() ? title : artist + " – " + title);
        int sw = mc.getWindow().getScaledWidth();
        int maxW = (int) (sw * 0.55f);
        head = tr.trimToWidth(head, maxW); cur = tr.trimToWidth(cur, maxW); next = tr.trimToWidth(next, maxW);
        int pad = 8;
        int w = Math.max(Math.max(tr.getWidth(head), tr.getWidth(cur)), Math.max(tr.getWidth(next), 120));
        int h = 14 + 12 + (next.isEmpty() ? 0 : 11) + 8;
        float[] pos0 = ToastyHud.place("lyrics", (sw - (w + pad * 2) * cfg.hudScale) / 2f, 6, (w + pad * 2) * cfg.hudScale, h * cfg.hudScale, mc);
        ctx.getMatrices().pushMatrix();
        ctx.getMatrices().translate(pos0[0], pos0[1]);
        ctx.getMatrices().scale(cfg.hudScale, cfg.hudScale);
        ToastyTheme.panel(ctx, 0, 0, w + pad * 2, h);
        ctx.drawTextWithShadow(tr, head, pad + (w - tr.getWidth(head)) / 2, 5, ToastyTheme.MUTED);
        ctx.drawTextWithShadow(tr, cur, pad + (w - tr.getWidth(cur)) / 2, 18, ToastyTheme.TEXT);
        if (!next.isEmpty()) ctx.drawTextWithShadow(tr, next, pad + (w - tr.getWidth(next)) / 2, 30, ToastyTheme.alpha(ToastyTheme.MUTED, 0xA0));
        ctx.getMatrices().popMatrix();
    }
}
