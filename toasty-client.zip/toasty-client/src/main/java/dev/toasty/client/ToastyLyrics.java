package dev.toasty.client;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Sky Lyrics: erkennt den laufenden Song (Windows: Medien-Steuerung z. B. Apple Music/Spotify; macOS: Music/Spotify) und laesst die
 * zeitlich passenden Lyrics im Himmel schweben. Lyrics kommen von lrclib.net.
 */
public final class ToastyLyrics {
    private record Line(double t, String text) {}

    private static volatile List<Line> lines = List.of();
    private static volatile String title = "", artist = "", status = "";
    private static volatile boolean playing = false;
    private static volatile double basePos = 0;
    private static volatile long baseAt = 0;
    private static String trackKey = "";
    private static final HttpClient HTTP = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(5)).build();
    private static final Pattern LRC = Pattern.compile("\\[(\\d+):(\\d+(?:\\.\\d+)?)]");

    private static final String OS = System.getProperty("os.name", "").toLowerCase();
    private static final boolean MAC = OS.contains("mac");
    private static final boolean WIN = OS.contains("win");

    private ToastyLyrics() {}

    public static void start() {
        if (!MAC && !WIN) return;
        ScheduledExecutorService ex = Executors.newSingleThreadScheduledExecutor(r -> {
            Thread t = new Thread(r, "toasty-lyrics");
            t.setDaemon(true);
            return t;
        });
        ex.scheduleWithFixedDelay(() -> { try { poll(); } catch (Throwable ignored) {} }, 2, 1, TimeUnit.SECONDS);
    }

    // ---------- Player abfragen ----------

    private static boolean isRunning(String proc) {
        try {
            Process p = new ProcessBuilder("pgrep", "-x", proc).redirectErrorStream(true).start();
            p.getInputStream().readAllBytes();
            return p.waitFor(2, TimeUnit.SECONDS) && p.exitValue() == 0;
        } catch (Exception e) { return false; }
    }

    private static String osa(String app) {
        try {
            Process p = new ProcessBuilder("osascript",
                "-e", "tell application \"" + app + "\"",
                "-e", "if player state is playing then",
                "-e", "return (name of current track) & \"|||\" & (artist of current track) & \"|||\" & (duration of current track) & \"|||\" & (player position)",
                "-e", "end if",
                "-e", "end tell").redirectErrorStream(true).start();
            String out;
            try (BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream(), StandardCharsets.UTF_8))) {
                out = r.readLine();
            }
            if (!p.waitFor(3, TimeUnit.SECONDS)) { p.destroyForcibly(); return ""; }
            return out == null ? "" : out.trim();
        } catch (Exception e) { return ""; }
    }

    private static double num(String s) { return Double.parseDouble(s.trim().replace(',', '.')); }

    private static void poll() {
        if (!ToastyConfig.get().skyLyrics) return;
        if (WIN) pollWindows(); else pollMac();
    }

    private static void pollMac() {
        String out = "";
        boolean spotify = false;
        if (isRunning("Music")) out = osa("Music");
        if (out.isBlank() && isRunning("Spotify")) { out = osa("Spotify"); spotify = true; }
        if (out.isBlank()) { playing = false; return; }
        String[] p = out.split("\\|\\|\\|");
        if (p.length < 4) { playing = false; return; }
        try {
            double dur = num(p[2]);
            if (spotify) dur /= 1000.0;
            applyTrack(p[0].trim(), p[1].trim(), dur, num(p[3]));
        } catch (Exception ignored) { playing = false; }
    }

    // ---------- Windows: System Media Transport Controls (Apple Music, Spotify, Browser ...) ----------

    private static final String WIN_SCRIPT = String.join("\n",
        "$ErrorActionPreference='Stop'",
        "[Console]::OutputEncoding=[System.Text.Encoding]::UTF8",
        "$ci=[cultureinfo]::InvariantCulture",
        "Add-Type -AssemblyName System.Runtime.WindowsRuntime",
        "$asTask=([System.WindowsRuntimeSystemExtensions].GetMethods()|?{$_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1'})[0]",
        "function Await($op,$t){$m=$asTask.MakeGenericMethod($t);$n=$m.Invoke($null,@($op));$n.Wait(-1)|Out-Null;$n.Result}",
        "[Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager,Windows.Media.Control,ContentType=WindowsRuntime]|Out-Null",
        "$mgr=Await([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager]::RequestAsync()) ([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager])",
        "$best=$null;$any=$null",
        "foreach($s in $mgr.GetSessions()){",
        "  if($s.GetPlaybackInfo().PlaybackStatus -eq 'Playing'){",
        "    if($any -eq $null){$any=$s}",
        "    if($s.SourceAppUserModelId -match 'Apple|Music|Spotify'){ if($best -eq $null){$best=$s} }",
        "  }",
        "}",
        "if($best -eq $null){$best=$any}",
        "if($best -eq $null){return}",
        "$props=Await($best.TryGetMediaPropertiesAsync()) ([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionMediaProperties])",
        "$tl=$best.GetTimelineProperties()",
        "$end=$tl.EndTime.TotalSeconds",
        "$pos=$tl.Position.TotalSeconds",
        "if($tl.LastUpdatedTime.Year -gt 2000){$pos+=([DateTimeOffset]::Now-$tl.LastUpdatedTime).TotalSeconds}",
        "if($end -gt 0 -and $pos -gt $end){$pos=$end}",
        "[Console]::Out.Write($props.Title+'|||'+$props.Artist+'|||'+$end.ToString($ci)+'|||'+$pos.ToString($ci))");

    private static String powershell(String script) {
        try {
            String enc = java.util.Base64.getEncoder().encodeToString(script.getBytes(StandardCharsets.UTF_16LE));
            Process p = new ProcessBuilder("powershell.exe", "-NoProfile", "-NonInteractive",
                "-ExecutionPolicy", "Bypass", "-EncodedCommand", enc).redirectErrorStream(true).start();
            String out;
            try (BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream(), StandardCharsets.UTF_8))) {
                out = r.readLine();
            }
            if (!p.waitFor(6, TimeUnit.SECONDS)) { p.destroyForcibly(); return ""; }
            return out == null ? "" : out.trim();
        } catch (Exception e) { return ""; }
    }

    private static void pollWindows() {
        String out = powershell(WIN_SCRIPT);
        if (out.isBlank()) { playing = false; return; }
        String[] p = out.split("\\|\\|\\|");
        if (p.length < 4 || p[0].isBlank()) { playing = false; return; }
        try {
            String artist = p[1].trim();
            int dash = artist.indexOf(" — ");   // Apple Music (Windows) liefert "Kuenstler — Album"
            if (dash > 0) artist = artist.substring(0, dash);
            applyTrack(p[0].trim(), artist, num(p[2]), num(p[3]));
        } catch (Exception ignored) { playing = false; }
    }

    // ---------- gemeinsam ----------

    private static void applyTrack(String t, String a, double dur, double pos) {
        basePos = pos; baseAt = System.currentTimeMillis(); playing = true;
        String key = t + "|" + a;
        if (!key.equals(trackKey)) {
            trackKey = key; title = t; artist = a; lines = List.of(); status = "Lade Lyrics …";
            final String k = key; final double d = dur;
            new Thread(() -> fetch(k, t, a, d), "toasty-lyrics-fetch").start();
        }
    }

    // ---------- Lyrics laden (lrclib.net) ----------

    private static String enc(String s) { return URLEncoder.encode(s, StandardCharsets.UTF_8); }

    private static String get(String url) throws Exception {
        HttpRequest req = HttpRequest.newBuilder(URI.create(url))
            .header("User-Agent", "ToastyClient/1.0").timeout(Duration.ofSeconds(8)).GET().build();
        HttpResponse<String> r = HTTP.send(req, HttpResponse.BodyHandlers.ofString());
        return r.statusCode() == 200 ? r.body() : null;
    }

    private static void fetch(String key, String t, String a, double dur) {
        try {
            String synced = null;
            String body = get("https://lrclib.net/api/get?track_name=" + enc(t) + "&artist_name=" + enc(a)
                + (dur > 0 ? "&duration=" + Math.round(dur) : ""));
            if (body != null) {
                JsonObject o = JsonParser.parseString(body).getAsJsonObject();
                JsonElement e = o.get("syncedLyrics");
                if (e != null && !e.isJsonNull()) synced = e.getAsString();
            }
            if (synced == null) {
                String sb = get("https://lrclib.net/api/search?q=" + enc(a + " " + t));
                if (sb != null) {
                    JsonArray arr = JsonParser.parseString(sb).getAsJsonArray();
                    for (JsonElement el : arr) {
                        JsonElement e = el.getAsJsonObject().get("syncedLyrics");
                        if (e != null && !e.isJsonNull() && !e.getAsString().isBlank()) { synced = e.getAsString(); break; }
                    }
                }
            }
            if (!key.equals(trackKey)) return; // Song wurde inzwischen gewechselt
            if (synced == null) { status = "Keine synchronen Lyrics gefunden"; return; }
            List<Line> res = parseLrc(synced);
            if (res.isEmpty()) { status = "Keine synchronen Lyrics gefunden"; return; }
            lines = res; status = "";
        } catch (Exception e) {
            if (key.equals(trackKey)) status = "Lyrics konnten nicht geladen werden";
        }
    }

    private static List<Line> parseLrc(String lrc) {
        List<Line> res = new ArrayList<>();
        for (String raw : lrc.split("\\R")) {
            Matcher m = LRC.matcher(raw);
            List<Double> times = new ArrayList<>();
            int end = 0;
            while (m.find()) {
                times.add(Integer.parseInt(m.group(1)) * 60 + Double.parseDouble(m.group(2)));
                end = m.end();
            }
            if (times.isEmpty()) continue;
            String text = raw.substring(end).trim();
            for (double t : times) res.add(new Line(t, text));
        }
        res.sort((x, y) -> Double.compare(x.t(), y.t()));
        return res;
    }

    // ---------- Anzeige: Text schwebt fest im Himmel ----------
    // Der Text ist an eine Himmelsrichtung gebunden (Blickwinkel, nicht Bildschirmposition): er wird per
    // Perspektiv-Projektion auf den Bildschirm gerechnet, bleibt beim Umschauen im Himmel stehen und
    // driftet nur langsam hinter deiner Blickrichtung her. Dazu kommt leichtes Schweben (Auf/Ab, Schwanken).

    private static float anchorYaw;
    private static boolean anchored = false;
    private static long lastNs = System.nanoTime();

    private static float wrap(float d) {
        d %= 360f;
        if (d > 180f) d -= 360f;
        if (d < -180f) d += 360f;
        return d;
    }

    /** Richtung (Yaw/Pitch in Grad, Minecraft-Konvention) -> Bildschirmposition oder null, wenn hinter der Kamera. */
    private static float[] project(float yawA, float pitchA, float camYaw, float camPitch, float fovV, int w, int h) {
        double ya = Math.toRadians(yawA), pa = Math.toRadians(pitchA);
        double tx = -Math.sin(ya) * Math.cos(pa), ty = -Math.sin(pa), tz = Math.cos(ya) * Math.cos(pa);
        double cy = Math.toRadians(camYaw), cp = Math.toRadians(camPitch);
        double fx = -Math.sin(cy) * Math.cos(cp), fy = -Math.sin(cp), fz = Math.cos(cy) * Math.cos(cp);
        double rx = -Math.cos(cy), ry = 0, rz = -Math.sin(cy);
        double ux = ry * fz - rz * fy, uy = rz * fx - rx * fz, uz = rx * fy - ry * fx;
        double xc = tx * rx + ty * ry + tz * rz;
        double yc = tx * ux + ty * uy + tz * uz;
        double zc = tx * fx + ty * fy + tz * fz;
        if (zc < 0.08) return null;
        double th = Math.tan(Math.toRadians(fovV) / 2.0);
        double ndcX = xc / (zc * th * ((double) w / h));
        double ndcY = yc / (zc * th);
        return new float[]{(float) (w / 2.0 * (1 + ndcX)), (float) (h / 2.0 * (1 - ndcY))};
    }

    private static void centered(DrawContext ctx, TextRenderer tr, String text, int cx, int y, float scale, int w, int alpha, boolean gradient, int color) {
        if (alpha < 8 || text.isEmpty()) return;
        while (scale > 0.8f && tr.getWidth(text) * scale > w * 0.9f) scale -= 0.1f;
        ctx.getMatrices().pushMatrix();
        ctx.getMatrices().translate(cx, y);
        ctx.getMatrices().scale(scale, scale);
        int tw = tr.getWidth(text);
        if (!gradient) {
            ctx.drawTextWithShadow(tr, text, -tw / 2, 0, ToastyTheme.alpha(color, alpha));
        } else {
            int x = -tw / 2, n = Math.max(1, text.length() - 1);
            for (int i = 0; i < text.length(); i++) {
                String ch = String.valueOf(text.charAt(i));
                int col = ToastyTheme.lerp(ToastyTheme.PURPLE, ToastyTheme.BLUE, (float) i / n);
                // weicher Glow: zwei versetzte, schwache Kopien hinter dem Buchstaben
                ctx.drawText(tr, ch, x + 1, 1, ToastyTheme.alpha(col, alpha / 5), false);
                ctx.drawText(tr, ch, x - 1, -1, ToastyTheme.alpha(col, alpha / 5), false);
                ctx.drawTextWithShadow(tr, ch, x, 0, ToastyTheme.alpha(col, alpha));
                x += tr.getWidth(ch);
            }
        }
        ctx.getMatrices().popMatrix();
    }

    public static void render(DrawContext ctx, TextRenderer tr, MinecraftClient mc, ToastyConfig cfg) {
        if (!cfg.skyLyrics || title.isEmpty() || mc.player == null) return;
        var cam = mc.gameRenderer.getCamera();
        float camYaw = cam.getYaw(), camPitch = cam.getPitch();

        long ns = System.nanoTime();
        float dt = Math.min(0.1f, (ns - lastNs) / 1e9f);
        lastNs = ns;
        if (!anchored) { anchorYaw = camYaw; anchored = true; }
        // traege Nachfuehrung -> wirkt wie schwebend
        anchorYaw += wrap(camYaw - anchorYaw) * (1f - (float) Math.exp(-dt * 1.1f));

        double t = System.currentTimeMillis() / 1000.0;
        float sway = (float) Math.sin(t * 0.45) * 1.2f;       // Grad
        float bob = (float) Math.sin(t * 0.9) * 0.8f;         // Grad
        int w = mc.getWindow().getScaledWidth(), h = mc.getWindow().getScaledHeight();
        float fov = mc.options.getFov().getValue();
        float[] p = project(anchorYaw + sway, -cfg.lyricsHeight + bob, camYaw, camPitch, fov, w, h);
        if (p == null) return;
        int cx = Math.round(p[0]), sy = Math.round(p[1]);

        float scale = cfg.lyricsScale;
        int curTop = sy - (int) (4 * scale);

        String head = "♪ " + title + (artist.isEmpty() ? "" : " – " + artist) + (playing ? "" : "  (Pause)");
        centered(ctx, tr, head, cx, curTop - 28, 1f, w, 190, false, ToastyTheme.MUTED);

        List<Line> ls = lines;
        if (ls.isEmpty()) {
            centered(ctx, tr, status, cx, curTop, 1.2f, w, 200, false, ToastyTheme.TEXT);
            return;
        }
        double pos = basePos + (playing ? (System.currentTimeMillis() - baseAt) / 1000.0 : 0);
        int idx = -1;
        for (int i = 0; i < ls.size(); i++) { if (ls.get(i).t() <= pos + 0.15) idx = i; else break; }

        if (idx > 0) centered(ctx, tr, ls.get(idx - 1).text(), cx, curTop - 14, 1f, w, 110, false, ToastyTheme.TEXT);
        if (idx >= 0) {
            Line cur = ls.get(idx);
            float k = (float) Math.max(0, Math.min(1, (pos - cur.t()) / 0.35));
            String text = cur.text().isEmpty() ? "♪" : cur.text();
            centered(ctx, tr, text, cx, curTop + (int) ((1 - k) * 8), scale, w, (int) (255 * k), true, 0);
        }
        if (idx + 1 < ls.size()) {
            centered(ctx, tr, ls.get(idx + 1).text(), cx, curTop + (int) (8 * scale) + 6, 1f, w, 140, false, ToastyTheme.TEXT);
        }
    }
}
