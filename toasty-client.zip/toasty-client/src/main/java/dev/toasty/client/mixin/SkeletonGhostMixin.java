package dev.toasty.client.mixin;

import dev.toasty.client.ToastyConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.client.render.entity.state.LivingEntityRenderState;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyConstant;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Skelett-Ansicht an: andere Spieler werden nur noch ganz leicht (Vanilla-"Geist"-Transparenz) gezeichnet. */
@Mixin(LivingEntityRenderer.class)
public abstract class SkeletonGhostMixin {
    @Inject(method = "updateRenderState(Lnet/minecraft/entity/LivingEntity;Lnet/minecraft/client/render/entity/state/LivingEntityRenderState;F)V", at = @At("RETURN"), require = 0)
    private void toasty$ghost(LivingEntity entity, LivingEntityRenderState state, float tickDelta, CallbackInfo ci) {
        try {
            ToastyConfig cf = ToastyConfig.get();
            if (!(cf.skeleton || cf.glass) || !(entity instanceof PlayerEntity)) return;
            if (entity == MinecraftClient.getInstance().player && !(cf.glass && !MinecraftClient.getInstance().options.getPerspective().isFirstPerson())) return;
            if (entity.isInvisible()) return;
            state.invisible = true;            // Vanilla zeichnet dann halbtransparent...
            state.invisibleToPlayer = false;   // ...statt gar nicht
        } catch (Throwable ignored) {}
    }

    /** Vanilla zeichnet "Geister" mit 15 % Deckkraft (0x26FFFFFF). Hier wird das glasig statt fast unsichtbar: 35 / 55 / 75 %. */
    @ModifyConstant(method = "render", constant = @Constant(intValue = 654311423), require = 0)
    private int toasty$glassAlpha(int original) {
        try {
            ToastyConfig cf = ToastyConfig.get();
            if (!(cf.skeleton || cf.glass)) return original;
            int a = cf.glassOpacity <= 1 ? 0x59 : cf.glassOpacity >= 3 ? 0xBF : 0x8C;
            return (a << 24) | 0xFFFFFF;
        } catch (Throwable t) { return original; }
    }
}
