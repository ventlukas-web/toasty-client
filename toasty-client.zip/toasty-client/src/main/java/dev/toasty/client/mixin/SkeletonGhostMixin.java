package dev.toasty.client.mixin;

import dev.toasty.client.ToastyConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.client.render.entity.state.LivingEntityRenderState;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Skelett-Ansicht an: andere Spieler werden nur noch ganz leicht (Vanilla-"Geist"-Transparenz) gezeichnet. */
@Mixin(LivingEntityRenderer.class)
public abstract class SkeletonGhostMixin {
    @Inject(method = "updateRenderState(Lnet/minecraft/entity/LivingEntity;Lnet/minecraft/client/render/entity/state/LivingEntityRenderState;F)V", at = @At("RETURN"), require = 0)
    private void toasty$ghost(LivingEntity entity, LivingEntityRenderState state, float tickDelta, CallbackInfo ci) {
        try {
            ToastyConfig cf = ToastyConfig.get();
            if (!(cf.skeleton || cf.glass) || !(entity instanceof PlayerEntity)) return;
            if (entity == MinecraftClient.getInstance().player && !(cf.glass && !MinecraftClient.getInstance().options.getPerspective().isFirstPerson())) return;
            if (entity.isInvisible()) return;
            state.invisible = true;            // Vanilla zeichnet dann halbtransparent...
            state.invisibleToPlayer = false;   // ...statt gar nicht
        } catch (Throwable ignored) {}
    }
}
