package dev.toasty.client;

import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.DisconnectedScreen;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.gui.screen.multiplayer.ConnectScreen;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.network.ServerAddress;
import net.minecraft.client.network.ServerInfo;
import net.minecraft.text.Text;

/** Auto-Reconnect: nach einem Verbindungsabbruch (Disconnect-Bildschirm) verbindet sich der Client nach einem Countdown erneut. */
public final class ToastyReconnect {
    private static final int MAX_TRIES = 10;
    private static String lastName, lastIp;
    private static int tries = 0;
    private static boolean cancelled = false;

    private ToastyReconnect() {}

    public static void register() {
        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> {
            ServerInfo si = client.getCurrentServerEntry();
            if (si != null) { lastName = si.name; lastIp = si.address; }
            tries = 0; cancelled = false;
        });

        ScreenEvents.AFTER_INIT.register((client, screen, w, h) -> {
            if (!(screen instanceof DisconnectedScreen)) return;
            ToastyConfig cfg = ToastyConfig.get();
            if (!cfg.autoReconnect || lastIp == null || cancelled) return;
            if (tries >= MAX_TRIES) return;
            final long[] target = {System.currentTimeMillis() + Math.max(2, cfg.reconnectSec) * 1000L};
            final boolean[] fired = {false};
            ButtonWidget btn = ButtonWidget.builder(Text.literal("Auto-Reconnect …"), b -> {
                cancelled = true;
                b.setMessage(Text.literal("Auto-Reconnect abgebrochen"));
                b.active = false;
            }).dimensions(w / 2 - 100, h - 34, 200, 20).build();
            Screens.getButtons(screen).add(btn);
            ScreenEvents.afterRender(screen).register((s, ctx, mx, my, delta) -> {
                if (cancelled || fired[0]) return;
                long left = target[0] - System.currentTimeMillis();
                if (left > 0) {
                    btn.setMessage(Text.literal("Reconnect in " + (left / 1000 + 1) + " s · Klick = abbrechen (" + (tries + 1) + "/" + MAX_TRIES + ")"));
                    return;
                }
                fired[0] = true;
                tries++;
                client.execute(() -> reconnect(client));
            });
        });
    }

    private static void reconnect(MinecraftClient mc) {
        if (lastIp == null) return;
        ServerAddress addr = ServerAddress.parse(lastIp);
        ServerInfo info = new ServerInfo(lastName == null ? "Server" : lastName, lastIp, ServerInfo.ServerType.OTHER);
        ConnectScreen.connect(new MultiplayerScreen(new TitleScreen()), mc, addr, info, false, null);
    }
}
