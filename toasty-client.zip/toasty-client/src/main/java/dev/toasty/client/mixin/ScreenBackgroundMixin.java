package dev.toasty.client.mixin;

import dev.toasty.client.ToastyConfig;
import dev.toasty.client.ToastyScreen;
import dev.toasty.client.ToastyTheme;
import dev.toasty.client.ToastyTitle;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Vanilla-Menuehintergrund im Wolken-Design: Verlauf Lila -> Himmelblau statt Dirt/Blur. */
@Mixin(Screen.class)
public abstract class ScreenBackgroundMixin {
    @Inject(method = "renderBackground", at = @At("HEAD"), cancellable = true)
    private void toasty$bg(DrawContext ctx, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        try {
            if (!ToastyConfig.get().niceButtons) return;
            Object self = this;
            if (self instanceof ToastyScreen || self instanceof TitleScreen || self instanceof HandledScreen<?>) return;
            Screen s = (Screen) self;
            boolean inWorld = MinecraftClient.getInstance().world != null;
            int ga = inWorld ? 0x70 : 0xFF;
            ctx.fillGradient(0, 0, s.width, s.height,
                ToastyTheme.alpha(ToastyTheme.lerp(0xFF2A1B5E, ToastyTheme.PURPLE, 0.12f), ga),
                ToastyTheme.alpha(ToastyTheme.lerp(0xFF5B8DE8, ToastyTheme.BLUE, 0.15f), ga));
            ci.cancel();
        } catch (Throwable t) {
            dev.toasty.client.ToastyProf.mixinErrors++;
            dev.toasty.client.ToastyProf.mixinLastError = String.valueOf(t);
        }
    }
}
