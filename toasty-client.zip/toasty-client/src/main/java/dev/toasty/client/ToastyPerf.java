package dev.toasty.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.ParticlesMode;

/** FPS-Boost ueber Spieloptionen (kein Ersatz fuer Sodium/Optifine, aber spuerbar). */
public final class ToastyPerf {
    private ToastyPerf() {}

    public static void apply() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc == null || mc.options == null) return;
        GameOptions o = mc.options;
        ToastyConfig c = ToastyConfig.get();

        if (c.perfParticles) {
            if (c.origParticles == null) c.origParticles = o.getParticles().getValue().name();
            o.getParticles().setValue(ParticlesMode.MINIMAL);
        } else if (c.origParticles != null) {
            try { o.getParticles().setValue(ParticlesMode.valueOf(c.origParticles)); } catch (Exception ignored) {}
            c.origParticles = null;
        }

        if (c.perfShadows) {
            if (c.origShadows == null) c.origShadows = o.getEntityShadows().getValue();
            o.getEntityShadows().setValue(false);
        } else if (c.origShadows != null) {
            o.getEntityShadows().setValue(c.origShadows);
            c.origShadows = null;
        }

        if (c.perfDistance) {
            if (c.origView == null) c.origView = o.getViewDistance().getValue();
            if (c.origSim == null) c.origSim = o.getSimulationDistance().getValue();
            if (c.origScaling == null) c.origScaling = o.getEntityDistanceScaling().getValue();
            o.getViewDistance().setValue(Math.min(c.origView, 8));
            o.getSimulationDistance().setValue(Math.min(c.origSim, 6));
            o.getEntityDistanceScaling().setValue(0.5);
        } else if (c.origView != null) {
            o.getViewDistance().setValue(c.origView);
            if (c.origSim != null) o.getSimulationDistance().setValue(c.origSim);
            if (c.origScaling != null) o.getEntityDistanceScaling().setValue(c.origScaling);
            c.origView = null; c.origSim = null; c.origScaling = null;
        }
        c.save();
        o.write();
    }
}
