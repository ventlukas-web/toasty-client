package dev.toasty.client;

import net.minecraft.client.MinecraftClient;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;

/** Auktion (Gebote = erkannte Zahlungen) und Giveaway (Teilnahme per Chat-Stichwort). */
public final class ToastyEvents {
    private ToastyEvents() {}

    // Auktion
    public static boolean aucOn;
    private static String aucItem = "";
    private static long aucEnd, aucBest;
    private static String aucBestName;
    private static final Map<String, Long> bids = new LinkedHashMap<>();

    // Giveaway
    public static boolean gwOn;
    private static String gwPrize = "";
    private static long gwEnd;
    private static final LinkedHashSet<String> entrants = new LinkedHashSet<>();
    private static final Random RND = new Random();

    private static void say(String s) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;
        if (ToastyConfig.get().auctionAnnounce && mc.player.networkHandler != null) mc.player.networkHandler.sendChatMessage(s);
        else ToastyGamble.chat(s);
    }

    // ---------- Auktion ----------

    public static void startAuction(String item, long startBid, int sec) {
        aucOn = true; aucItem = item; aucBest = startBid; aucBestName = null; bids.clear();
        aucEnd = System.currentTimeMillis() + sec * 1000L;
        say("AUKTION: " + item + " | Startgebot " + ToastyStats.fmt(startBid) + " | " + sec + "s | Gebot = /pay an mich");
        ToastyNotify.push("Auktion", item + " gestartet", ToastyTheme.PURPLE);
    }

    /** @return true, wenn die Zahlung als Gebot gewertet wurde (dann kein Gamble-Einsatz). */
    public static boolean onPayment(String player, long amount) {
        if (!aucOn) return false;
        long total = bids.merge(player, amount, Long::sum);
        if (total > aucBest) {
            aucBest = total; aucBestName = player;
            say("Neues Höchstgebot: " + ToastyStats.fmt(total) + " von " + player);
        } else {
            ToastyGamble.chat(player + " hat " + ToastyStats.fmt(total) + " geboten – zu niedrig (Höchstgebot " + ToastyStats.fmt(aucBest) + ").");
        }
        return true;
    }

    public static void endAuction(boolean cancel) {
        if (!aucOn) { ToastyGamble.chat("Keine Auktion aktiv."); return; }
        aucOn = false;
        if (cancel) { ToastyGamble.chat("Auktion abgebrochen. Alle Gebote zurückzahlen!"); return; }
        if (aucBestName == null) { say("Auktion beendet: " + aucItem + " – keine Gebote."); return; }
        say("Auktion beendet: " + aucItem + " geht an " + aucBestName + " für " + ToastyStats.fmt(aucBest) + "!");
        StringBuilder sb = new StringBuilder();
        for (var e : bids.entrySet()) if (!e.getKey().equals(aucBestName)) sb.append(e.getKey()).append(' ').append(ToastyStats.fmt(e.getValue())).append("  ");
        if (sb.length() > 0) ToastyGamble.chat("Zurückzahlen: " + sb.toString().trim());
        ToastyNotify.push("Auktion", aucBestName + " gewinnt (" + ToastyStats.fmt(aucBest) + ")", ToastyTheme.GOOD);
    }

    // ---------- Giveaway ----------

    public static void startGiveaway(int sec, String prize) {
        gwOn = true; gwPrize = prize; entrants.clear();
        gwEnd = System.currentTimeMillis() + sec * 1000L;
        say("GIVEAWAY: " + prize + " | Schreib \"" + ToastyConfig.get().giveawayKeyword + "\" in den Chat | " + sec + "s");
        ToastyNotify.push("Giveaway", prize, ToastyTheme.BLUE);
    }

    public static void drawWinner(boolean announce) {
        if (entrants.isEmpty()) { gwOn = false; say("Giveaway beendet – keine Teilnehmer."); return; }
        List<String> l = new ArrayList<>(entrants);
        String w = l.get(RND.nextInt(l.size()));
        gwOn = false;
        say("Giveaway-Gewinner: " + w + " (" + gwPrize + ")! " + l.size() + " Teilnehmer.");
        ToastyNotify.push("Giveaway", w + " gewinnt!", ToastyTheme.GOOD);
    }

    public static void cancelGiveaway() { gwOn = false; ToastyGamble.chat("Giveaway abgebrochen."); }

    /** Chatzeile pruefen: enthaelt sie ein Spieler-Name gefolgt vom Stichwort? */
    public static void onChatLine(String text) {
        if (!gwOn) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.getNetworkHandler() == null) return;
        String kw = ToastyConfig.get().giveawayKeyword.toLowerCase().trim();
        if (kw.isEmpty()) return;
        String low = text.toLowerCase();
        for (var e : mc.getNetworkHandler().getPlayerList()) {
            String n = e.getProfile().name();
            int i = low.indexOf(n.toLowerCase());
            if (i < 0) continue;
            int k = low.indexOf(kw, i + n.length());
            if (k >= 0) { if (entrants.add(n)) ToastyNotify.push("Giveaway", n + " nimmt teil (" + entrants.size() + ")", ToastyTheme.BLUE); return; }
        }
    }

    public static void tick() {
        ToastyStats.checkWait();
        ToastyPanels.armorCheck();
        long now = System.currentTimeMillis();
        if (aucOn && now >= aucEnd) endAuction(false);
        if (gwOn && now >= gwEnd) drawWinner(true);
    }

    /** Zeilen fuer das HUD: {links, rechts}. */
    public static List<String[]> rows() {
        List<String[]> r = new ArrayList<>();
        long now = System.currentTimeMillis();
        if (aucOn) {
            r.add(new String[]{"Auktion: " + aucItem, Math.max(0, (aucEnd - now) / 1000) + "s"});
            r.add(new String[]{aucBestName == null ? "Startgebot" : aucBestName, ToastyStats.fmt(aucBest)});
        }
        if (gwOn) {
            r.add(new String[]{"Giveaway: " + gwPrize, Math.max(0, (gwEnd - now) / 1000) + "s"});
            r.add(new String[]{"Teilnehmer", String.valueOf(entrants.size())});
        }
        return r;
    }
}
