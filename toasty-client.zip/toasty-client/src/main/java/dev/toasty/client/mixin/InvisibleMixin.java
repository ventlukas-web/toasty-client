package dev.toasty.client.mixin;

import dev.toasty.client.ToastyConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Andere Spieler werden nie unsichtbar/durchsichtig gerendert (nur auf dem Client, fail-soft). */
@Mixin(Entity.class)
public abstract class InvisibleMixin {
    @Inject(method = "isInvisible", at = @At("RETURN"), cancellable = true, require = 0)
    private void toasty$visible(CallbackInfoReturnable<Boolean> cir) {
        try {
            if (cir.getReturnValueZ() && (Object) this instanceof PlayerEntity p && p.getEntityWorld().isClient() && ToastyConfig.get().noInvisible
                && MinecraftClient.getInstance().player != null) cir.setReturnValue(false);
        } catch (Throwable ignored) {}
    }
}
