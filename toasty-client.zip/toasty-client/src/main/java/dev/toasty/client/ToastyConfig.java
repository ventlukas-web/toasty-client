package dev.toasty.client;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;

public class ToastyConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("toastyclient.json");
    private static ToastyConfig instance;

    // Anzeige
    public boolean hud = true;
    public boolean sound = true;
    public boolean effects = true;
    public boolean confetti = true;
    public boolean watermark = true;
    public boolean titleAnimation = true;
    public boolean skyLyrics = false;
    public float lyricsScale = 2.5f;
    /** Hoehe ueber dem Horizont in Grad. */
    public float lyricsHeight = 26f;

    // Sell-Makro
    public String sellCommand = "/sell";
    /** Item-IDs (z. B. "minecraft:wheat"), die ins Sell-Menue geschoben werden. */
    public java.util.List<String> sellItems = new java.util.ArrayList<>();
    /** Pause zwischen den Shift-Klicks in Ticks (20 Ticks = 1 Sekunde). */
    public int sellClickDelay = 2;
    /** Optional: Sell-Menue nur erkennen, wenn der Titel diesen Text enthaelt. */
    public String sellTitleFilter = "";
    public boolean sellAuto = false;
    public int sellIntervalSec = 10;
    public boolean showFps = false;
    public boolean keystrokes = true;
    public boolean coords = true;
    public boolean ping = false;
    public boolean speed = false;
    public boolean clock = false;
    public boolean moduleList = true;
    public float hudScale = 1.0f;

    // Design
    public String color1 = "#A855F7";
    public String color2 = "#7DD3FC";
    public int bgOpacity = 208;

    // Gamble
    public long minBet = 0;
    public long maxBet = Long.MAX_VALUE;
    public double winMultiplier = 2.0;
    /** WindSMP: "You received $1.5k from Name". Benannte Gruppen: player, amount, suffix. */
    public String pattern = "^You received \\$(?<amount>[0-9][0-9.,]*)\\s*(?<suffix>[KkMmBbTt]?) from (?<player>\\.?[A-Za-z0-9_]{1,16})\\.?$";

    // Performance (Einstellungen werden gemerkt, damit man sie zurueckstellen kann)
    public boolean perfParticles = false;
    public boolean perfShadows = false;
    public boolean perfDistance = false;
    public String origParticles = null;
    public Boolean origShadows = null;
    public Integer origView = null;
    public Integer origSim = null;
    public Double origScaling = null;

    public static ToastyConfig get() {
        if (instance == null) {
            try {
                if (Files.exists(FILE)) instance = GSON.fromJson(Files.readString(FILE), ToastyConfig.class);
            } catch (Exception ignored) {}
            if (instance == null) { instance = new ToastyConfig(); instance.save(); }
        }
        return instance;
    }

    public void save() {
        try { Files.writeString(FILE, GSON.toJson(this)); } catch (Exception ignored) {}
    }
}
