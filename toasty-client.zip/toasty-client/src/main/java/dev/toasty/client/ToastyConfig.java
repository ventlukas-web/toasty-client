package dev.toasty.client;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;

public class ToastyConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("toastyclient.json");
    private static ToastyConfig instance;

    // Anzeige
    public boolean hud = true;
    public boolean sound = true;
    public boolean effects = true;
    public boolean confetti = true;
    public boolean watermark = true;
    public boolean titleAnimation = false;
    /** Trailer mit Musik beim Spielstart (einmal pro Start), ueberspringbar. */
    public boolean introTrailer = true;
    /** Deckkraft der Buttons (0-255), leicht durchsichtig. */
    public int buttonAlpha = 200;
    /** Grundfarbe der Menue-Hintergruende (#RRGGBB), gesetzt durch Themes */
    public String themeBase = "#0A0614";
    // Inventar-/Button-Design sind immer an (kein Schalter mehr)
    public boolean niceInventory = false;
    public boolean invOffDone = false;
    /** GUI-Skalierung fuer Inventare: 0 = aus (normale Skalierung), 1-6 = fest */
    public int invGuiScale = 2;
    public boolean niceButtons = true;
    /** Startbildschirm: Theme-Verlauf + grosser Toast rechts (ohne Animationen). */
    public boolean titleToast = true;
    public int cfgVersion = 0;

    // Sell-Makro
    public String sellCommand = "/sell";
    /** Item-IDs (z. B. "minecraft:wheat"), die ins Sell-Menue geschoben werden. */
    public java.util.List<String> sellItems = new java.util.ArrayList<>();
    /** Pause zwischen den Shift-Klicks in Ticks (20 Ticks = 1 Sekunde). */
    public int sellClickDelay = 2;
    /** Optional: Sell-Menue nur erkennen, wenn der Titel diesen Text enthaelt. */
    public String sellTitleFilter = "";
    public boolean sellAuto = false;
    public int sellIntervalSec = 10;
    /** Auto-Intervall in Millisekunden (ab 100 ms). */
    public int sellIntervalMs = 10000;
    /** Shift gehalten = ganzes Inventar auf einmal ins Sell-Menue. */
    public boolean sellShiftAll = true;
    /** Immer das ganze Inventar per Shift-Klick ins Sell-Menü schieben (ohne Shift halten). */
    public boolean sellAlwaysAll = true;
    public boolean showFps = false;
    public boolean keystrokes = true;
    public boolean coords = true;
    public boolean ping = false;
    public boolean speed = false;
    public boolean clock = false;
    public boolean moduleList = true;
    public float hudScale = 1.0f;
    /** Verschobene HUD-Positionen: id -> {x, y} als Bruchteil der Bildschirmgroesse (0..1). */
    public java.util.Map<String, float[]> hudPos = new java.util.HashMap<>();

    // Neue Module
    public boolean payHud = true;
    /** Ansage, wenn eine Zahlung so viele Sekunden wartet (0 = aus), wiederholt sich im selben Abstand. */
    public int waitWarnSec = 30;
    public boolean notesHud = true;
    // Wegpunkte + Tasten-Snapshot fuer Profile
    public static class Wp { public String name = "", dim = ""; public int x, y, z; }
    public boolean wpOn = true;
    public java.util.List<Wp> waypoints = new java.util.ArrayList<>();
    public java.util.Map<String, String> keys = new java.util.HashMap<>();
    // Scoreboard (rechte Seite)
    public boolean sbCustom = false, sbNumbers = false, sbBorderOn = true;
    /** Scoreboard nutzt die Farben aus dem Design-Tab (Farbe 1/2). */
    public boolean sbTheme = true;
    public int sbRadius = 6, sbAlpha = 170;
    public float sbScale = 1.0f;
    public String sbBg = "#0B0618", sbBorder = "#A855F7", sbText = "#FFFFFF";
    // Streamer-Modus
    public boolean streamer = false, streamerHideXyz = true;
    public String streamerName = "Toasty";
    public boolean customHud = false;
    public String customTitle = "Mein HUD";
    public java.util.List<String> customLines = new java.util.ArrayList<>(java.util.List.of("XYZ: {x} {y} {z}", "FPS: {fps}", "Profit: {profit}"));
    public boolean comboHud = false, memHud = false, vitalsHud = false;
    public boolean lyricsHud = false;
    /** Sky Lyrics wie bei FWM: "sky" = im Himmel, "front" = vor dir, "block" = an einer festen Stelle, "hud" = alter Kasten oben */
    public String lyricsMode = "sky";
    public float lyricsSize = 1.0f;
    public boolean lyricsNext = true;
    /** Lyrics so viele ms früher zeigen (gleicht Anzeige-Verzögerung aus), negativ = später */
    public int lyricsOffsetMs = 250;
    public double lyricsBX, lyricsBY = -1000, lyricsBZ;
    /** Sky-Lyrics-Schrift: "clean" (Poppins), "bold" (Poppins Bold), "vanilla" (Minecraft) */
    public String lyricsFont = "clean";
    /** Farben: aktuelle Zeile, nächste Zeile (Kopfzeile wird daraus abgeleitet) */
    public String lyricsColor = "#F3E6FF", lyricsColor2 = "#B89CFF";
    /** Musik: "spotify" oder "system" (Apple Music und andere Player über Windows-Medientasten) */
    public String musicSource = "spotify";
    public String spotifyClientId = "", spotifyRefresh = "";
    public boolean topHud = false, graphHud = false;
    /** Pause zwischen automatischen /pay-Auszahlungen in ms (0 = sofort). */
    public int payDelayMs = 0;
    /** Warnung, wenn der Session-Verlust des Hauses diesen Betrag erreicht (0 = aus). */
    public long lossLimit = 0;
    public boolean compassHud = false, sellHud = false, armorWarn = true;
    public int armorWarnPct = 10;
    public boolean armorHud = false, potionHud = false, sessionHud = false, autoSprint = false;
    public java.util.List<String> notes = new java.util.ArrayList<>();
    public boolean notify = true;
    public boolean fullbright = false;
    public boolean itemGlow = false;
    public String glowItems = ""; // Item-Highlight-Filter: IDs/Namen, Komma getrennt (leer = alle Items)
    public boolean blockHighlight = false;
    /** Kein Nebel (Welt, Wasser, Lava) */
    public boolean noFog = false;
    /** Eigenes Crosshair */
    public boolean chOn = false, chDot = true, chOutline = true;
    public int chStyle = 1, chLen = 6, chGap = 3, chThick = 1, chColorIdx = 1;
    public String chHex = "";
    public String[] chSlots = {"", "", ""};
    /** Eigener Mauszeiger in Menues: 0 = Standard */
    public int cursorStyle = 0, cursorSize = 0;
    // PvP
    public boolean cpsHud = false, reachHud = false, pvpItems = false;
    public int hitSoundIdx = 0;
    public boolean hitMarker = false, hitSound = false, lowHpWarn = false, cooldownBar = false;
    /** Goldener Rand um die Hunger-Icons = Saturation */
    public boolean satBorder = true;
    /** Auto-Reconnect nach Verbindungsabbruch */
    public boolean autoReconnect = true;
    public int reconnectSec = 5;
    /** Eigener Nametag ueber dem Kopf in der 3. Person (F5) */
    public boolean ownNametag = true;
    public boolean autoUpdate = true;
    /** einmalig: Auto-Update wieder einschalten (wurde vom Master-Schalter mit ausgeschaltet) */
    public boolean autoUpdateFixed = false;
    /** Effekte in Toasty-Farben (Partikel ingame) und Menue-Hintergrund */
    public boolean fxOrbs = true, fxJump = true, blockOutline = true;
    public boolean rainFx = true;
    public int rainDensity = 2;
    /** Skelett-Ansicht (Knochen anderer Spieler); Glas-Felder nur noch intern fuer ToastyBody, Glas-Skin selbst bleibt aus */
    @com.google.gson.annotations.SerializedName("skeletonView") public boolean skeleton = false;
    public transient boolean glass = false;
    public int skelStyle = 0, glassOpacity = 2, glassGlow = 2;
    public String glassColor = "#880FF9";
    public int airDensity = 2, airSize = 2;
    public boolean mbNebula = true, mbRays = true, mbStars = true, mbSparks = true;
    public int mbIntensity = 2;
    public boolean antiLeak = false;
    /** Grosser Beitreten-Button im Hauptmenue */
    public boolean joinButton = true;
    /** Groesse der grossen Startmenue-Buttons (WindSMP + Multiplayer): 1 (klein) bis 5 (sehr gross) */
    public int startBtnSize = 3;
    /** Groesse des Multiplayer-Buttons im Hauptmenue: 1-5 (Standard kleiner als der Beitreten-Button) */
    public int mpBtnSize = 0; // 0 = wie Singleplayer
    public boolean mpSizeMigrated = false;
    /** Master-Schalter (Toasty Client): false = alle Features aus, Zustand in masterSaved gemerkt */
    public boolean masterOn = true;
    /** Toasty AI (Claude API): eigener Key, Modell */
    public String aiKey = "";
    public String aiModel = "claude-haiku-5-5";
    public java.util.Map<String, Boolean> masterSaved = new java.util.HashMap<>();
    /** Verschiebung des Mod-Menues */
    public int menuDx = 0, menuDy = 0;
    /** Mod-Menue-Fenster (0-6 Bereiche, 7 Suche): Position, offen/zu, gewaehlte Seite */
    public int[] winX = new int[8], winY = new int[8], winPage = new int[8];
    public boolean[] winOpen = {true, false, false, false, false, false, false, true};
    public String serverName = "WindSMP";
    public String serverIp = "windsmp.net";
    public String leakWords = "";
    public int totemIdx = 0;
    public boolean youtube = false;
    public String youtubeKey = "", youtubeVideo = "";
    public boolean twitch = false;
    public String twitchChannel = "";
    /** Werbung: Kanalname (leer = Twitch-Kanal vom Chat) und Text; {kanal} wird ersetzt. */
    public boolean adAuto = false;
    public int adEverySec = 10;
    public String adChannel = "";
    public String adText = "Schaut bei mir auf Twitch vorbei: twitch.tv/{kanal}";
    public int twitchLines = 8;
    public boolean auctionAnnounce = true;
    // ---------- Auktion (wie im Floons Client) ----------
    public boolean aucCountdown = true, aucHud = true, aucBigCountdown = true, aucFeed = true, aucAutoQueue = true;
    public long aucMinRaise = 1;
    /** Anti-Snipe: kommt in den letzten aucSnipeWindow Sekunden mehr Geld, geht die Zeit wieder auf aucSnipeTo Sekunden. */
    public boolean aucAntiSnipe = true;
    /** HUDs bei offenem Chat mit der Maus verschieben */
    public boolean chatDrag = true;
    public int aucSnipeWindow = 10, aucSnipeTo = 15, aucQueueGap = 10;
    /** top_left, top_right, bottom_right, mid_left, mid_right */
    public String aucCorner = "mid_right";
    public String giveawayKeyword = "join";
    // ---------- Giveaway (wie im Floons Client) ----------
    public int giveawayWinners = 1;
    public boolean giveawayTwitch = true, giveawayHud = true;
    /** Teilnahme per /msg an dich: jede Nachricht zählt, sonst nur mit Stichwort. */
    public boolean giveawayAnyMsg = true;
    public boolean giveawayPublic = false, giveawayReply = false;
    /** Eigenes Muster für eingehende /msg (Gruppen player und msg); leer = eingebaute Formate. */
    public String giveawayMsgPattern = "";
    // ---------- Ender-Wert (WindSMP-Preise aus /ah und /orders) ----------
    public boolean worthOverlay = true, worthTooltip = true, worthLearn = true;
    /** WindSMP-Preis-Server (Cloudflare Worker), leer = nur selbst gesehene Preise. */
    public String priceServer = "https://windsmp-prices.vent-lukas.workers.dev";
    /** gesehene /ah- und /orders-Preise an den Preis-Server senden */
    public boolean priceShare = true;
    public String worthMode = "ah";
    /** Suchbefehle für "Alle Preise suchen"; {item} = Itemname mit _ (z. B. diamond_sword). */
    /** Nach jeder Änderung in der Endertruhe die geänderten Items automatisch in /ah und /orders neu suchen. */
    public boolean worthAutoScan = true;
    /** Preise, die jünger sind als so viele Minuten, werden bei der Suche übersprungen. */
    public int worthFreshMin = 30;
    /** Pause zwischen zwei Suchbefehlen (ms); zu klein kann vom Server als Spam gewertet werden. */
    public int worthScanGapMs = 350;
    public String worthAhCmd = "ah {item}", worthOrderCmd = "orders {item}";
    public String worthMarketTitle = "(auction|auktion|\\bah\\b|markt|market)";
    public boolean perfClouds = false, perfBlend = false, perfAo = false, perfFps = false;
    public java.util.Map<String, String> orig = new java.util.HashMap<>();

    // Design
    public String color1 = "#A855F7";
    public String color2 = "#7DD3FC";
    public int bgOpacity = 208;

    // Gamble
    public long minBet = 0;
    public long maxBet = Long.MAX_VALUE;
    public double winMultiplier = 2.0;
    /** /win zahlt den Gewinn automatisch per /pay aus. */
    public boolean autoPay = true;
    /** WindSMP: "You received $1.5k from Name". Benannte Gruppen: player, amount, suffix. */
    public String pattern = "^You received \\$(?<amount>[0-9][0-9.,]*)\\s*(?<suffix>[KkMmBbTt]?) from (?<player>\\.?[A-Za-z0-9_]{1,16})\\.?$";

    // Performance (Einstellungen werden gemerkt, damit man sie zurueckstellen kann)
    public boolean perfParticles = false;
    public boolean perfShadows = false;
    public boolean perfDistance = false;
    public String origParticles = null;
    public Boolean origShadows = null;
    public Integer origView = null;
    public Integer origSim = null;
    public Double origScaling = null;

    public static ToastyConfig get() {
        if (instance == null) {
            try {
                if (Files.exists(FILE)) instance = GSON.fromJson(Files.readString(FILE), ToastyConfig.class);
            } catch (Exception ignored) {}
            if (instance == null) { instance = new ToastyConfig(); instance.cfgVersion = 2; instance.save(); }
            if (instance.cfgVersion < 2) {
                instance.cfgVersion = 2;
                instance.sellIntervalMs = Math.max(100, instance.sellIntervalSec * 1000);
                if (instance.orig == null) instance.orig = new java.util.HashMap<>();
                instance.save();
            }
        }
        return instance;
    }

    public String toJson() { return GSON.toJson(this); }

    public static ToastyConfig parse(String json) {
        try { return GSON.fromJson(json, ToastyConfig.class); } catch (Exception e) { return null; }
    }

    public static void replace(ToastyConfig c) {
        if (c.orig == null) c.orig = new java.util.HashMap<>();
        if (c.waypoints == null) c.waypoints = new java.util.ArrayList<>();
        if (c.notes == null) c.notes = new java.util.ArrayList<>();
        if (c.customLines == null) c.customLines = new java.util.ArrayList<>();
        if (c.hudPos == null) c.hudPos = new java.util.HashMap<>();
        if (c.keys == null) c.keys = new java.util.HashMap<>();
        if (c.sellItems == null) c.sellItems = new java.util.ArrayList<>();
        c.cfgVersion = 2;
        instance = c;
        c.save();
    }

    public void save() {
        try { Files.writeString(FILE, GSON.toJson(this)); } catch (Exception ignored) {}
    }
}
