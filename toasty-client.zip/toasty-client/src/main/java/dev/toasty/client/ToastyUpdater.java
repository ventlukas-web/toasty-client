package dev.toasty.client;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.fabricmc.loader.api.FabricLoader;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.time.Duration;
import java.util.Locale;

/**
 * Auto-Update: prueft beim Start das neueste GitHub-Release des Toasty Clients (nur ventlukas-web/toasty-client, per HTTPS), laedt die neue
 * Jar neben die alte und tauscht sie beim Beenden des Spiels aus (die laufende Jar ist unter Windows gesperrt). Wirkt beim naechsten Start.
 */
final class ToastyUpdater {
    private static final String API = "https://api.github.com/repos/ventlukas-web/toasty-client/releases/latest";
    private ToastyUpdater() {}

    static void start() {
        if (!ToastyConfig.get().autoUpdate) return;
        Thread t = new Thread(ToastyUpdater::run, "toasty-updater");
        t.setDaemon(true);
        t.start();
    }

    private static void run() {
        try {
            Path cur = FabricLoader.getInstance().getModContainer("toastyclient").flatMap(c -> c.getOrigin().getPaths().stream().findFirst()).orElse(null);
            if (cur == null || !Files.isRegularFile(cur) || !cur.getFileName().toString().endsWith(".jar")) return;   // Entwicklungsumgebung o. ae.
            Path mods = cur.getParent();
            if (Files.isRegularFile(mods.resolve(cur.getFileName() + ".new"))) return;   // Update liegt schon bereit
            HttpClient http = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(8)).followRedirects(HttpClient.Redirect.NORMAL).build();
            HttpResponse<String> r = http.send(HttpRequest.newBuilder(URI.create(API)).header("Accept", "application/vnd.github+json").timeout(Duration.ofSeconds(10)).build(), HttpResponse.BodyHandlers.ofString());
            if (r.statusCode() != 200) return;
            JsonArray assets = JsonParser.parseString(r.body()).getAsJsonObject().getAsJsonArray("assets");
            if (assets == null) return;
            for (JsonElement el : assets) {
                JsonObject a = el.getAsJsonObject();
                String nm = a.get("name").getAsString();
                if (!nm.startsWith("toasty-client") || !nm.endsWith(".jar") || nm.contains("sources") || nm.contains("dev")) continue;
                long size = a.get("size").getAsLong();
                if (size == Files.size(cur)) return;   // gleiche Version
                Path tmp = mods.resolve(nm + ".new");
                HttpResponse<Path> d = http.send(HttpRequest.newBuilder(URI.create(a.get("browser_download_url").getAsString())).timeout(Duration.ofMinutes(2)).build(), HttpResponse.BodyHandlers.ofFile(tmp));
                if (d.statusCode() != 200 || Files.size(tmp) != size) { Files.deleteIfExists(tmp); return; }
                Path target = mods.resolve(nm);
                Runtime.getRuntime().addShutdownHook(new Thread(() -> swap(cur, tmp, target)));
                try { ToastyNotify.push("Update bereit", "Neue Version wird beim Beenden installiert", ToastyTheme.PURPLE); } catch (Throwable ignored) {}
                return;
            }
        } catch (Throwable ignored) {}   // Auto-Update darf das Spiel nie stoeren
    }

    private static void swap(Path old, Path tmp, Path target) {
        try {
            boolean win = System.getProperty("os.name", "").toLowerCase(Locale.ROOT).contains("win");
            ProcessBuilder pb;
            if (win) pb = new ProcessBuilder("cmd", "/c", "ping -n 5 127.0.0.1 >nul & del /f /q \"" + old + "\" & move /y \"" + tmp + "\" \"" + target + "\"");
            else pb = new ProcessBuilder("sh", "-c", "sleep 4; rm -f '" + old + "'; mv -f '" + tmp + "' '" + target + "'");
            pb.start();
        } catch (Throwable ignored) {}
    }
}
