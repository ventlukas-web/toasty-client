package dev.toasty.client;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.fabricmc.loader.api.FabricLoader;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.time.Duration;
import java.util.Locale;

/**
 * Auto-Update: prueft beim Start das neueste GitHub-Release des Toasty Clients (nur ventlukas-web/toasty-client, per HTTPS), laedt die neue
 * Jar neben die alte und tauscht sie beim Beenden des Spiels aus (die laufende Jar ist unter Windows gesperrt). Wirkt beim naechsten Start.
 */
final class ToastyUpdater {
    private static final String API = "https://api.github.com/repos/ventlukas-web/toasty-client/releases/latest";
    private ToastyUpdater() {}

    static void start() {
        if (!ToastyConfig.get().autoUpdate) { status = "Auto-Update aus"; return; }
        Thread t = new Thread(ToastyUpdater::run, "toasty-updater");
        t.setDaemon(true);
        t.start();
    }

    private static Path logFile() { return FabricLoader.getInstance().getConfigDir().resolve("toasty-update.log"); }
    private static Path markFile() { return FabricLoader.getInstance().getConfigDir().resolve("toasty-update.mark"); }

    static void log(String m) {
        try { Files.writeString(logFile(), Instant.now() + " " + m + "\n", StandardCharsets.UTF_8, java.nio.file.StandardOpenOption.CREATE, java.nio.file.StandardOpenOption.APPEND); } catch (Throwable ignored) {}
    }

    /** Zustand für /toasty update und das Menü. */
    static volatile String status = "noch nicht geprüft";

    static String sha256(Path p) {
        try (var in = Files.newInputStream(p)) {
            var md = java.security.MessageDigest.getInstance("SHA-256");
            byte[] buf = new byte[1 << 16]; int n;
            while ((n = in.read(buf)) > 0) md.update(buf, 0, n);
            StringBuilder sb = new StringBuilder();
            for (byte x : md.digest()) sb.append(String.format("%02x", x));
            return sb.toString();
        } catch (Throwable t) { return ""; }
    }

    /** Weitere Kopien derselben Jar (z. B. Norisk-Launcher-Ordner, die beim Start in den mods-Ordner kopiert werden). */
    private static java.util.List<Path> copies(Path cur, String curSha) {
        java.util.Set<Path> roots = new java.util.LinkedHashSet<>();
        for (Path p = cur.getParent(); p != null; p = p.getParent())
            if (p.getFileName() != null && p.getFileName().toString().toLowerCase(Locale.ROOT).contains("norisk")) roots.add(p);
        String appdata = System.getenv("APPDATA");
        for (String base : new String[]{appdata, System.getProperty("user.home")}) {
            if (base == null) continue;
            try (var ds = Files.newDirectoryStream(Path.of(base))) {
                for (Path p : ds) if (Files.isDirectory(p) && p.getFileName().toString().toLowerCase(Locale.ROOT).contains("norisk")) roots.add(p);
            } catch (Throwable ignored) {}
        }
        java.util.List<Path> out = new java.util.ArrayList<>();
        for (Path root : roots) {
            try (var st = Files.walk(root, 9)) {
                st.filter(f -> {
                    String n = f.getFileName().toString().toLowerCase(Locale.ROOT);
                    return n.startsWith("toasty-client") && n.endsWith(".jar") && Files.isRegularFile(f);
                }).forEach(f -> {
                    try { if (!Files.isSameFile(f, cur) && sha256(f).equals(curSha)) out.add(f); } catch (Throwable ignored) {}
                });
            } catch (Throwable ignored) {}
        }
        return out;
    }

    static void run() {
        try {
            status = "prüfe …";
            Path cur = FabricLoader.getInstance().getModContainer("toastyclient").flatMap(c -> c.getOrigin().getPaths().stream().findFirst()).orElse(null);
            log("Start. Jar: " + cur);
            if (cur == null || !Files.isRegularFile(cur) || !cur.getFileName().toString().endsWith(".jar")) { status = "keine Jar (Dev?)"; log("Abbruch: keine Jar-Datei (Dev-Umgebung?)"); return; }
            Path mods = cur.getParent();
            String curSha = sha256(cur);
            HttpClient http = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(8)).followRedirects(HttpClient.Redirect.NORMAL).build();
            HttpResponse<String> r = http.send(HttpRequest.newBuilder(URI.create(API)).header("Accept", "application/vnd.github+json")
                .header("User-Agent", "toasty-client").timeout(Duration.ofSeconds(10)).build(), HttpResponse.BodyHandlers.ofString());
            if (r.statusCode() != 200) { status = "GitHub-Fehler " + r.statusCode(); log("GitHub-Antwort " + r.statusCode()); return; }
            JsonArray assets = JsonParser.parseString(r.body()).getAsJsonObject().getAsJsonArray("assets");
            if (assets == null) { status = "Release ohne Datei"; log("Release ohne Dateien"); return; }
            for (JsonElement el : assets) {
                JsonObject a = el.getAsJsonObject();
                String nm = a.get("name").getAsString();
                if (!nm.startsWith("toasty-client") || !nm.endsWith(".jar") || nm.contains("sources") || nm.contains("dev")) continue;
                long size = a.get("size").getAsLong();
                String digest = a.has("digest") && !a.get("digest").isJsonNull() ? a.get("digest").getAsString().replaceFirst("^sha256:", "") : "";
                // Vergleich über den echten Datei-Inhalt (SHA-256), nicht über eine Merk-Datei
                boolean same = !digest.isEmpty() ? digest.equalsIgnoreCase(curSha) : size == Files.size(cur);
                if (same) { status = "aktuell"; log("Aktuell (" + nm + ")"); return; }
                Path tmp = mods.resolve(nm + ".new");
                Files.deleteIfExists(tmp);
                status = "lade Update …";
                log("Lade " + nm + " (" + size + " Bytes)");
                HttpResponse<Path> d = http.send(HttpRequest.newBuilder(URI.create(a.get("browser_download_url").getAsString()))
                    .header("User-Agent", "toasty-client").timeout(Duration.ofMinutes(2)).build(), HttpResponse.BodyHandlers.ofFile(tmp));
                if (d.statusCode() != 200 || Files.size(tmp) != size || (!digest.isEmpty() && !digest.equalsIgnoreCase(sha256(tmp)))) {
                    status = "Download fehlgeschlagen"; log("Download fehlgeschlagen: " + d.statusCode()); Files.deleteIfExists(tmp); return;
                }
                // Kopien im Launcher-Ordner (Norisk) mit aktualisieren, sonst kopiert der Launcher beim Start wieder die alte Version rein
                for (Path c : copies(cur, curSha)) {
                    try {
                        Path nc = c.resolveSibling(nm);
                        Files.copy(tmp, nc, StandardCopyOption.REPLACE_EXISTING);
                        if (!Files.isSameFile(nc, c)) Files.deleteIfExists(c);
                        log("Launcher-Kopie aktualisiert: " + nc);
                    } catch (Throwable t) { log("Launcher-Kopie nicht aktualisiert: " + c + " " + t); }
                }
                Path target = mods.resolve(nm);
                String stamp = a.has("updated_at") ? a.get("updated_at").getAsString() : "";
                if (direct(cur, tmp, target, stamp)) {
                    status = "Update installiert – Neustart";
                    log("Update sofort installiert, aktiv beim naechsten Start");
                    try { ToastyNotify.push("Update installiert", "Neue Version ist beim naechsten Start aktiv", ToastyTheme.PURPLE); } catch (Throwable ignored) {}
                    return;
                }
                Runtime.getRuntime().addShutdownHook(new Thread(() -> swap(cur, tmp, target, stamp)));
                status = "Update beim Beenden";
                log("Sofort-Tausch nicht moeglich, Update wird beim Beenden installiert");
                try { ToastyNotify.push("Update bereit", "Neue Version wird beim Beenden installiert", ToastyTheme.PURPLE); } catch (Throwable ignored) {}
                return;
            }
            status = "kein Jar im Release";
            log("Kein passendes Jar im Release");
        } catch (Throwable t) { status = "Fehler: " + t.getClass().getSimpleName(); log("Fehler: " + t); }   // Auto-Update darf das Spiel nie stoeren
    }

    /** /toasty update: sofort prüfen (auch wenn Auto-Update aus ist). */
    static void checkNow() {
        Thread t = new Thread(ToastyUpdater::run, "toasty-updater");
        t.setDaemon(true);
        t.start();
    }

    private static boolean direct(Path old, Path tmp, Path target, String stamp) {
        try {
            Path bak = old.resolveSibling(old.getFileName() + ".old");
            Files.deleteIfExists(bak);
            Files.move(old, bak, StandardCopyOption.REPLACE_EXISTING);
            try {
                Files.move(tmp, target, StandardCopyOption.REPLACE_EXISTING);
            } catch (Throwable t) {
                try { Files.move(bak, old, StandardCopyOption.REPLACE_EXISTING); } catch (Throwable ignored) {}   // zurueckrollen
                throw t;
            }
            try { Files.deleteIfExists(bak); } catch (Throwable ignored) {}   // ggf. spaeter von Hand
            try { Files.writeString(markFile(), stamp); } catch (Throwable ignored) {}
            log("Direkt getauscht -> " + target);
            return true;
        } catch (Throwable t) {
            log("Direkter Tausch nicht moeglich: " + t);
            return false;
        }
    }

    private static void swap(Path old, Path tmp, Path target, String stamp) {
        if (direct(old, tmp, target, stamp)) return;
        // 2) abgekoppelter Helfer (ueberlebt das Beenden, auch wenn der Launcher den Prozessbaum beendet)
        try {
            boolean win = System.getProperty("os.name", "").toLowerCase(Locale.ROOT).contains("win");
            ProcessBuilder pb;
            if (win) pb = new ProcessBuilder("cmd", "/c", "start", "\"\"", "/b", "cmd", "/c",
                "ping -n 6 127.0.0.1 >nul & del /f /q \"" + old + "\" & move /y \"" + tmp + "\" \"" + target + "\"");
            else pb = new ProcessBuilder("sh", "-c", "nohup sh -c \"sleep 4; rm -f '" + old + "'; mv -f '" + tmp + "' '" + target + "'\" >/dev/null 2>&1 &");
            pb.start();
            try { Files.writeString(markFile(), stamp); } catch (Throwable ignored) {}
            log("Helfer gestartet");
        } catch (Throwable t) { log("Helfer fehlgeschlagen: " + t); }
    }
}
