package dev.toasty.client;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.fabricmc.loader.api.FabricLoader;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.time.Duration;
import java.util.Locale;

/**
 * Auto-Update: prueft beim Start das neueste GitHub-Release des Toasty Clients (nur ventlukas-web/toasty-client, per HTTPS), laedt die neue
 * Jar neben die alte und tauscht sie beim Beenden des Spiels aus (die laufende Jar ist unter Windows gesperrt). Wirkt beim naechsten Start.
 */
final class ToastyUpdater {
    private static final String API = "https://api.github.com/repos/ventlukas-web/toasty-client/releases/latest";
    private ToastyUpdater() {}

    static void start() {
        if (!ToastyConfig.get().autoUpdate) return;
        Thread t = new Thread(ToastyUpdater::run, "toasty-updater");
        t.setDaemon(true);
        t.start();
    }

    private static Path logFile() { return FabricLoader.getInstance().getConfigDir().resolve("toasty-update.log"); }
    private static Path markFile() { return FabricLoader.getInstance().getConfigDir().resolve("toasty-update.mark"); }

    static void log(String m) {
        try { Files.writeString(logFile(), Instant.now() + " " + m + "\n", StandardCharsets.UTF_8, java.nio.file.StandardOpenOption.CREATE, java.nio.file.StandardOpenOption.APPEND); } catch (Throwable ignored) {}
    }

    private static void run() {
        try {
            Path cur = FabricLoader.getInstance().getModContainer("toastyclient").flatMap(c -> c.getOrigin().getPaths().stream().findFirst()).orElse(null);
            log("Start. Jar: " + cur);
            if (cur == null || !Files.isRegularFile(cur) || !cur.getFileName().toString().endsWith(".jar")) { log("Abbruch: keine Jar-Datei (Dev-Umgebung?)"); return; }
            Path mods = cur.getParent();
            HttpClient http = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(8)).followRedirects(HttpClient.Redirect.NORMAL).build();
            HttpResponse<String> r = http.send(HttpRequest.newBuilder(URI.create(API)).header("Accept", "application/vnd.github+json").timeout(Duration.ofSeconds(10)).build(), HttpResponse.BodyHandlers.ofString());
            if (r.statusCode() != 200) { log("GitHub-Antwort " + r.statusCode()); return; }
            JsonArray assets = JsonParser.parseString(r.body()).getAsJsonObject().getAsJsonArray("assets");
            if (assets == null) { log("Release ohne Dateien"); return; }
            String mark = null;
            try { if (Files.isRegularFile(markFile())) mark = Files.readString(markFile()).trim(); } catch (Throwable ignored) {}
            for (JsonElement el : assets) {
                JsonObject a = el.getAsJsonObject();
                String nm = a.get("name").getAsString();
                if (!nm.startsWith("toasty-client") || !nm.endsWith(".jar") || nm.contains("sources") || nm.contains("dev")) continue;
                long size = a.get("size").getAsLong();
                String stamp = a.has("updated_at") ? a.get("updated_at").getAsString() : "";
                boolean same = mark != null ? mark.equals(stamp) : size == Files.size(cur);
                if (same) { log("Aktuell (" + nm + ")"); if (mark == null) try { Files.writeString(markFile(), stamp); } catch (Throwable ignored) {} return; }
                Path tmp = mods.resolve(nm + ".new");
                Files.deleteIfExists(tmp);
                log("Lade " + nm + " (" + size + " Bytes)");
                HttpResponse<Path> d = http.send(HttpRequest.newBuilder(URI.create(a.get("browser_download_url").getAsString())).timeout(Duration.ofMinutes(2)).build(), HttpResponse.BodyHandlers.ofFile(tmp));
                if (d.statusCode() != 200 || Files.size(tmp) != size) { log("Download fehlgeschlagen: " + d.statusCode()); Files.deleteIfExists(tmp); return; }
                Path target = mods.resolve(nm);
                Runtime.getRuntime().addShutdownHook(new Thread(() -> swap(cur, tmp, target, stamp)));
                log("Update bereit, wird beim Beenden installiert");
                try { ToastyNotify.push("Update bereit", "Neue Version wird beim Beenden installiert", ToastyTheme.PURPLE); } catch (Throwable ignored) {}
                return;
            }
            log("Kein passendes Jar im Release");
        } catch (Throwable t) { log("Fehler: " + t); }   // Auto-Update darf das Spiel nie stoeren
    }

    private static void swap(Path old, Path tmp, Path target, String stamp) {
        // 1) direkt: alte Jar beiseite schieben (geht meist auch bei geoeffneter Jar), neue an ihren Platz
        try {
            Path bak = old.resolveSibling(old.getFileName() + ".old");
            Files.deleteIfExists(bak);
            Files.move(old, bak, StandardCopyOption.REPLACE_EXISTING);
            Files.move(tmp, target, StandardCopyOption.REPLACE_EXISTING);
            try { Files.deleteIfExists(bak); } catch (Throwable ignored) {}
            try { Files.writeString(markFile(), stamp); } catch (Throwable ignored) {}
            log("Direkt getauscht -> " + target);
            return;
        } catch (Throwable t) {
            log("Direkter Tausch nicht moeglich: " + t);
            try { if (!Files.exists(old)) Files.move(old.resolveSibling(old.getFileName() + ".old"), old); } catch (Throwable ignored) {}
        }
        // 2) abgekoppelter Helfer (ueberlebt das Beenden, auch wenn der Launcher den Prozessbaum beendet)
        try {
            boolean win = System.getProperty("os.name", "").toLowerCase(Locale.ROOT).contains("win");
            ProcessBuilder pb;
            if (win) pb = new ProcessBuilder("cmd", "/c", "start", "\"\"", "/b", "cmd", "/c",
                "ping -n 6 127.0.0.1 >nul & del /f /q \"" + old + "\" & move /y \"" + tmp + "\" \"" + target + "\"");
            else pb = new ProcessBuilder("sh", "-c", "nohup sh -c \"sleep 4; rm -f '" + old + "'; mv -f '" + tmp + "' '" + target + "'\" >/dev/null 2>&1 &");
            pb.start();
            try { Files.writeString(markFile(), stamp); } catch (Throwable ignored) {}
            log("Helfer gestartet");
        } catch (Throwable t) { log("Helfer fehlgeschlagen: " + t); }
    }
}
