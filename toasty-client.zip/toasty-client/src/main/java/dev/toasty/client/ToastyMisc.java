package dev.toasty.client;

import net.fabricmc.fabric.api.client.message.v1.ClientSendMessageEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.registry.Registries;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Fullbright, Autoclicker, Totem-Sounds, Anti-Leak. */
public final class ToastyMisc {
    private ToastyMisc() {}

    public static KeyBinding freecamKey, freelookKey, fullbrightKey, autoClickKey;

    public static final String[][] TOTEM = {
        {"Aus", ""}, {"Amboss", "block.anvil.land"}, {"Glocke", "block.bell.use"}, {"Ding", "entity.experience_orb.pickup"},
        {"Glas", "block.glass.break"}, {"Donner", "entity.lightning_bolt.thunder"}, {"Drache", "entity.ender_dragon.growl"},
        {"Amethyst", "block.amethyst_block.chime"}, {"Feuerwerk", "entity.firework_rocket.blast"},
        {"Wither", "entity.wither.shoot"}, {"Villager", "entity.villager.yes"}, {"Explosion", "entity.generic.explode"}
    };

    private static boolean fbApplied;
    private static double acc;

    public static void playTotem(int idx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || idx <= 0 || idx >= TOTEM.length) return;
        SoundEvent ev = Registries.SOUND_EVENT.get(Identifier.of("minecraft", TOTEM[idx][1]));
        if (ev != null) mc.player.playSound(ev, 1.0f, 1.0f);
    }

    public static void register() {
        // Totem-Pop erkennen: Sound-Listener (wie bei den Untertiteln)
        MinecraftClient.getInstance().getSoundManager().registerListener((sound, set, range) -> {
            int idx = ToastyConfig.get().totemIdx;
            if (idx <= 0) return;
            if (sound.getId().getPath().equals("item.totem.use")) playTotem(idx);
        });
        ClientSendMessageEvents.ALLOW_CHAT.register(ToastyMisc::allowOut);
        ClientSendMessageEvents.ALLOW_COMMAND.register(cmd -> allowOut("/" + cmd));
    }

    public static void tick(MinecraftClient mc) {
        ToastyConfig cfg = ToastyConfig.get();
        if (mc.player == null || mc.world == null) { fbApplied = false; return; }

        while (fullbrightKey != null && fullbrightKey.wasPressed()) {
            cfg.fullbright = !cfg.fullbright; cfg.save();
            ToastyGamble.chat("Fullbright " + (cfg.fullbright ? "an" : "aus"));
        }
        while (autoClickKey != null && autoClickKey.wasPressed()) {
            cfg.autoClick = !cfg.autoClick; cfg.save();
            ToastyGamble.chat("Autoclicker " + (cfg.autoClick ? "an" : "aus"));
        }

        // Fullbright = clientseitiger Nachtsicht-Effekt
        if (cfg.fullbright) {
            StatusEffectInstance cur = mc.player.getStatusEffect(StatusEffects.NIGHT_VISION);
            if (cur == null || cur.getDuration() < 400) {
                mc.player.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 1200, 0, false, false, false));
                fbApplied = true;
            }
        } else if (fbApplied) {
            mc.player.removeStatusEffect(StatusEffects.NIGHT_VISION);
            fbApplied = false;
        }

        // Autoclicker: solange die Maustaste gehalten wird, zusaetzliche Klicks mit eingestellter CPS
        if (cfg.autoClick && mc.currentScreen == null && !ToastyCam.active()) {
            KeyBinding kb = cfg.autoRight ? mc.options.useKey : mc.options.attackKey;
            if (kb.isPressed()) {
                acc += Math.max(1, Math.min(40, cfg.autoCps)) / 20.0;
                int n = Math.min(4, (int) acc);
                acc -= (int) acc;
                if (n > 0) {
                    InputUtil.Key key = InputUtil.fromTranslationKey(kb.getBoundKeyTranslationKey());
                    for (int i = 0; i < n; i++) KeyBinding.onKeyPressed(key);
                }
            } else acc = 0;
        }
    }

    // ---------- Anti-Leak ----------

    private static final Pattern IP = Pattern.compile("\\b(?:\\d{1,3}\\.){3}\\d{1,3}\\b");
    private static final Pattern NUM = Pattern.compile("-?\\d{2,6}");
    private static final Pattern DM = Pattern.compile("^/(msg|w|tell|r|reply|m|whisper|t)\\b.*", Pattern.CASE_INSENSITIVE);

    private static boolean allowOut(String text) {
        ToastyConfig cfg = ToastyConfig.get();
        if (!cfg.antiLeak) return true;
        MinecraftClient mc = MinecraftClient.getInstance();
        String low = text.toLowerCase();
        String why = null;
        for (String w : cfg.leakWords.split(",")) {
            w = w.trim().toLowerCase();
            if (w.length() >= 2 && low.contains(w)) { why = "gesperrtes Wort \"" + w + "\""; break; }
        }
        String user = System.getProperty("user.name", "");
        if (why == null && user.length() >= 4 && low.contains(user.toLowerCase())) why = "dein PC-Benutzername";
        if (why == null && IP.matcher(text).find()) why = "IP-Adresse";
        boolean chatLike = !text.startsWith("/") || DM.matcher(text).matches();
        if (why == null && chatLike && mc.player != null) {
            Matcher m = NUM.matcher(text);
            java.util.List<Integer> nums = new java.util.ArrayList<>();
            while (m.find()) { try { nums.add(Integer.parseInt(m.group())); } catch (Exception ignored) {} }
            for (int a : nums) for (int b : nums) {
                if (Math.abs(a - mc.player.getX()) < 150 && Math.abs(b - mc.player.getZ()) < 150) { why = "deine Koordinaten"; break; }
            }
        }
        if (why == null) return true;
        ToastyNotify.push("Anti-Leak", "Blockiert: " + why, ToastyTheme.BAD);
        ToastyGamble.chat("Anti-Leak hat die Nachricht blockiert (" + why + ").");
        return false;
    }
}
