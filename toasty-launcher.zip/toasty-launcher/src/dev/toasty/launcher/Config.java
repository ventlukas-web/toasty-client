package dev.toasty.launcher;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

/** Einstellungen + gespeicherter Account in %APPDATA%\ToastyLauncher\config.json */
public final class Config {
    public static final String CLIENT_MC = "1.21.11"; // Toasty Client gibt es nur dafür
    public static String mc = CLIENT_MC;           // gewählte Minecraft-Version
    public static final String LAUNCHER_REPO = "ventlukas-web/toasty-launcher";
    public static final String CLIENT_REPO = "ventlukas-web/toasty-client";

    public static final Path DIR = baseDir();
    public static final Path FILE = DIR.resolve("config.json");
    public static final Path GAME = DIR.resolve("game");
    public static Path instance() { return GAME.resolve("instances").resolve(mc); }

    public int ramMb = 4096;
    public boolean closeOnLaunch = false;
    public String clientId = "";
    public String repo = CLIENT_REPO;
    // Account
    public String accName = "", accUuid = "", accRefresh = "";
    public boolean offline = false;

    private static Path baseDir() {
        String ad = System.getenv("APPDATA");
        Path p = ad != null && !ad.isBlank() ? Paths.get(ad, "ToastyLauncher") : Paths.get(System.getProperty("user.home"), ".toasty-launcher");
        return p;
    }

    public static Config load() {
        Config c = new Config();
        try {
            if (Files.isRegularFile(FILE)) {
                Map<String, Object> m = Json.obj(Json.parse(Files.readString(FILE, StandardCharsets.UTF_8)));
                if (m.get("ramMb") instanceof Double d) c.ramMb = Math.max(1024, Math.min(32768, d.intValue()));
                if (m.get("closeOnLaunch") instanceof Boolean b) c.closeOnLaunch = b;
                if (m.get("offline") instanceof Boolean b) c.offline = b;
                String v = Json.str(m.get("mc")); if (!v.isBlank()) mc = v;
                c.clientId = Json.str(m.get("clientId")); c.accName = Json.str(m.get("accName")); c.accUuid = Json.str(m.get("accUuid")); c.accRefresh = Json.str(m.get("accRefresh"));
                String r = Json.str(m.get("repo")); if (!r.isBlank()) c.repo = r;
            }
        } catch (Exception ignored) {}
        return c;
    }

    public void save() {
        try {
            Files.createDirectories(DIR);
            Map<String, Object> m = new LinkedHashMap<>();
            m.put("ramMb", (double) ramMb); m.put("mc", mc); m.put("closeOnLaunch", closeOnLaunch); m.put("offline", offline); m.put("clientId", clientId);
            m.put("repo", repo); m.put("accName", accName); m.put("accUuid", accUuid); m.put("accRefresh", accRefresh);
            Files.writeString(FILE, Json.write(m), StandardCharsets.UTF_8);
        } catch (IOException ignored) {}
    }
}
