package dev.toasty.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

/** Aurora-Overlay: weiche, wandernde Lila/Blau-Baender oben im Bild (reines HUD, kein Shader). */
public final class ToastyAurora {
    private ToastyAurora() {}

    public static void render(DrawContext ctx, MinecraftClient mc, ToastyConfig cfg) {
        if (!cfg.aurora || mc.world == null || mc.options.hudHidden) return;
        int w = ctx.getScaledWindowWidth(), h = ctx.getScaledWindowHeight();
        double t = System.currentTimeMillis() / 1000.0;
        int bandH = h / 3, step = 4;
        for (int x = 0; x < w; x += step) {
            double wave = Math.sin(x * 0.02 + t * 0.6) * 0.5 + Math.sin(x * 0.047 - t * 0.9) * 0.5; // -1..1
            float k = (float) (0.5 + 0.5 * wave);
            int hh = (int) (bandH * (0.45 + 0.55 * k));
            int c = ToastyTheme.lerp(ToastyTheme.PURPLE, ToastyTheme.BLUE, (float) (0.5 + 0.5 * Math.sin(x * 0.011 + t * 0.3)));
            ctx.fillGradient(x, 0, x + step, hh, ToastyTheme.alpha(c, (int) (0x38 * (0.5 + 0.5 * k))), ToastyTheme.alpha(c, 0));
        }
    }
}
