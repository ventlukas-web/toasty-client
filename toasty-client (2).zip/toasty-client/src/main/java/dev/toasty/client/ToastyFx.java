package dev.toasty.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.particle.DustColorTransitionParticleEffect;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.util.math.Vec3d;

/** Effekte in Toasty-Farben: Lichtschweif hinter dir (Trail) und Ring beim Landen (Shockwave). Reine Client-Partikel. */
public final class ToastyFx {
    private ToastyFx() {}

    private static boolean wasGround = true;
    private static double fallStartY = 0, lastY = 0;
    private static int ringTick = -1;
    private static Vec3d ringPos = Vec3d.ZERO;
    private static Vec3d lastPos = Vec3d.ZERO;

    private static ParticleEffect effect(float size) {
        // Uebergang Lila -> Blau (Toasty-Farben); Farbe ohne Alpha
        return new DustColorTransitionParticleEffect(ToastyTheme.PURPLE & 0xFFFFFF, ToastyTheme.BLUE & 0xFFFFFF, size);
    }

    public static void tick(MinecraftClient mc) {
        ToastyConfig cfg = ToastyConfig.get();
        if ((!cfg.fxTrail && !cfg.fxShock && !cfg.fxHalo && !cfg.fxRing) || mc.player == null || mc.world == null || mc.isPaused()) { ringTick = -1; return; }
        var p = mc.player;
        Vec3d pos = new Vec3d(p.getX(), p.getY(), p.getZ());

        // Trail: Partikel entlang der zurueckgelegten Strecke, nur bei Bewegung und nicht in der 1. Person ganz vor der Kamera
        if (cfg.fxTrail) {
            double moved = pos.distanceTo(lastPos);
            if (moved > 0.04 && moved < 5) {
                int n = Math.min(6, 1 + (int) (moved * 6));
                for (int i = 0; i < n; i++) {
                    double t = (i + 1) / (double) n;
                    Vec3d q = lastPos.lerp(pos, t);
                    double jx = (Math.random() - 0.5) * 0.25, jy = Math.random() * 0.9, jz = (Math.random() - 0.5) * 0.25;
                    mc.particleManager.addParticle(effect(0.9f), q.x + jx, q.y + 0.1 + jy, q.z + jz, 0, 0.01, 0);
                }
            }
        }

        // Halo: Ring ueber dem Kopf (in der 1. Person nicht sichtbar, daher nur ausserhalb)
        long tk = mc.world.getTime();
        if (cfg.fxHalo && !mc.options.getPerspective().isFirstPerson() && tk % 2 == 0) {
            for (int i = 0; i < 10; i++) {
                double a = tk * 0.08 + i * (Math.PI * 2 / 10);
                mc.particleManager.addParticle(effect(0.7f), pos.x + Math.cos(a) * 0.38, pos.y + p.getHeight() + 0.25, pos.z + Math.sin(a) * 0.38, 0, 0, 0);
            }
        }
        // Boden-Ring: langsam drehender Ring um die Fuesse
        if (cfg.fxRing && tk % 3 == 0) {
            for (int i = 0; i < 12; i++) {
                double a = -tk * 0.05 + i * (Math.PI * 2 / 12);
                mc.particleManager.addParticle(effect(0.8f), pos.x + Math.cos(a) * 1.1, pos.y + 0.06, pos.z + Math.sin(a) * 1.1, 0, 0, 0);
            }
        }

        // Shockwave: beim Landen nach einem Fall von >= 2.5 Bloecken
        if (cfg.fxShock) {
            boolean ground = p.isOnGround();
            if (!ground && wasGround) fallStartY = p.getY();
            if (!ground) fallStartY = Math.max(fallStartY, p.getY());
            if (ground && !wasGround && fallStartY - p.getY() >= 2.5 && !p.isTouchingWater()) { ringTick = 0; ringPos = pos; }
            wasGround = ground;
            if (ringTick >= 0) {
                double r = 0.6 + ringTick * 0.55;
                int pts = (int) Math.min(48, 14 + ringTick * 4);
                for (int i = 0; i < pts; i++) {
                    double a = i * (Math.PI * 2 / pts) + ringTick * 0.15;
                    mc.particleManager.addParticle(effect(1.2f), ringPos.x + Math.cos(a) * r, ringPos.y + 0.08, ringPos.z + Math.sin(a) * r, 0, 0.02, 0);
                }
                if (++ringTick > 12) ringTick = -1;
            }
        } else { ringTick = -1; wasGround = true; }
        lastPos = pos;
    }
}
