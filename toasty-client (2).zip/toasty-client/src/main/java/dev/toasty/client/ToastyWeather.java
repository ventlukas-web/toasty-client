package dev.toasty.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

/** Wetter-Karte mit echten Welt-Daten (Regen, Gewitter, Tageszeit, Tag) und eine leichte Wetter-Stimmung als Farbton. Keine erfundenen Werte. */
public final class ToastyWeather {
    private ToastyWeather() {}

    public static void render(DrawContext ctx, TextRenderer tr, MinecraftClient mc, ToastyConfig cfg) {
        if (mc.world == null || mc.player == null || (!cfg.weatherHud && !cfg.weatherTint)) return;
        var w = mc.world;
        String dim = w.getRegistryKey().getValue().getPath();
        boolean overworld = dim.equals("overworld");
        float rain = overworld ? w.getRainGradient(1f) : 0f;
        float thunder = overworld ? w.getThunderGradient(1f) : 0f;

        // Stimmung: weicher Farbton ueber dem Bild
        if (cfg.weatherTint && (rain > 0.02f || thunder > 0.02f)) {
            int sw = mc.getWindow().getScaledWidth(), sh = mc.getWindow().getScaledHeight();
            int col = thunder > 0.02f ? 0x7B2FD6 : 0x3A63C8;
            float k = Math.max(thunder * 1.0f, rain * 0.6f);
            ctx.fill(0, 0, sw, sh, ToastyTheme.alpha(0xFF000000 | col, (int) (0x34 * k)));
        }
        if (!cfg.weatherHud) return;

        String cond; int accent;
        if (!overworld) { cond = dim.equals("the_nether") ? "Nether" : dim.equals("the_end") ? "End" : dim; accent = ToastyTheme.PURPLE; }
        else if (thunder > 0.5f) { cond = "Gewitter"; accent = ToastyTheme.PURPLE; }
        else if (rain > 0.5f) { cond = "Regen"; accent = ToastyTheme.BLUE; }
        else { cond = "Klar"; accent = ToastyTheme.BLUE; }

        long t = w.getTimeOfDay();
        long dayTime = ((t % 24000) + 24000) % 24000;
        int hour = (int) ((dayTime / 1000 + 6) % 24), min = (int) ((dayTime % 1000) * 60 / 1000);
        String sub = overworld
            ? "Tag " + (t / 24000 + 1) + "  ·  " + String.format("%02d:%02d", hour, min) + (dayTime >= 12500 && dayTime < 23000 ? "  ·  Nacht" : "")
            : "Tag " + (t / 24000 + 1);

        int pad = 8, big = 2;
        int cw = tr.getWidth(cond) * big, sw2 = tr.getWidth(sub);
        int bw = Math.max(Math.max(cw, sw2), 90) + pad * 2, bh = 8 + 9 + 9 * big + 6 + 9 + 8;
        float[] p = ToastyHud.place("weather", 6, 60, bw * cfg.hudScale, bh * cfg.hudScale, mc);
        ctx.getMatrices().pushMatrix();
        ctx.getMatrices().translate(p[0], p[1]);
        ctx.getMatrices().scale(cfg.hudScale, cfg.hudScale);
        ToastyTheme.panel(ctx, 0, 0, bw, bh);
        ctx.drawTextWithShadow(tr, "WETTER", pad, 6, ToastyTheme.MUTED);
        ctx.getMatrices().pushMatrix();
        ctx.getMatrices().translate(pad, 17);
        ctx.getMatrices().scale(big, big);
        ctx.drawTextWithShadow(tr, cond, 0, 0, accent);
        ctx.getMatrices().popMatrix();
        ctx.drawTextWithShadow(tr, sub, pad, 17 + 9 * big + 4, ToastyTheme.TEXT);
        // Intensitaetsbalken (echter Regen-/Gewitterwert der Welt)
        int bx = pad, by = bh - 7, bwid = bw - pad * 2;
        ctx.fill(bx, by, bx + bwid, by + 2, ToastyTheme.alpha(0xFFFFFFFF, 0x30));
        float lvl = Math.max(rain, thunder);
        if (lvl > 0.01f) ctx.fill(bx, by, bx + Math.max(1, (int) (bwid * lvl)), by + 2, accent);
        ctx.getMatrices().popMatrix();
    }
}
