package dev.toasty.client.mixin;

import dev.toasty.client.ToastyScreen;
import dev.toasty.client.ToastyTitle;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.client.gui.widget.CyclingButtonWidget;
import net.minecraft.client.gui.widget.PressableWidget;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Zeichnet alle Vanilla-Buttons (Optionen, Pause, Welt-Auswahl ...) im Toasty-Design. */
@Mixin(PressableWidget.class)
public abstract class PressableWidgetMixin {
    @Inject(method = "renderWidget", at = @At("HEAD"), cancellable = true)
    private void toasty$render(DrawContext ctx, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        try {
            if (!dev.toasty.client.ToastyConfig.get().niceButtons) return;
            Object self = this;
            if (!(self.getClass() == ButtonWidget.class || self instanceof CyclingButtonWidget)) return;
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.currentScreen instanceof ToastyScreen) return;
            ClickableWidget w = (ClickableWidget) self;
            ToastyTitle.styledButton(ctx, mc, w, mouseX, mouseY);
            ci.cancel();
        } catch (Throwable t) { /* fail-soft: Vanilla zeichnen lassen */ }
    }
}
